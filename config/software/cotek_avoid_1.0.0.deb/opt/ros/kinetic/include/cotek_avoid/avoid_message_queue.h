/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_MESSAGE_QUEUE_H_
#define COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_MESSAGE_QUEUE_H_
#include <ros/ros.h>
#include <deque>
#include <utility>
#include "cotek_avoid/avoid_constants.h"
#include "cotek_common/enum_type.h"
#include "cotek_common/log_porting.h"

namespace cotek_avoid {
class AvoidMessageQueue
    : public std::deque<std::pair<ros::Time, AvoidSpeedLevel>> {
 public:
  AvoidSpeedLevel Filter(const ros::Duration &reserve_time);
};

}  // namespace cotek_avoid
#endif  // COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_MESSAGE_QUEUE_H_
