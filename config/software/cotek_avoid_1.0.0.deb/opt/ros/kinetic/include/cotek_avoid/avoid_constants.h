/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#pragma once
#ifndef COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_CONSTANTS_H_
#define COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_CONSTANTS_H_
#include <string>
#include <vector>
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include "cotek_common/log_porting.h"

namespace cotek_avoid {

namespace bg = boost::geometry;
namespace tf = bg::strategy::transform;

using Point = bg::model::d2::point_xy<double>;
using Line = bg::model::linestring<Point>;
using Polygon = bg::model::polygon<Point, true, true>;
using Translate = tf::translate_transformer<double, 2, 2>;
using Rotate = tf::rotate_transformer<boost::geometry::radian, double, 2, 2>;

constexpr char kLaserScanTopic[] = "scan";
constexpr char kAvoidSlowLevel1Name[] = "slow_level1";
constexpr char kAvoidSlowLevel2Name[] = "slow_level2";
constexpr char kAvoidStopName[] = "stop";

std::vector<std::string> ComputeRepeatedTopicNames(const std::string& topic,
                                                   int num_topics);

}  // namespace cotek_avoid

#endif  // COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_CONSTANTS_H_
