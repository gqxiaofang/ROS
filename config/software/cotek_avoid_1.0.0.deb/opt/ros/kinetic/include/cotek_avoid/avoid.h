/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_H_
#define COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_H_
#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <deque>
#include <string>
#include <utility>
#include "cotek_avoid/avoid_constants.h"
#include "cotek_avoid/avoid_options.h"
#include "cotek_avoid/avoid_process.h"
#include "cotek_common/cotek_topic_name.h"
#include "cotek_common/node_diagnostic_info.h"
#include "cotek_msgs/manual.h"
#include "cotek_msgs/node_diagnostic.h"

namespace cotek_avoid {

class Avoid {
  using AvoidNodeStatus = cotek_diagnostic::AvoidNodeStatus;

 public:
  /**
   * \brief default constructor
   */
  Avoid() = delete;

  /**
   * \brief construct object with options
   * \param option all Avoid related parameters
   */
  explicit Avoid(const AvoidOption& option);

  /**
   * \brief destructor
   */
  ~Avoid();

  /**
   * \brief option getter
   * \return LocalizerOption
   */
  inline AvoidOption Option() const { return option_; }

  /**
   * \brief do initialization
   * \return true if init succeeded
   */
  bool Init() { return ap_->Init(); }

  /**
   * \brief start a thread and excute cycle
   */
  void Run();

  void AddSafetyIOStateCallback(
      const cotek_msgs::safety_io_state::ConstPtr& state);

  void AddPGVR2100Callback(
      const cotek_msgs::pgv_r2100_feedback::ConstPtr& data);

  void AddLaserScanCallback(const sensor_msgs::LaserScan::ConstPtr& scan);

  void AddSafetySettingCallback(
      const cotek_msgs::safety_setting::ConstPtr& setting);

  void AddManualCallback(const cotek_msgs::manual::ConstPtr& manual);

  void AddManualData(const cotek_msgs::manual::ConstPtr& manual);

  // 故障错误按优先级排序  1>2
  void SetNodeStatus(const AvoidNodeStatus& status) {
    if (status_ == AvoidNodeStatus::NORMAL) {
      status_ = status;
    } else {
      status_ = static_cast<uint16_t>(status_) <= static_cast<uint16_t>(status)
                    ? status_
                    : status;
    }
  }

  inline void ClearNodeStatus() { status_ = AvoidNodeStatus::NORMAL; }

  inline AvoidNodeStatus GetNodeStatus() const { return status_; }

  void AddUltrasoundCallback(
    const cotek_msgs::ultarsonic_feedback::ConstPtr& ultrasound);
 private:
  void Runner();
  /**
   * \brief handle error
   * \return true if can continue, false otherwise
   */
  void HandleError();

  void NodeDiagnostic(const ros::TimerEvent& e);

  AvoidOption option_;
  boost::shared_ptr<boost::thread> executor_;

  ros::Publisher avoid_level_pub_;
  ros::Publisher avoid_diagnostic_pub_;
  ros::Timer timer_;
  AvoidNodeStatus status_;
  boost::shared_ptr<AvoidProcess> ap_;
};

}  // namespace cotek_avoid

#endif  // COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_H_
