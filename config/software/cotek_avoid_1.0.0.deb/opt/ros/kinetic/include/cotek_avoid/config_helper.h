/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_AVOID_INCLUDE_COTEK_AVOID_CONFIG_HELPER_H_
#define COTEK_AVOID_INCLUDE_COTEK_AVOID_CONFIG_HELPER_H_
#include <map>
#include <string>
#include <vector>
#include "cotek_avoid/avoid_constants.h"
#include "cotek_common/json11.h"
#include "cotek_common/log_porting.h"

namespace cotek_avoid {

struct SensorTransform {
  double translation_x;
  double translation_y;
  double rotation;
};

// <map_id, <area_name, [coordinate_vector]>>
using AvoidMap = std::map<int, std::map<std::string, std::vector<Point>>>;
using Inner = std::vector<Point>;
using SensorTFData = std::map<std::string, SensorTransform>;

// 读取 json 文件 加载配置
class ConfigHelper {
 public:
  ~ConfigHelper() {}
  static ConfigHelper& Instance() {
    static ConfigHelper instance;
    return instance;
  }
  ConfigHelper(const ConfigHelper&) = delete;
  ConfigHelper& operator=(const ConfigHelper&) = delete;
  /**
   * \brief load config param from file path
   * \param the path of config param
   */
  bool LoadConfig(const std::string& json_str);
  /**
   * \brief get coordinate point from file
   */
  std::vector<Point> GetCoordinateVector(const std::vector<json11::Json>& vj);

  inline const AvoidMap& GetAvoidMap() { return avoid_map_; }

  inline const AvoidMap& GetSensorProtectMap() { return sensor_protect_map_; }

  inline const Inner& GetAgvInner() { return agv_inner_; }

  inline const SensorTFData& GetSensorTransform() { return sensor_tf_; }

 private:
  ConfigHelper() {}

  AvoidMap sensor_protect_map_;
  AvoidMap avoid_map_;
  Inner agv_inner_;
  SensorTFData sensor_tf_;
};
}  // namespace cotek_avoid
#endif  // COTEK_AVOID_INCLUDE_COTEK_AVOID_CONFIG_HELPER_H_
