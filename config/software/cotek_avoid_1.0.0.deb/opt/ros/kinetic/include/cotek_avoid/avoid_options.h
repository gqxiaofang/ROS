/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_OPTIONS_H_
#define COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_OPTIONS_H_
#include <string>

namespace cotek_avoid {

struct TopicOption {
  int num_laser_scans;
  bool io_state;
  bool Sick_LMSXXX_lidar;      // sick导航激光 (默认这三个只使能一种)
  bool PGV_r2000_lidar;        // 倍加福定位激光
  bool PGV_r2100_avoid_lidar;  // 倍加福避障激光
  bool Ultrasound;
};

struct LaserScanOption {
  int scan_sample_step;
  int samples_per_scan;
  std::string scan_frame_name;
  double angle_min;
  double angle_max;
  double angle_increment;
  double range_min;
  double range_max;
};

struct DataProcessOption {
  bool enable_visualize;
  bool ingore_error_laser_point;
  double sample_ratio;
  LaserScanOption pgv_r2100;
  LaserScanOption navi_laser;
  LaserScanOption ultrasound;
};

struct AvoidOption {
  TopicOption topic_option;
  DataProcessOption data_process_option;
  bool enable_local_debug;
  double controller_frequency;
  double node_diagnostic_frequency;
  std::string config_filename;
};

}  // namespace cotek_avoid

#endif  // COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_OPTIONS_H_
