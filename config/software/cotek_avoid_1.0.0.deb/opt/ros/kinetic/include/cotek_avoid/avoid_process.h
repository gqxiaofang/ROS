/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_PROCESS_H_
#define COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_PROCESS_H_
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PolygonStamped.h>
#include <sensor_msgs/LaserScan.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "cotek_avoid/avoid_constants.h"
#include "cotek_avoid/avoid_message_queue.h"
#include "cotek_avoid/avoid_options.h"
#include "cotek_avoid/config_helper.h"
#include "cotek_avoid/fixed_ratio_sampler.h"
#include "cotek_common/enum_type.h"
#include "cotek_common/log_porting.h"
#include "cotek_msgs/manual.h"
#include "cotek_msgs/pgv_r2100_feedback.h"
#include "cotek_msgs/safety_io_state.h"
#include "cotek_msgs/safety_setting.h"
#include "cotek_msgs/safety_state.h"
#include "cotek_msgs/ultarsonic_feedback.h"

namespace cotek_avoid {

enum class ErrorCode : uint8_t {
  NONE = 0,
  CONFIG_ERR,
  AVOID_SETTING_ERR,
  DATA_CHECK_ERR,
  DATA_TIME_OUT,
  AVOID_OVERTIME,
  BUMP_ERR,
  SENSOR_PROTECT
};

struct Strategy {
  Polygon slow_level1;
  Polygon slow_level2;
  Polygon stop;
  Polygon laser_protect;
};

struct SensorAvoidLevel {
  AvoidSpeedLevel navi_laser;
  AvoidSpeedLevel pgv_r2100;
  AvoidSpeedLevel io_state;
  AvoidSpeedLevel ultra_avoid;
};

struct UltrasoundAvoid {
  double length1;
  double length2;
  double length3;
};

class AvoidProcess {
 public:
  explicit AvoidProcess(const DataProcessOption &option);
  /**
   * \brief config default config and param..
   */
  bool Init();

  cotek_msgs::safety_state GetAvoidState();

  void SafetyIOStateCallback(
      const cotek_msgs::safety_io_state::ConstPtr &state);

  void PGVR2100Callback(const cotek_msgs::pgv_r2100_feedback::ConstPtr &data);

  void LaserScanCallback(const sensor_msgs::LaserScan::ConstPtr &scan);

  void SafetySettingCallback(
      const cotek_msgs::safety_setting::ConstPtr &setting);

  void ManualCallback(const cotek_msgs::manual::ConstPtr &manual);

  void UltrasoundCallback(
      const cotek_msgs::ultarsonic_feedback::ConstPtr &ultr);

  inline ErrorCode error() const { return err_; }
  inline void set_error_code(ErrorCode err) { err_ = err; }
  inline void ClearTimeOutCnt() { avoid_time_out_cnt_ = 0; }

 private:
  AvoidSpeedLevel GetScanAvoidLevel(
      const sensor_msgs::LaserScan::ConstPtr &scan, const Polygon &slow_level1,
      const Polygon &slow_level2, const Polygon &stop,
      const LaserScanOption &option);

  AvoidSpeedLevel GetLaserProtectAvoidLevel(
      const sensor_msgs::LaserScan::ConstPtr &scan, const Polygon &protect_map,
      const LaserScanOption &option);
  /**
   * \brief transform that caculate point to poly
   */
  Polygon TransformPoly(const Polygon &from_poly, const SensorTransform &tf);

  void AvoidPolygonPublish(const sensor_msgs::LaserScan::ConstPtr &scan,
                           const Polygon &slow_level1,
                           const Polygon &slow_level2, const Polygon &stop);

  void AvoidPointPublish(const sensor_msgs::LaserScan::ConstPtr &scan,
                         const Point &pt);

  Strategy GetStrategy(
      const std::map<std::string, std::vector<Point>> area_map);

  DataProcessOption option_;
  ros::Duration reserve_time_;
  ros::Time lastest_stop_time_;
  SensorAvoidLevel sensor_avoid_level_;
  AvoidLevel io_state_;
  ErrorCode err_;
  // 发送3次后不发避障超时
  char avoid_time_out_cnt_;

  ros::Publisher avoid_pub_;
  ros::Publisher point_pub_;
  ros::Publisher avoid_slow_level1_pub_;
  ros::Publisher avoid_slow_level2_pub_;
  ros::Publisher avoid_stop_pub_;

  std::map<std::string, std::vector<Point>> default_map_;
  Strategy active_strategy_;
  Strategy default_strategy_;
  // 叉车顶部激光防护
  Strategy fork_safety_strategy_;
  std::map<std::string, std::shared_ptr<FixedRatioSampler>> samplers_;
  AvoidMessageQueue msg_queue_;
};
}  // namespace cotek_avoid

#endif  // COTEK_AVOID_INCLUDE_COTEK_AVOID_AVOID_PROCESS_H_
