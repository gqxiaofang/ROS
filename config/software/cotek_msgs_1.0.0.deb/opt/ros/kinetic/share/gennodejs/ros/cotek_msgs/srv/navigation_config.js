// Auto-generated. Do not edit!

// (in-package cotek_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let deviation_limit = require('../msg/deviation_limit.js');
let avoid_ratio = require('../msg/avoid_ratio.js');
let velocity_paramer = require('../msg/velocity_paramer.js');
let straight_line_gain = require('../msg/straight_line_gain.js');
let b_spline_line_gain = require('../msg/b_spline_line_gain.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class navigation_configRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.warning_deviation = null;
      this.error_deviation = null;
      this.avoid_ratio = null;
      this.velocity_paramer = null;
      this.straight_line_gain = null;
      this.b_spline_line_gain = null;
    }
    else {
      if (initObj.hasOwnProperty('warning_deviation')) {
        this.warning_deviation = initObj.warning_deviation
      }
      else {
        this.warning_deviation = new deviation_limit();
      }
      if (initObj.hasOwnProperty('error_deviation')) {
        this.error_deviation = initObj.error_deviation
      }
      else {
        this.error_deviation = new deviation_limit();
      }
      if (initObj.hasOwnProperty('avoid_ratio')) {
        this.avoid_ratio = initObj.avoid_ratio
      }
      else {
        this.avoid_ratio = new avoid_ratio();
      }
      if (initObj.hasOwnProperty('velocity_paramer')) {
        this.velocity_paramer = initObj.velocity_paramer
      }
      else {
        this.velocity_paramer = new velocity_paramer();
      }
      if (initObj.hasOwnProperty('straight_line_gain')) {
        this.straight_line_gain = initObj.straight_line_gain
      }
      else {
        this.straight_line_gain = new straight_line_gain();
      }
      if (initObj.hasOwnProperty('b_spline_line_gain')) {
        this.b_spline_line_gain = initObj.b_spline_line_gain
      }
      else {
        this.b_spline_line_gain = new b_spline_line_gain();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type navigation_configRequest
    // Serialize message field [warning_deviation]
    bufferOffset = deviation_limit.serialize(obj.warning_deviation, buffer, bufferOffset);
    // Serialize message field [error_deviation]
    bufferOffset = deviation_limit.serialize(obj.error_deviation, buffer, bufferOffset);
    // Serialize message field [avoid_ratio]
    bufferOffset = avoid_ratio.serialize(obj.avoid_ratio, buffer, bufferOffset);
    // Serialize message field [velocity_paramer]
    bufferOffset = velocity_paramer.serialize(obj.velocity_paramer, buffer, bufferOffset);
    // Serialize message field [straight_line_gain]
    bufferOffset = straight_line_gain.serialize(obj.straight_line_gain, buffer, bufferOffset);
    // Serialize message field [b_spline_line_gain]
    bufferOffset = b_spline_line_gain.serialize(obj.b_spline_line_gain, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type navigation_configRequest
    let len;
    let data = new navigation_configRequest(null);
    // Deserialize message field [warning_deviation]
    data.warning_deviation = deviation_limit.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_deviation]
    data.error_deviation = deviation_limit.deserialize(buffer, bufferOffset);
    // Deserialize message field [avoid_ratio]
    data.avoid_ratio = avoid_ratio.deserialize(buffer, bufferOffset);
    // Deserialize message field [velocity_paramer]
    data.velocity_paramer = velocity_paramer.deserialize(buffer, bufferOffset);
    // Deserialize message field [straight_line_gain]
    data.straight_line_gain = straight_line_gain.deserialize(buffer, bufferOffset);
    // Deserialize message field [b_spline_line_gain]
    data.b_spline_line_gain = b_spline_line_gain.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 160;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/navigation_configRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fbdb36fd89b29881bc0306599a907895';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cotek_msgs/deviation_limit warning_deviation
    cotek_msgs/deviation_limit error_deviation
    cotek_msgs/avoid_ratio avoid_ratio
    cotek_msgs/velocity_paramer velocity_paramer
    cotek_msgs/straight_line_gain straight_line_gain
    cotek_msgs/b_spline_line_gain b_spline_line_gain
    
    ================================================================================
    MSG: cotek_msgs/deviation_limit
    float64 distance_deviation
    float64 angle_deviation
    ================================================================================
    MSG: cotek_msgs/avoid_ratio
    float64 slow_level1_decel_ratio
    float64 slow_level2_decel_ratio
    ================================================================================
    MSG: cotek_msgs/velocity_paramer
    float64 max_v
    float64 min_v
    float64 acceleration
    float64 deceleration
    float64 margin
    float64 inertia_gain
    ================================================================================
    MSG: cotek_msgs/straight_line_gain
    float64 laterl_error_gain
    float64 orientation_error_gain
    ================================================================================
    MSG: cotek_msgs/b_spline_line_gain
    float64 forward_laterl_error_gain
    float64 forward_orientation_error_gain
    float64 forward_los_error_gain
    float64 back_laterl_error_gain
    float64 back_orientation_error_gain
    float64 back_los_error_gain
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new navigation_configRequest(null);
    if (msg.warning_deviation !== undefined) {
      resolved.warning_deviation = deviation_limit.Resolve(msg.warning_deviation)
    }
    else {
      resolved.warning_deviation = new deviation_limit()
    }

    if (msg.error_deviation !== undefined) {
      resolved.error_deviation = deviation_limit.Resolve(msg.error_deviation)
    }
    else {
      resolved.error_deviation = new deviation_limit()
    }

    if (msg.avoid_ratio !== undefined) {
      resolved.avoid_ratio = avoid_ratio.Resolve(msg.avoid_ratio)
    }
    else {
      resolved.avoid_ratio = new avoid_ratio()
    }

    if (msg.velocity_paramer !== undefined) {
      resolved.velocity_paramer = velocity_paramer.Resolve(msg.velocity_paramer)
    }
    else {
      resolved.velocity_paramer = new velocity_paramer()
    }

    if (msg.straight_line_gain !== undefined) {
      resolved.straight_line_gain = straight_line_gain.Resolve(msg.straight_line_gain)
    }
    else {
      resolved.straight_line_gain = new straight_line_gain()
    }

    if (msg.b_spline_line_gain !== undefined) {
      resolved.b_spline_line_gain = b_spline_line_gain.Resolve(msg.b_spline_line_gain)
    }
    else {
      resolved.b_spline_line_gain = new b_spline_line_gain()
    }

    return resolved;
    }
};

class navigation_configResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type navigation_configResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type navigation_configResponse
    let len;
    let data = new navigation_configResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/navigation_configResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new navigation_configResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: navigation_configRequest,
  Response: navigation_configResponse,
  md5sum() { return 'fbdb36fd89b29881bc0306599a907895'; },
  datatype() { return 'cotek_msgs/navigation_config'; }
};
