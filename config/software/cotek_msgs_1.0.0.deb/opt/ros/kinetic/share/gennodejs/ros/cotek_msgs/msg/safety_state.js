// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class safety_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.avoid_level = null;
    }
    else {
      if (initObj.hasOwnProperty('avoid_level')) {
        this.avoid_level = initObj.avoid_level
      }
      else {
        this.avoid_level = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type safety_state
    // Serialize message field [avoid_level]
    bufferOffset = _serializer.int32(obj.avoid_level, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type safety_state
    let len;
    let data = new safety_state(null);
    // Deserialize message field [avoid_level]
    data.avoid_level = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/safety_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3f3f4782311fcaa6d54dc725a1e2791f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 avoid_level
    
    # enum class AvoidLevel : uint32_t {
    #   FREE = 0,
    #   SLOWLEVEL1 = 1,
    #   SLOWLEVEL2 = 2,
    #   STOP = 3
    # };
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new safety_state(null);
    if (msg.avoid_level !== undefined) {
      resolved.avoid_level = msg.avoid_level;
    }
    else {
      resolved.avoid_level = 0
    }

    return resolved;
    }
};

module.exports = safety_state;
