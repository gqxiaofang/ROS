// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class audio_control {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.audio_control_type = null;
      this.audio_control_level = null;
    }
    else {
      if (initObj.hasOwnProperty('audio_control_type')) {
        this.audio_control_type = initObj.audio_control_type
      }
      else {
        this.audio_control_type = 0;
      }
      if (initObj.hasOwnProperty('audio_control_level')) {
        this.audio_control_level = initObj.audio_control_level
      }
      else {
        this.audio_control_level = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type audio_control
    // Serialize message field [audio_control_type]
    bufferOffset = _serializer.uint8(obj.audio_control_type, buffer, bufferOffset);
    // Serialize message field [audio_control_level]
    bufferOffset = _serializer.uint8(obj.audio_control_level, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type audio_control
    let len;
    let data = new audio_control(null);
    // Deserialize message field [audio_control_type]
    data.audio_control_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [audio_control_level]
    data.audio_control_level = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/audio_control';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '81c19e456f47e1918a705a656e829754';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 audio_control_type
    uint8 audio_control_level
    
    # enum class AudioControlType : uint32_t {
    #   NONE = 0,
    #   BUMP_FAULT = 1,
    #   FORWARD = 2,
    #   BACKWARD = 3,
    #   OBSTACLE_WARN = 4,
    #   OBSTACLE_STOP = 5,
    #   LOW_BATTERY = 6
    # } 
    
    # audio_control_level  0 ~ 30 
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new audio_control(null);
    if (msg.audio_control_type !== undefined) {
      resolved.audio_control_type = msg.audio_control_type;
    }
    else {
      resolved.audio_control_type = 0
    }

    if (msg.audio_control_level !== undefined) {
      resolved.audio_control_level = msg.audio_control_level;
    }
    else {
      resolved.audio_control_level = 0
    }

    return resolved;
    }
};

module.exports = audio_control;
