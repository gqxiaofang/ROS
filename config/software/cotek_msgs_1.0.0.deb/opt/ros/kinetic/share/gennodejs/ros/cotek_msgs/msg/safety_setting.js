// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class safety_setting {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.avoid_map = null;
    }
    else {
      if (initObj.hasOwnProperty('avoid_map')) {
        this.avoid_map = initObj.avoid_map
      }
      else {
        this.avoid_map = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type safety_setting
    // Serialize message field [avoid_map]
    bufferOffset = _serializer.int32(obj.avoid_map, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type safety_setting
    let len;
    let data = new safety_setting(null);
    // Deserialize message field [avoid_map]
    data.avoid_map = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/safety_setting';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '74f625f83671060aa8b1ea4c8849c4c3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 avoid_map
    
    # avoid map
    #enum class AvoidMapType : int {
    #   NONE = 0,
    #   IO_PROTECT = 1,
    # // 叉车
    #   FORWARD = 31,        // 直行避障
    #   FORWARD_RIGHT = 30,  // 前进右转
    #   FORWARD_LEFT = 29,   // 前进左转
    #   BACK_RIGHT = 28,     // 后退左转
    #   BACK_LEFT = 27       // 后退右转
    
    
    #                        // 后退
    # };
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new safety_setting(null);
    if (msg.avoid_map !== undefined) {
      resolved.avoid_map = msg.avoid_map;
    }
    else {
      resolved.avoid_map = 0
    }

    return resolved;
    }
};

module.exports = safety_setting;
