
"use strict";

let test_move_feedback = require('./test_move_feedback.js');
let velocity_paramer = require('./velocity_paramer.js');
let step = require('./step.js');
let forklift_logic = require('./forklift_logic.js');
let finishing_mode = require('./finishing_mode.js');
let empty_test = require('./empty_test.js');
let pose_deviation = require('./pose_deviation.js');
let common_action_param = require('./common_action_param.js');
let motion_calibration_cmd = require('./motion_calibration_cmd.js');
let robot_pose = require('./robot_pose.js');
let motion_calibration = require('./motion_calibration.js');
let error_state = require('./error_state.js');
let straight_line_gain = require('./straight_line_gain.js');
let charging_mode = require('./charging_mode.js');
let b_spline_line_gain = require('./b_spline_line_gain.js');
let avoid_ratio = require('./avoid_ratio.js');
let reflector = require('./reflector.js');
let reflector_list = require('./reflector_list.js');
let pose_deviation_test = require('./pose_deviation_test.js');
let test_move_cmd = require('./test_move_cmd.js');
let deviation_limit = require('./deviation_limit.js');
let low_power_mode = require('./low_power_mode.js');
let heap_fork_action_param = require('./heap_fork_action_param.js');
let linde_mode_debug = require('./linde_mode_debug.js');
let track_pathActionFeedback = require('./track_pathActionFeedback.js');
let openloopResult = require('./openloopResult.js');
let agv_actionActionResult = require('./agv_actionActionResult.js');
let track_pathGoal = require('./track_pathGoal.js');
let openloopGoal = require('./openloopGoal.js');
let agv_actionResult = require('./agv_actionResult.js');
let openloopAction = require('./openloopAction.js');
let openloopActionGoal = require('./openloopActionGoal.js');
let track_pathActionResult = require('./track_pathActionResult.js');
let agv_actionActionGoal = require('./agv_actionActionGoal.js');
let openloopFeedback = require('./openloopFeedback.js');
let track_pathFeedback = require('./track_pathFeedback.js');
let track_pathResult = require('./track_pathResult.js');
let agv_actionFeedback = require('./agv_actionFeedback.js');
let openloopActionResult = require('./openloopActionResult.js');
let track_pathAction = require('./track_pathAction.js');
let agv_actionAction = require('./agv_actionAction.js');
let track_pathActionGoal = require('./track_pathActionGoal.js');
let openloopActionFeedback = require('./openloopActionFeedback.js');
let agv_actionGoal = require('./agv_actionGoal.js');
let agv_actionActionFeedback = require('./agv_actionActionFeedback.js');
let test_move_feedback = require('./test_move_feedback.js');
let velocity_paramer = require('./velocity_paramer.js');
let step = require('./step.js');
let forklift_logic = require('./forklift_logic.js');
let finishing_mode = require('./finishing_mode.js');
let empty_test = require('./empty_test.js');
let pose_deviation = require('./pose_deviation.js');
let common_action_param = require('./common_action_param.js');
let motion_calibration_cmd = require('./motion_calibration_cmd.js');
let robot_pose = require('./robot_pose.js');
let motion_calibration = require('./motion_calibration.js');
let error_state = require('./error_state.js');
let straight_line_gain = require('./straight_line_gain.js');
let charging_mode = require('./charging_mode.js');
let b_spline_line_gain = require('./b_spline_line_gain.js');
let avoid_ratio = require('./avoid_ratio.js');
let reflector = require('./reflector.js');
let reflector_list = require('./reflector_list.js');
let pose_deviation_test = require('./pose_deviation_test.js');
let test_move_cmd = require('./test_move_cmd.js');
let deviation_limit = require('./deviation_limit.js');
let low_power_mode = require('./low_power_mode.js');
let heap_fork_action_param = require('./heap_fork_action_param.js');
let linde_mode_debug = require('./linde_mode_debug.js');
let track_pathActionFeedback = require('./track_pathActionFeedback.js');
let openloopResult = require('./openloopResult.js');
let agv_actionActionResult = require('./agv_actionActionResult.js');
let track_pathGoal = require('./track_pathGoal.js');
let openloopGoal = require('./openloopGoal.js');
let agv_actionResult = require('./agv_actionResult.js');
let openloopAction = require('./openloopAction.js');
let openloopActionGoal = require('./openloopActionGoal.js');
let track_pathActionResult = require('./track_pathActionResult.js');
let agv_actionActionGoal = require('./agv_actionActionGoal.js');
let openloopFeedback = require('./openloopFeedback.js');
let track_pathFeedback = require('./track_pathFeedback.js');
let track_pathResult = require('./track_pathResult.js');
let agv_actionFeedback = require('./agv_actionFeedback.js');
let openloopActionResult = require('./openloopActionResult.js');
let track_pathAction = require('./track_pathAction.js');
let agv_actionAction = require('./agv_actionAction.js');
let track_pathActionGoal = require('./track_pathActionGoal.js');
let openloopActionFeedback = require('./openloopActionFeedback.js');
let agv_actionGoal = require('./agv_actionGoal.js');
let agv_actionActionFeedback = require('./agv_actionActionFeedback.js');

module.exports = {
  test_move_feedback: test_move_feedback,
  velocity_paramer: velocity_paramer,
  step: step,
  forklift_logic: forklift_logic,
  finishing_mode: finishing_mode,
  empty_test: empty_test,
  pose_deviation: pose_deviation,
  common_action_param: common_action_param,
  motion_calibration_cmd: motion_calibration_cmd,
  robot_pose: robot_pose,
  motion_calibration: motion_calibration,
  error_state: error_state,
  straight_line_gain: straight_line_gain,
  charging_mode: charging_mode,
  b_spline_line_gain: b_spline_line_gain,
  avoid_ratio: avoid_ratio,
  reflector: reflector,
  reflector_list: reflector_list,
  pose_deviation_test: pose_deviation_test,
  test_move_cmd: test_move_cmd,
  deviation_limit: deviation_limit,
  low_power_mode: low_power_mode,
  heap_fork_action_param: heap_fork_action_param,
  linde_mode_debug: linde_mode_debug,
  track_pathActionFeedback: track_pathActionFeedback,
  openloopResult: openloopResult,
  agv_actionActionResult: agv_actionActionResult,
  track_pathGoal: track_pathGoal,
  openloopGoal: openloopGoal,
  agv_actionResult: agv_actionResult,
  openloopAction: openloopAction,
  openloopActionGoal: openloopActionGoal,
  track_pathActionResult: track_pathActionResult,
  agv_actionActionGoal: agv_actionActionGoal,
  openloopFeedback: openloopFeedback,
  track_pathFeedback: track_pathFeedback,
  track_pathResult: track_pathResult,
  agv_actionFeedback: agv_actionFeedback,
  openloopActionResult: openloopActionResult,
  track_pathAction: track_pathAction,
  agv_actionAction: agv_actionAction,
  track_pathActionGoal: track_pathActionGoal,
  openloopActionFeedback: openloopActionFeedback,
  agv_actionGoal: agv_actionGoal,
  agv_actionActionFeedback: agv_actionActionFeedback,
  test_move_feedback: test_move_feedback,
  velocity_paramer: velocity_paramer,
  step: step,
  forklift_logic: forklift_logic,
  finishing_mode: finishing_mode,
  empty_test: empty_test,
  pose_deviation: pose_deviation,
  common_action_param: common_action_param,
  motion_calibration_cmd: motion_calibration_cmd,
  robot_pose: robot_pose,
  motion_calibration: motion_calibration,
  error_state: error_state,
  straight_line_gain: straight_line_gain,
  charging_mode: charging_mode,
  b_spline_line_gain: b_spline_line_gain,
  avoid_ratio: avoid_ratio,
  reflector: reflector,
  reflector_list: reflector_list,
  pose_deviation_test: pose_deviation_test,
  test_move_cmd: test_move_cmd,
  deviation_limit: deviation_limit,
  low_power_mode: low_power_mode,
  heap_fork_action_param: heap_fork_action_param,
  linde_mode_debug: linde_mode_debug,
  track_pathActionFeedback: track_pathActionFeedback,
  openloopResult: openloopResult,
  agv_actionActionResult: agv_actionActionResult,
  track_pathGoal: track_pathGoal,
  openloopGoal: openloopGoal,
  agv_actionResult: agv_actionResult,
  openloopAction: openloopAction,
  openloopActionGoal: openloopActionGoal,
  track_pathActionResult: track_pathActionResult,
  agv_actionActionGoal: agv_actionActionGoal,
  openloopFeedback: openloopFeedback,
  track_pathFeedback: track_pathFeedback,
  track_pathResult: track_pathResult,
  agv_actionFeedback: agv_actionFeedback,
  openloopActionResult: openloopActionResult,
  track_pathAction: track_pathAction,
  agv_actionAction: agv_actionAction,
  track_pathActionGoal: track_pathActionGoal,
  openloopActionFeedback: openloopActionFeedback,
  agv_actionGoal: agv_actionGoal,
  agv_actionActionFeedback: agv_actionActionFeedback,
};
