// Auto-generated. Do not edit!

// (in-package cotek_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let charging_mode = require('../msg/charging_mode.js');
let finishing_mode = require('../msg/finishing_mode.js');
let low_power_mode = require('../msg/low_power_mode.js');
let forklift_logic = require('../msg/forklift_logic.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class logic_configRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.agv_type = null;
      this.charging_mode = null;
      this.finishing_mode = null;
      this.low_power_mode = null;
      this.forklift_logic = null;
    }
    else {
      if (initObj.hasOwnProperty('agv_type')) {
        this.agv_type = initObj.agv_type
      }
      else {
        this.agv_type = 0;
      }
      if (initObj.hasOwnProperty('charging_mode')) {
        this.charging_mode = initObj.charging_mode
      }
      else {
        this.charging_mode = new charging_mode();
      }
      if (initObj.hasOwnProperty('finishing_mode')) {
        this.finishing_mode = initObj.finishing_mode
      }
      else {
        this.finishing_mode = new finishing_mode();
      }
      if (initObj.hasOwnProperty('low_power_mode')) {
        this.low_power_mode = initObj.low_power_mode
      }
      else {
        this.low_power_mode = new low_power_mode();
      }
      if (initObj.hasOwnProperty('forklift_logic')) {
        this.forklift_logic = initObj.forklift_logic
      }
      else {
        this.forklift_logic = new forklift_logic();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type logic_configRequest
    // Serialize message field [agv_type]
    bufferOffset = _serializer.int16(obj.agv_type, buffer, bufferOffset);
    // Serialize message field [charging_mode]
    bufferOffset = charging_mode.serialize(obj.charging_mode, buffer, bufferOffset);
    // Serialize message field [finishing_mode]
    bufferOffset = finishing_mode.serialize(obj.finishing_mode, buffer, bufferOffset);
    // Serialize message field [low_power_mode]
    bufferOffset = low_power_mode.serialize(obj.low_power_mode, buffer, bufferOffset);
    // Serialize message field [forklift_logic]
    bufferOffset = forklift_logic.serialize(obj.forklift_logic, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type logic_configRequest
    let len;
    let data = new logic_configRequest(null);
    // Deserialize message field [agv_type]
    data.agv_type = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [charging_mode]
    data.charging_mode = charging_mode.deserialize(buffer, bufferOffset);
    // Deserialize message field [finishing_mode]
    data.finishing_mode = finishing_mode.deserialize(buffer, bufferOffset);
    // Deserialize message field [low_power_mode]
    data.low_power_mode = low_power_mode.deserialize(buffer, bufferOffset);
    // Deserialize message field [forklift_logic]
    data.forklift_logic = forklift_logic.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/logic_configRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5211696c15d58c5b80f4a4ad3b55dd43';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    int16 agv_type
    cotek_msgs/charging_mode charging_mode
    cotek_msgs/finishing_mode finishing_mode
    cotek_msgs/low_power_mode low_power_mode
    cotek_msgs/forklift_logic forklift_logic
    
    ================================================================================
    MSG: cotek_msgs/charging_mode
    bool open_current_detection
    int32 end_of_the_charging_current_value
    ================================================================================
    MSG: cotek_msgs/finishing_mode
    int32 timeout
    ================================================================================
    MSG: cotek_msgs/low_power_mode
    bool open_low_power_mode
    int32 waiting_to_enter_time
    ================================================================================
    MSG: cotek_msgs/forklift_logic
    float64 fork_extend_threshold
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new logic_configRequest(null);
    if (msg.agv_type !== undefined) {
      resolved.agv_type = msg.agv_type;
    }
    else {
      resolved.agv_type = 0
    }

    if (msg.charging_mode !== undefined) {
      resolved.charging_mode = charging_mode.Resolve(msg.charging_mode)
    }
    else {
      resolved.charging_mode = new charging_mode()
    }

    if (msg.finishing_mode !== undefined) {
      resolved.finishing_mode = finishing_mode.Resolve(msg.finishing_mode)
    }
    else {
      resolved.finishing_mode = new finishing_mode()
    }

    if (msg.low_power_mode !== undefined) {
      resolved.low_power_mode = low_power_mode.Resolve(msg.low_power_mode)
    }
    else {
      resolved.low_power_mode = new low_power_mode()
    }

    if (msg.forklift_logic !== undefined) {
      resolved.forklift_logic = forklift_logic.Resolve(msg.forklift_logic)
    }
    else {
      resolved.forklift_logic = new forklift_logic()
    }

    return resolved;
    }
};

class logic_configResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type logic_configResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type logic_configResponse
    let len;
    let data = new logic_configResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/logic_configResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new logic_configResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: logic_configRequest,
  Response: logic_configResponse,
  md5sum() { return '5211696c15d58c5b80f4a4ad3b55dd43'; },
  datatype() { return 'cotek_msgs/logic_config'; }
};
