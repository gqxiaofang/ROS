// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class gyro_rion_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.omega_z = null;
      this.accelerate_x = null;
      this.angle_z = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('omega_z')) {
        this.omega_z = initObj.omega_z
      }
      else {
        this.omega_z = 0.0;
      }
      if (initObj.hasOwnProperty('accelerate_x')) {
        this.accelerate_x = initObj.accelerate_x
      }
      else {
        this.accelerate_x = 0.0;
      }
      if (initObj.hasOwnProperty('angle_z')) {
        this.angle_z = initObj.angle_z
      }
      else {
        this.angle_z = 0.0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type gyro_rion_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [omega_z]
    bufferOffset = _serializer.float32(obj.omega_z, buffer, bufferOffset);
    // Serialize message field [accelerate_x]
    bufferOffset = _serializer.float32(obj.accelerate_x, buffer, bufferOffset);
    // Serialize message field [angle_z]
    bufferOffset = _serializer.float32(obj.angle_z, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.uint16(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type gyro_rion_feedback
    let len;
    let data = new gyro_rion_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [omega_z]
    data.omega_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [accelerate_x]
    data.accelerate_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angle_z]
    data.angle_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/gyro_rion_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '27ec773464a0be212b87b06e6e564b2e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 时间戳
    uint32 time_stamp
    # 驱动数据
    float32 omega_z
    float32 accelerate_x
    float32 angle_z
    # 错误码
    uint16 error_code
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new gyro_rion_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.omega_z !== undefined) {
      resolved.omega_z = msg.omega_z;
    }
    else {
      resolved.omega_z = 0.0
    }

    if (msg.accelerate_x !== undefined) {
      resolved.accelerate_x = msg.accelerate_x;
    }
    else {
      resolved.accelerate_x = 0.0
    }

    if (msg.angle_z !== undefined) {
      resolved.angle_z = msg.angle_z;
    }
    else {
      resolved.angle_z = 0.0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = gyro_rion_feedback;
