// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class pose_deviation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.goal_pose_x = null;
      this.goal_pose_y = null;
      this.goal_theta = null;
      this.pose_x = null;
      this.pose_y = null;
      this.pose_theta = null;
      this.delta_y = null;
      this.delta_theta = null;
      this.delta_theta1 = null;
      this.delta_y_average = null;
      this.delta_theta_average = null;
    }
    else {
      if (initObj.hasOwnProperty('goal_pose_x')) {
        this.goal_pose_x = initObj.goal_pose_x
      }
      else {
        this.goal_pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('goal_pose_y')) {
        this.goal_pose_y = initObj.goal_pose_y
      }
      else {
        this.goal_pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('goal_theta')) {
        this.goal_theta = initObj.goal_theta
      }
      else {
        this.goal_theta = 0.0;
      }
      if (initObj.hasOwnProperty('pose_x')) {
        this.pose_x = initObj.pose_x
      }
      else {
        this.pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('pose_y')) {
        this.pose_y = initObj.pose_y
      }
      else {
        this.pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('pose_theta')) {
        this.pose_theta = initObj.pose_theta
      }
      else {
        this.pose_theta = 0.0;
      }
      if (initObj.hasOwnProperty('delta_y')) {
        this.delta_y = initObj.delta_y
      }
      else {
        this.delta_y = 0.0;
      }
      if (initObj.hasOwnProperty('delta_theta')) {
        this.delta_theta = initObj.delta_theta
      }
      else {
        this.delta_theta = 0.0;
      }
      if (initObj.hasOwnProperty('delta_theta1')) {
        this.delta_theta1 = initObj.delta_theta1
      }
      else {
        this.delta_theta1 = 0.0;
      }
      if (initObj.hasOwnProperty('delta_y_average')) {
        this.delta_y_average = initObj.delta_y_average
      }
      else {
        this.delta_y_average = 0.0;
      }
      if (initObj.hasOwnProperty('delta_theta_average')) {
        this.delta_theta_average = initObj.delta_theta_average
      }
      else {
        this.delta_theta_average = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type pose_deviation
    // Serialize message field [goal_pose_x]
    bufferOffset = _serializer.float32(obj.goal_pose_x, buffer, bufferOffset);
    // Serialize message field [goal_pose_y]
    bufferOffset = _serializer.float32(obj.goal_pose_y, buffer, bufferOffset);
    // Serialize message field [goal_theta]
    bufferOffset = _serializer.float32(obj.goal_theta, buffer, bufferOffset);
    // Serialize message field [pose_x]
    bufferOffset = _serializer.float32(obj.pose_x, buffer, bufferOffset);
    // Serialize message field [pose_y]
    bufferOffset = _serializer.float32(obj.pose_y, buffer, bufferOffset);
    // Serialize message field [pose_theta]
    bufferOffset = _serializer.float32(obj.pose_theta, buffer, bufferOffset);
    // Serialize message field [delta_y]
    bufferOffset = _serializer.float32(obj.delta_y, buffer, bufferOffset);
    // Serialize message field [delta_theta]
    bufferOffset = _serializer.float32(obj.delta_theta, buffer, bufferOffset);
    // Serialize message field [delta_theta1]
    bufferOffset = _serializer.float32(obj.delta_theta1, buffer, bufferOffset);
    // Serialize message field [delta_y_average]
    bufferOffset = _serializer.float32(obj.delta_y_average, buffer, bufferOffset);
    // Serialize message field [delta_theta_average]
    bufferOffset = _serializer.float32(obj.delta_theta_average, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type pose_deviation
    let len;
    let data = new pose_deviation(null);
    // Deserialize message field [goal_pose_x]
    data.goal_pose_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [goal_pose_y]
    data.goal_pose_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [goal_theta]
    data.goal_theta = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_x]
    data.pose_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_y]
    data.pose_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pose_theta]
    data.pose_theta = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [delta_y]
    data.delta_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [delta_theta]
    data.delta_theta = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [delta_theta1]
    data.delta_theta1 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [delta_y_average]
    data.delta_y_average = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [delta_theta_average]
    data.delta_theta_average = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/pose_deviation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b26bed7e6060d032dcbe63c460826e43';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 goal_pose_x
    float32 goal_pose_y
    float32 goal_theta
    float32 pose_x
    float32 pose_y
    float32 pose_theta
    float32 delta_y
    float32 delta_theta
    float32 delta_theta1
    float32 delta_y_average
    float32 delta_theta_average
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new pose_deviation(null);
    if (msg.goal_pose_x !== undefined) {
      resolved.goal_pose_x = msg.goal_pose_x;
    }
    else {
      resolved.goal_pose_x = 0.0
    }

    if (msg.goal_pose_y !== undefined) {
      resolved.goal_pose_y = msg.goal_pose_y;
    }
    else {
      resolved.goal_pose_y = 0.0
    }

    if (msg.goal_theta !== undefined) {
      resolved.goal_theta = msg.goal_theta;
    }
    else {
      resolved.goal_theta = 0.0
    }

    if (msg.pose_x !== undefined) {
      resolved.pose_x = msg.pose_x;
    }
    else {
      resolved.pose_x = 0.0
    }

    if (msg.pose_y !== undefined) {
      resolved.pose_y = msg.pose_y;
    }
    else {
      resolved.pose_y = 0.0
    }

    if (msg.pose_theta !== undefined) {
      resolved.pose_theta = msg.pose_theta;
    }
    else {
      resolved.pose_theta = 0.0
    }

    if (msg.delta_y !== undefined) {
      resolved.delta_y = msg.delta_y;
    }
    else {
      resolved.delta_y = 0.0
    }

    if (msg.delta_theta !== undefined) {
      resolved.delta_theta = msg.delta_theta;
    }
    else {
      resolved.delta_theta = 0.0
    }

    if (msg.delta_theta1 !== undefined) {
      resolved.delta_theta1 = msg.delta_theta1;
    }
    else {
      resolved.delta_theta1 = 0.0
    }

    if (msg.delta_y_average !== undefined) {
      resolved.delta_y_average = msg.delta_y_average;
    }
    else {
      resolved.delta_y_average = 0.0
    }

    if (msg.delta_theta_average !== undefined) {
      resolved.delta_theta_average = msg.delta_theta_average;
    }
    else {
      resolved.delta_theta_average = 0.0
    }

    return resolved;
    }
};

module.exports = pose_deviation;
