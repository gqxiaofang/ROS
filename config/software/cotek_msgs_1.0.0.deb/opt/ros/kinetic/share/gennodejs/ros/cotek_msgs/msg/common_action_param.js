// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class common_action_param {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.agv_type = null;
      this.enable_loacl_debug = null;
      this.enable_timeout = null;
      this.check_pallet = null;
      this.action_timeout_value = null;
      this.control_period = null;
    }
    else {
      if (initObj.hasOwnProperty('agv_type')) {
        this.agv_type = initObj.agv_type
      }
      else {
        this.agv_type = 0;
      }
      if (initObj.hasOwnProperty('enable_loacl_debug')) {
        this.enable_loacl_debug = initObj.enable_loacl_debug
      }
      else {
        this.enable_loacl_debug = false;
      }
      if (initObj.hasOwnProperty('enable_timeout')) {
        this.enable_timeout = initObj.enable_timeout
      }
      else {
        this.enable_timeout = false;
      }
      if (initObj.hasOwnProperty('check_pallet')) {
        this.check_pallet = initObj.check_pallet
      }
      else {
        this.check_pallet = false;
      }
      if (initObj.hasOwnProperty('action_timeout_value')) {
        this.action_timeout_value = initObj.action_timeout_value
      }
      else {
        this.action_timeout_value = 0.0;
      }
      if (initObj.hasOwnProperty('control_period')) {
        this.control_period = initObj.control_period
      }
      else {
        this.control_period = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type common_action_param
    // Serialize message field [agv_type]
    bufferOffset = _serializer.uint16(obj.agv_type, buffer, bufferOffset);
    // Serialize message field [enable_loacl_debug]
    bufferOffset = _serializer.bool(obj.enable_loacl_debug, buffer, bufferOffset);
    // Serialize message field [enable_timeout]
    bufferOffset = _serializer.bool(obj.enable_timeout, buffer, bufferOffset);
    // Serialize message field [check_pallet]
    bufferOffset = _serializer.bool(obj.check_pallet, buffer, bufferOffset);
    // Serialize message field [action_timeout_value]
    bufferOffset = _serializer.float64(obj.action_timeout_value, buffer, bufferOffset);
    // Serialize message field [control_period]
    bufferOffset = _serializer.float64(obj.control_period, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type common_action_param
    let len;
    let data = new common_action_param(null);
    // Deserialize message field [agv_type]
    data.agv_type = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [enable_loacl_debug]
    data.enable_loacl_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [enable_timeout]
    data.enable_timeout = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [check_pallet]
    data.check_pallet = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [action_timeout_value]
    data.action_timeout_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [control_period]
    data.control_period = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/common_action_param';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8264231638e1b81b09009b9f1cc13a40';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint16 agv_type
    bool enable_loacl_debug
    bool enable_timeout
    bool check_pallet
    float64 action_timeout_value
    float64 control_period
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new common_action_param(null);
    if (msg.agv_type !== undefined) {
      resolved.agv_type = msg.agv_type;
    }
    else {
      resolved.agv_type = 0
    }

    if (msg.enable_loacl_debug !== undefined) {
      resolved.enable_loacl_debug = msg.enable_loacl_debug;
    }
    else {
      resolved.enable_loacl_debug = false
    }

    if (msg.enable_timeout !== undefined) {
      resolved.enable_timeout = msg.enable_timeout;
    }
    else {
      resolved.enable_timeout = false
    }

    if (msg.check_pallet !== undefined) {
      resolved.check_pallet = msg.check_pallet;
    }
    else {
      resolved.check_pallet = false
    }

    if (msg.action_timeout_value !== undefined) {
      resolved.action_timeout_value = msg.action_timeout_value;
    }
    else {
      resolved.action_timeout_value = 0.0
    }

    if (msg.control_period !== undefined) {
      resolved.control_period = msg.control_period;
    }
    else {
      resolved.control_period = 0.0
    }

    return resolved;
    }
};

module.exports = common_action_param;
