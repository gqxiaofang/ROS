// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class b_spline_line_gain {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.forward_laterl_error_gain = null;
      this.forward_orientation_error_gain = null;
      this.forward_los_error_gain = null;
      this.back_laterl_error_gain = null;
      this.back_orientation_error_gain = null;
      this.back_los_error_gain = null;
    }
    else {
      if (initObj.hasOwnProperty('forward_laterl_error_gain')) {
        this.forward_laterl_error_gain = initObj.forward_laterl_error_gain
      }
      else {
        this.forward_laterl_error_gain = 0.0;
      }
      if (initObj.hasOwnProperty('forward_orientation_error_gain')) {
        this.forward_orientation_error_gain = initObj.forward_orientation_error_gain
      }
      else {
        this.forward_orientation_error_gain = 0.0;
      }
      if (initObj.hasOwnProperty('forward_los_error_gain')) {
        this.forward_los_error_gain = initObj.forward_los_error_gain
      }
      else {
        this.forward_los_error_gain = 0.0;
      }
      if (initObj.hasOwnProperty('back_laterl_error_gain')) {
        this.back_laterl_error_gain = initObj.back_laterl_error_gain
      }
      else {
        this.back_laterl_error_gain = 0.0;
      }
      if (initObj.hasOwnProperty('back_orientation_error_gain')) {
        this.back_orientation_error_gain = initObj.back_orientation_error_gain
      }
      else {
        this.back_orientation_error_gain = 0.0;
      }
      if (initObj.hasOwnProperty('back_los_error_gain')) {
        this.back_los_error_gain = initObj.back_los_error_gain
      }
      else {
        this.back_los_error_gain = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type b_spline_line_gain
    // Serialize message field [forward_laterl_error_gain]
    bufferOffset = _serializer.float64(obj.forward_laterl_error_gain, buffer, bufferOffset);
    // Serialize message field [forward_orientation_error_gain]
    bufferOffset = _serializer.float64(obj.forward_orientation_error_gain, buffer, bufferOffset);
    // Serialize message field [forward_los_error_gain]
    bufferOffset = _serializer.float64(obj.forward_los_error_gain, buffer, bufferOffset);
    // Serialize message field [back_laterl_error_gain]
    bufferOffset = _serializer.float64(obj.back_laterl_error_gain, buffer, bufferOffset);
    // Serialize message field [back_orientation_error_gain]
    bufferOffset = _serializer.float64(obj.back_orientation_error_gain, buffer, bufferOffset);
    // Serialize message field [back_los_error_gain]
    bufferOffset = _serializer.float64(obj.back_los_error_gain, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type b_spline_line_gain
    let len;
    let data = new b_spline_line_gain(null);
    // Deserialize message field [forward_laterl_error_gain]
    data.forward_laterl_error_gain = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [forward_orientation_error_gain]
    data.forward_orientation_error_gain = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [forward_los_error_gain]
    data.forward_los_error_gain = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [back_laterl_error_gain]
    data.back_laterl_error_gain = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [back_orientation_error_gain]
    data.back_orientation_error_gain = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [back_los_error_gain]
    data.back_los_error_gain = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/b_spline_line_gain';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3bb121908266448dff656e8dc07106f2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 forward_laterl_error_gain
    float64 forward_orientation_error_gain
    float64 forward_los_error_gain
    float64 back_laterl_error_gain
    float64 back_orientation_error_gain
    float64 back_los_error_gain
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new b_spline_line_gain(null);
    if (msg.forward_laterl_error_gain !== undefined) {
      resolved.forward_laterl_error_gain = msg.forward_laterl_error_gain;
    }
    else {
      resolved.forward_laterl_error_gain = 0.0
    }

    if (msg.forward_orientation_error_gain !== undefined) {
      resolved.forward_orientation_error_gain = msg.forward_orientation_error_gain;
    }
    else {
      resolved.forward_orientation_error_gain = 0.0
    }

    if (msg.forward_los_error_gain !== undefined) {
      resolved.forward_los_error_gain = msg.forward_los_error_gain;
    }
    else {
      resolved.forward_los_error_gain = 0.0
    }

    if (msg.back_laterl_error_gain !== undefined) {
      resolved.back_laterl_error_gain = msg.back_laterl_error_gain;
    }
    else {
      resolved.back_laterl_error_gain = 0.0
    }

    if (msg.back_orientation_error_gain !== undefined) {
      resolved.back_orientation_error_gain = msg.back_orientation_error_gain;
    }
    else {
      resolved.back_orientation_error_gain = 0.0
    }

    if (msg.back_los_error_gain !== undefined) {
      resolved.back_los_error_gain = msg.back_los_error_gain;
    }
    else {
      resolved.back_los_error_gain = 0.0
    }

    return resolved;
    }
};

module.exports = b_spline_line_gain;
