// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let error_state = require('./error_state.js');

//-----------------------------------------------------------

class fault_report {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.level = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('level')) {
        this.level = initObj.level
      }
      else {
        this.level = 0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type fault_report
    // Serialize message field [level]
    bufferOffset = _serializer.uint16(obj.level, buffer, bufferOffset);
    // Serialize message field [error_code]
    // Serialize the length for message field [error_code]
    bufferOffset = _serializer.uint32(obj.error_code.length, buffer, bufferOffset);
    obj.error_code.forEach((val) => {
      bufferOffset = error_state.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type fault_report
    let len;
    let data = new fault_report(null);
    // Deserialize message field [level]
    data.level = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [error_code]
    // Deserialize array length for message field [error_code]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.error_code = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.error_code[i] = error_state.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.error_code.forEach((val) => {
      length += error_state.getMessageSize(val);
    });
    return length + 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/fault_report';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e142942ca37d8f89990cbe4b40fabe44';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint16 level
    cotek_msgs/error_state[] error_code
    ================================================================================
    MSG: cotek_msgs/error_state
    string id
    int32 error_code
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new fault_report(null);
    if (msg.level !== undefined) {
      resolved.level = msg.level;
    }
    else {
      resolved.level = 0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = new Array(msg.error_code.length);
      for (let i = 0; i < resolved.error_code.length; ++i) {
        resolved.error_code[i] = error_state.Resolve(msg.error_code[i]);
      }
    }
    else {
      resolved.error_code = []
    }

    return resolved;
    }
};

module.exports = fault_report;
