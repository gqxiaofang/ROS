// Auto-generated. Do not edit!

// (in-package cotek_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class CalibrationServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CalibrationServiceRequest
    // Serialize message field [status]
    bufferOffset = _serializer.uint32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CalibrationServiceRequest
    let len;
    let data = new CalibrationServiceRequest(null);
    // Deserialize message field [status]
    data.status = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/CalibrationServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '83a57a727be8ba31cb31383c323b93c8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    uint32 status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CalibrationServiceRequest(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

class CalibrationServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.reflector_count = null;
    }
    else {
      if (initObj.hasOwnProperty('reflector_count')) {
        this.reflector_count = initObj.reflector_count
      }
      else {
        this.reflector_count = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CalibrationServiceResponse
    // Serialize message field [reflector_count]
    bufferOffset = _serializer.uint32(obj.reflector_count, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CalibrationServiceResponse
    let len;
    let data = new CalibrationServiceResponse(null);
    // Deserialize message field [reflector_count]
    data.reflector_count = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/CalibrationServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ac014c74b4c979940abb39e6e6219f7d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    uint32 reflector_count
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CalibrationServiceResponse(null);
    if (msg.reflector_count !== undefined) {
      resolved.reflector_count = msg.reflector_count;
    }
    else {
      resolved.reflector_count = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: CalibrationServiceRequest,
  Response: CalibrationServiceResponse,
  md5sum() { return '382d6e25f52072120c224d2a08cf88e3'; },
  datatype() { return 'cotek_msgs/CalibrationService'; }
};
