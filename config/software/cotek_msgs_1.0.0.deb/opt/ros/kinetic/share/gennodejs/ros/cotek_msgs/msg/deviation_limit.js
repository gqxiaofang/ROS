// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class deviation_limit {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.distance_deviation = null;
      this.angle_deviation = null;
    }
    else {
      if (initObj.hasOwnProperty('distance_deviation')) {
        this.distance_deviation = initObj.distance_deviation
      }
      else {
        this.distance_deviation = 0.0;
      }
      if (initObj.hasOwnProperty('angle_deviation')) {
        this.angle_deviation = initObj.angle_deviation
      }
      else {
        this.angle_deviation = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type deviation_limit
    // Serialize message field [distance_deviation]
    bufferOffset = _serializer.float64(obj.distance_deviation, buffer, bufferOffset);
    // Serialize message field [angle_deviation]
    bufferOffset = _serializer.float64(obj.angle_deviation, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type deviation_limit
    let len;
    let data = new deviation_limit(null);
    // Deserialize message field [distance_deviation]
    data.distance_deviation = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [angle_deviation]
    data.angle_deviation = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/deviation_limit';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '123615bbdf59c7a6173b32ad7ae2af6a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 distance_deviation
    float64 angle_deviation
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new deviation_limit(null);
    if (msg.distance_deviation !== undefined) {
      resolved.distance_deviation = msg.distance_deviation;
    }
    else {
      resolved.distance_deviation = 0.0
    }

    if (msg.angle_deviation !== undefined) {
      resolved.angle_deviation = msg.angle_deviation;
    }
    else {
      resolved.angle_deviation = 0.0
    }

    return resolved;
    }
};

module.exports = deviation_limit;
