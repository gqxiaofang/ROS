// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class heap_fork_action_param {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.heap_liftload_height = null;
      this.heap_unload_height = null;
      this.heap_height_margin = null;
    }
    else {
      if (initObj.hasOwnProperty('heap_liftload_height')) {
        this.heap_liftload_height = initObj.heap_liftload_height
      }
      else {
        this.heap_liftload_height = 0;
      }
      if (initObj.hasOwnProperty('heap_unload_height')) {
        this.heap_unload_height = initObj.heap_unload_height
      }
      else {
        this.heap_unload_height = 0;
      }
      if (initObj.hasOwnProperty('heap_height_margin')) {
        this.heap_height_margin = initObj.heap_height_margin
      }
      else {
        this.heap_height_margin = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type heap_fork_action_param
    // Serialize message field [heap_liftload_height]
    bufferOffset = _serializer.int32(obj.heap_liftload_height, buffer, bufferOffset);
    // Serialize message field [heap_unload_height]
    bufferOffset = _serializer.int32(obj.heap_unload_height, buffer, bufferOffset);
    // Serialize message field [heap_height_margin]
    bufferOffset = _serializer.int32(obj.heap_height_margin, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type heap_fork_action_param
    let len;
    let data = new heap_fork_action_param(null);
    // Deserialize message field [heap_liftload_height]
    data.heap_liftload_height = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [heap_unload_height]
    data.heap_unload_height = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [heap_height_margin]
    data.heap_height_margin = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/heap_fork_action_param';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2c42199c26ae768ad48b395fba64605c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 heap_liftload_height
    int32 heap_unload_height
    int32 heap_height_margin
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new heap_fork_action_param(null);
    if (msg.heap_liftload_height !== undefined) {
      resolved.heap_liftload_height = msg.heap_liftload_height;
    }
    else {
      resolved.heap_liftload_height = 0
    }

    if (msg.heap_unload_height !== undefined) {
      resolved.heap_unload_height = msg.heap_unload_height;
    }
    else {
      resolved.heap_unload_height = 0
    }

    if (msg.heap_height_margin !== undefined) {
      resolved.heap_height_margin = msg.heap_height_margin;
    }
    else {
      resolved.heap_height_margin = 0
    }

    return resolved;
    }
};

module.exports = heap_fork_action_param;
