// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class charging_mode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.open_current_detection = null;
      this.end_of_the_charging_current_value = null;
    }
    else {
      if (initObj.hasOwnProperty('open_current_detection')) {
        this.open_current_detection = initObj.open_current_detection
      }
      else {
        this.open_current_detection = false;
      }
      if (initObj.hasOwnProperty('end_of_the_charging_current_value')) {
        this.end_of_the_charging_current_value = initObj.end_of_the_charging_current_value
      }
      else {
        this.end_of_the_charging_current_value = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type charging_mode
    // Serialize message field [open_current_detection]
    bufferOffset = _serializer.bool(obj.open_current_detection, buffer, bufferOffset);
    // Serialize message field [end_of_the_charging_current_value]
    bufferOffset = _serializer.int32(obj.end_of_the_charging_current_value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type charging_mode
    let len;
    let data = new charging_mode(null);
    // Deserialize message field [open_current_detection]
    data.open_current_detection = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [end_of_the_charging_current_value]
    data.end_of_the_charging_current_value = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/charging_mode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '49ef132031bb59387dbdfda1dff3ae7b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool open_current_detection
    int32 end_of_the_charging_current_value
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new charging_mode(null);
    if (msg.open_current_detection !== undefined) {
      resolved.open_current_detection = msg.open_current_detection;
    }
    else {
      resolved.open_current_detection = false
    }

    if (msg.end_of_the_charging_current_value !== undefined) {
      resolved.end_of_the_charging_current_value = msg.end_of_the_charging_current_value;
    }
    else {
      resolved.end_of_the_charging_current_value = 0
    }

    return resolved;
    }
};

module.exports = charging_mode;
