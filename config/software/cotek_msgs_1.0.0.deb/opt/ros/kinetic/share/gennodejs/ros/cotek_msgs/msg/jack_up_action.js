// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class jack_up_action {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.left_motor_enable = null;
      this.right_motor_enable = null;
      this.lift_motor_enable = null;
      this.rotate_motor_enable = null;
      this.lift_v = null;
      this.rotate_w = null;
      this.three_color_led_type = null;
      this.audio_control_type = null;
      this.audio_control_level = null;
      this.atomic_action_type = null;
      this.atomic_action_value = null;
    }
    else {
      if (initObj.hasOwnProperty('left_motor_enable')) {
        this.left_motor_enable = initObj.left_motor_enable
      }
      else {
        this.left_motor_enable = false;
      }
      if (initObj.hasOwnProperty('right_motor_enable')) {
        this.right_motor_enable = initObj.right_motor_enable
      }
      else {
        this.right_motor_enable = false;
      }
      if (initObj.hasOwnProperty('lift_motor_enable')) {
        this.lift_motor_enable = initObj.lift_motor_enable
      }
      else {
        this.lift_motor_enable = false;
      }
      if (initObj.hasOwnProperty('rotate_motor_enable')) {
        this.rotate_motor_enable = initObj.rotate_motor_enable
      }
      else {
        this.rotate_motor_enable = false;
      }
      if (initObj.hasOwnProperty('lift_v')) {
        this.lift_v = initObj.lift_v
      }
      else {
        this.lift_v = 0.0;
      }
      if (initObj.hasOwnProperty('rotate_w')) {
        this.rotate_w = initObj.rotate_w
      }
      else {
        this.rotate_w = 0.0;
      }
      if (initObj.hasOwnProperty('three_color_led_type')) {
        this.three_color_led_type = initObj.three_color_led_type
      }
      else {
        this.three_color_led_type = 0;
      }
      if (initObj.hasOwnProperty('audio_control_type')) {
        this.audio_control_type = initObj.audio_control_type
      }
      else {
        this.audio_control_type = 0;
      }
      if (initObj.hasOwnProperty('audio_control_level')) {
        this.audio_control_level = initObj.audio_control_level
      }
      else {
        this.audio_control_level = 0;
      }
      if (initObj.hasOwnProperty('atomic_action_type')) {
        this.atomic_action_type = initObj.atomic_action_type
      }
      else {
        this.atomic_action_type = 0;
      }
      if (initObj.hasOwnProperty('atomic_action_value')) {
        this.atomic_action_value = initObj.atomic_action_value
      }
      else {
        this.atomic_action_value = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type jack_up_action
    // Serialize message field [left_motor_enable]
    bufferOffset = _serializer.bool(obj.left_motor_enable, buffer, bufferOffset);
    // Serialize message field [right_motor_enable]
    bufferOffset = _serializer.bool(obj.right_motor_enable, buffer, bufferOffset);
    // Serialize message field [lift_motor_enable]
    bufferOffset = _serializer.bool(obj.lift_motor_enable, buffer, bufferOffset);
    // Serialize message field [rotate_motor_enable]
    bufferOffset = _serializer.bool(obj.rotate_motor_enable, buffer, bufferOffset);
    // Serialize message field [lift_v]
    bufferOffset = _serializer.float64(obj.lift_v, buffer, bufferOffset);
    // Serialize message field [rotate_w]
    bufferOffset = _serializer.float64(obj.rotate_w, buffer, bufferOffset);
    // Serialize message field [three_color_led_type]
    bufferOffset = _serializer.uint8(obj.three_color_led_type, buffer, bufferOffset);
    // Serialize message field [audio_control_type]
    bufferOffset = _serializer.int32(obj.audio_control_type, buffer, bufferOffset);
    // Serialize message field [audio_control_level]
    bufferOffset = _serializer.int32(obj.audio_control_level, buffer, bufferOffset);
    // Serialize message field [atomic_action_type]
    bufferOffset = _serializer.int32(obj.atomic_action_type, buffer, bufferOffset);
    // Serialize message field [atomic_action_value]
    bufferOffset = _serializer.float64(obj.atomic_action_value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type jack_up_action
    let len;
    let data = new jack_up_action(null);
    // Deserialize message field [left_motor_enable]
    data.left_motor_enable = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [right_motor_enable]
    data.right_motor_enable = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [lift_motor_enable]
    data.lift_motor_enable = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [rotate_motor_enable]
    data.rotate_motor_enable = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [lift_v]
    data.lift_v = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rotate_w]
    data.rotate_w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [three_color_led_type]
    data.three_color_led_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [audio_control_type]
    data.audio_control_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [audio_control_level]
    data.audio_control_level = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [atomic_action_type]
    data.atomic_action_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [atomic_action_value]
    data.atomic_action_value = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 41;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/jack_up_action';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f568237c3602121e3e219a1c1b7ce7a4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool left_motor_enable
    bool right_motor_enable
    bool lift_motor_enable
    bool rotate_motor_enable
    float64 lift_v
    float64 rotate_w
    uint8 three_color_led_type
    int32 audio_control_type
    int32 audio_control_level
    int32 atomic_action_type
    float64 atomic_action_value
    
    # 三色灯控制类型
    # enum class ThreeColorLedType : uint32_t {
    #     GREEN_ON                 = 0x00000100,
    #     YELLOW_ON                = 0x00000010,
    #     RED_ON                   = 0x00000001,
        
    #     YELLOW_GREEN_ON          = 0x00000110,
    #     RED_YELLOW_ON            = 0x00000011,
    #     RED_GREEN_ON             = 0x00000101,
    #     RED_YELLOW_GREEN_ON      = 0x00000111,
        
    #     RED_TWINKLE              = 0x10000001,
    #     YELLOW_TWINKLE           = 0x10000010,
    #     GREEN_TWINKLE            = 0x10000100,
        
    #     YELLOW_GREEN_TWINKLE     = 0x10000110,
    #     RED_YELLOW_TWINKLE       = 0x10000011,
    #     RED_GREEN_TWINKLE        = 0x10000101,
    #     RED_YELLOW_GREEN_TWINKLE = 0x10000111,
        
    #     YELLOW_GREEN_SWITCH      = 0x20000110,
    #     RED_YELLOW_SWITCH        = 0x20000011,
    #     RED_GREEN_SWITCH         = 0x20000101,
        
    #     LIGHT_ALL_ON             = 0x00000111,
    #     LIGHT_OFF                = 0x00000000,
    # }
    
    # enum class AudioControlType : uint32_t {
    #   STOP = 0,
    #   BUMP_FAULT = 1,
    #   FORWARD = 2,
    #   BACKWARD = 3,
    #   OBSTACLE_WARN = 4,
    #   OBSTACLE_STOP = 5,
    #   LOW_BATTERY = 6
    # }
    
    # enum class AtomicActionType : uint32_t {
    #   REST = 0,
    #   LOW_POWER = 2,         // 低功耗模式  (operation_value 填0(关), 1(开))
    #   CHARGE = 3,            // 自动充电继电器 (operation_value 填0(关), 1(开))
    #   ROATE_MOTOR_BREAK = 4, // 旋转电机报闸 (operation_value 填0(关), 1(开))
    # };
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new jack_up_action(null);
    if (msg.left_motor_enable !== undefined) {
      resolved.left_motor_enable = msg.left_motor_enable;
    }
    else {
      resolved.left_motor_enable = false
    }

    if (msg.right_motor_enable !== undefined) {
      resolved.right_motor_enable = msg.right_motor_enable;
    }
    else {
      resolved.right_motor_enable = false
    }

    if (msg.lift_motor_enable !== undefined) {
      resolved.lift_motor_enable = msg.lift_motor_enable;
    }
    else {
      resolved.lift_motor_enable = false
    }

    if (msg.rotate_motor_enable !== undefined) {
      resolved.rotate_motor_enable = msg.rotate_motor_enable;
    }
    else {
      resolved.rotate_motor_enable = false
    }

    if (msg.lift_v !== undefined) {
      resolved.lift_v = msg.lift_v;
    }
    else {
      resolved.lift_v = 0.0
    }

    if (msg.rotate_w !== undefined) {
      resolved.rotate_w = msg.rotate_w;
    }
    else {
      resolved.rotate_w = 0.0
    }

    if (msg.three_color_led_type !== undefined) {
      resolved.three_color_led_type = msg.three_color_led_type;
    }
    else {
      resolved.three_color_led_type = 0
    }

    if (msg.audio_control_type !== undefined) {
      resolved.audio_control_type = msg.audio_control_type;
    }
    else {
      resolved.audio_control_type = 0
    }

    if (msg.audio_control_level !== undefined) {
      resolved.audio_control_level = msg.audio_control_level;
    }
    else {
      resolved.audio_control_level = 0
    }

    if (msg.atomic_action_type !== undefined) {
      resolved.atomic_action_type = msg.atomic_action_type;
    }
    else {
      resolved.atomic_action_type = 0
    }

    if (msg.atomic_action_value !== undefined) {
      resolved.atomic_action_value = msg.atomic_action_value;
    }
    else {
      resolved.atomic_action_value = 0.0
    }

    return resolved;
    }
};

module.exports = jack_up_action;
