// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class track_pathGoal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.navi_type = null;
      this.motion_type = null;
      this.next_path_type = null;
      this.max_speed = null;
      this.target_speed = null;
      this.end_id = null;
      this.end_x = null;
      this.end_y = null;
      this.end_yaw = null;
      this.c1_x = null;
      this.c1_y = null;
      this.c2_x = null;
      this.c2_y = null;
    }
    else {
      if (initObj.hasOwnProperty('navi_type')) {
        this.navi_type = initObj.navi_type
      }
      else {
        this.navi_type = 0;
      }
      if (initObj.hasOwnProperty('motion_type')) {
        this.motion_type = initObj.motion_type
      }
      else {
        this.motion_type = 0;
      }
      if (initObj.hasOwnProperty('next_path_type')) {
        this.next_path_type = initObj.next_path_type
      }
      else {
        this.next_path_type = 0;
      }
      if (initObj.hasOwnProperty('max_speed')) {
        this.max_speed = initObj.max_speed
      }
      else {
        this.max_speed = 0.0;
      }
      if (initObj.hasOwnProperty('target_speed')) {
        this.target_speed = initObj.target_speed
      }
      else {
        this.target_speed = 0.0;
      }
      if (initObj.hasOwnProperty('end_id')) {
        this.end_id = initObj.end_id
      }
      else {
        this.end_id = 0;
      }
      if (initObj.hasOwnProperty('end_x')) {
        this.end_x = initObj.end_x
      }
      else {
        this.end_x = 0.0;
      }
      if (initObj.hasOwnProperty('end_y')) {
        this.end_y = initObj.end_y
      }
      else {
        this.end_y = 0.0;
      }
      if (initObj.hasOwnProperty('end_yaw')) {
        this.end_yaw = initObj.end_yaw
      }
      else {
        this.end_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('c1_x')) {
        this.c1_x = initObj.c1_x
      }
      else {
        this.c1_x = 0.0;
      }
      if (initObj.hasOwnProperty('c1_y')) {
        this.c1_y = initObj.c1_y
      }
      else {
        this.c1_y = 0.0;
      }
      if (initObj.hasOwnProperty('c2_x')) {
        this.c2_x = initObj.c2_x
      }
      else {
        this.c2_x = 0.0;
      }
      if (initObj.hasOwnProperty('c2_y')) {
        this.c2_y = initObj.c2_y
      }
      else {
        this.c2_y = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type track_pathGoal
    // Serialize message field [navi_type]
    bufferOffset = _serializer.uint32(obj.navi_type, buffer, bufferOffset);
    // Serialize message field [motion_type]
    bufferOffset = _serializer.uint32(obj.motion_type, buffer, bufferOffset);
    // Serialize message field [next_path_type]
    bufferOffset = _serializer.uint32(obj.next_path_type, buffer, bufferOffset);
    // Serialize message field [max_speed]
    bufferOffset = _serializer.float64(obj.max_speed, buffer, bufferOffset);
    // Serialize message field [target_speed]
    bufferOffset = _serializer.float64(obj.target_speed, buffer, bufferOffset);
    // Serialize message field [end_id]
    bufferOffset = _serializer.uint32(obj.end_id, buffer, bufferOffset);
    // Serialize message field [end_x]
    bufferOffset = _serializer.float32(obj.end_x, buffer, bufferOffset);
    // Serialize message field [end_y]
    bufferOffset = _serializer.float32(obj.end_y, buffer, bufferOffset);
    // Serialize message field [end_yaw]
    bufferOffset = _serializer.float32(obj.end_yaw, buffer, bufferOffset);
    // Serialize message field [c1_x]
    bufferOffset = _serializer.float32(obj.c1_x, buffer, bufferOffset);
    // Serialize message field [c1_y]
    bufferOffset = _serializer.float32(obj.c1_y, buffer, bufferOffset);
    // Serialize message field [c2_x]
    bufferOffset = _serializer.float32(obj.c2_x, buffer, bufferOffset);
    // Serialize message field [c2_y]
    bufferOffset = _serializer.float32(obj.c2_y, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type track_pathGoal
    let len;
    let data = new track_pathGoal(null);
    // Deserialize message field [navi_type]
    data.navi_type = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [motion_type]
    data.motion_type = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [next_path_type]
    data.next_path_type = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [max_speed]
    data.max_speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [target_speed]
    data.target_speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [end_id]
    data.end_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [end_x]
    data.end_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [end_y]
    data.end_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [end_yaw]
    data.end_yaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [c1_x]
    data.c1_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [c1_y]
    data.c1_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [c2_x]
    data.c2_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [c2_y]
    data.c2_y = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 60;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/track_pathGoal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6381ba54e8851e146a404a6a02a721f3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    # Define the goal
    uint32 navi_type # 0:none, 1:激光,二维码, 2:磁条
    uint32 motion_type # 0:none, 1:start_point, 2:直线, 3:b样条曲线, 4:圆弧, 5:叉车、堆高车插货
    # -预留
    # 10 - 原地旋转
    # 11 - 充电
    # 12 - 向上整定
    # 13 - 向下整定
    uint32 next_path_type # 0:none, 1:点, 2:线, 3:b样条曲线, 4:圆弧
    float64 max_speed
    float64 target_speed
    uint32 end_id
    float32 end_x
    float32 end_y
    float32 end_yaw
    float32 c1_x
    float32 c1_y
    float32 c2_x
    float32 c2_y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new track_pathGoal(null);
    if (msg.navi_type !== undefined) {
      resolved.navi_type = msg.navi_type;
    }
    else {
      resolved.navi_type = 0
    }

    if (msg.motion_type !== undefined) {
      resolved.motion_type = msg.motion_type;
    }
    else {
      resolved.motion_type = 0
    }

    if (msg.next_path_type !== undefined) {
      resolved.next_path_type = msg.next_path_type;
    }
    else {
      resolved.next_path_type = 0
    }

    if (msg.max_speed !== undefined) {
      resolved.max_speed = msg.max_speed;
    }
    else {
      resolved.max_speed = 0.0
    }

    if (msg.target_speed !== undefined) {
      resolved.target_speed = msg.target_speed;
    }
    else {
      resolved.target_speed = 0.0
    }

    if (msg.end_id !== undefined) {
      resolved.end_id = msg.end_id;
    }
    else {
      resolved.end_id = 0
    }

    if (msg.end_x !== undefined) {
      resolved.end_x = msg.end_x;
    }
    else {
      resolved.end_x = 0.0
    }

    if (msg.end_y !== undefined) {
      resolved.end_y = msg.end_y;
    }
    else {
      resolved.end_y = 0.0
    }

    if (msg.end_yaw !== undefined) {
      resolved.end_yaw = msg.end_yaw;
    }
    else {
      resolved.end_yaw = 0.0
    }

    if (msg.c1_x !== undefined) {
      resolved.c1_x = msg.c1_x;
    }
    else {
      resolved.c1_x = 0.0
    }

    if (msg.c1_y !== undefined) {
      resolved.c1_y = msg.c1_y;
    }
    else {
      resolved.c1_y = 0.0
    }

    if (msg.c2_x !== undefined) {
      resolved.c2_x = msg.c2_x;
    }
    else {
      resolved.c2_x = 0.0
    }

    if (msg.c2_y !== undefined) {
      resolved.c2_y = msg.c2_y;
    }
    else {
      resolved.c2_y = 0.0
    }

    return resolved;
    }
};

module.exports = track_pathGoal;
