// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class linde_kob_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.actual_driver_velocity = null;
      this.actual_steering_angle = null;
      this.driver_mode = null;
      this.battery = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('actual_driver_velocity')) {
        this.actual_driver_velocity = initObj.actual_driver_velocity
      }
      else {
        this.actual_driver_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('actual_steering_angle')) {
        this.actual_steering_angle = initObj.actual_steering_angle
      }
      else {
        this.actual_steering_angle = 0.0;
      }
      if (initObj.hasOwnProperty('driver_mode')) {
        this.driver_mode = initObj.driver_mode
      }
      else {
        this.driver_mode = 0;
      }
      if (initObj.hasOwnProperty('battery')) {
        this.battery = initObj.battery
      }
      else {
        this.battery = 0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type linde_kob_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [actual_driver_velocity]
    bufferOffset = _serializer.float32(obj.actual_driver_velocity, buffer, bufferOffset);
    // Serialize message field [actual_steering_angle]
    bufferOffset = _serializer.float32(obj.actual_steering_angle, buffer, bufferOffset);
    // Serialize message field [driver_mode]
    bufferOffset = _serializer.uint8(obj.driver_mode, buffer, bufferOffset);
    // Serialize message field [battery]
    bufferOffset = _serializer.uint8(obj.battery, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.uint16(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type linde_kob_feedback
    let len;
    let data = new linde_kob_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [actual_driver_velocity]
    data.actual_driver_velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [actual_steering_angle]
    data.actual_steering_angle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [driver_mode]
    data.driver_mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [battery]
    data.battery = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/linde_kob_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '033310ede39a63cb5c60e5cc1001a188';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 时间戳
    uint32 time_stamp
    # 林德KOB驱动数据
    float32 actual_driver_velocity
    float32 actual_steering_angle
    uint8 driver_mode
    uint8 battery
    # 错误码
    uint16 error_code
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new linde_kob_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.actual_driver_velocity !== undefined) {
      resolved.actual_driver_velocity = msg.actual_driver_velocity;
    }
    else {
      resolved.actual_driver_velocity = 0.0
    }

    if (msg.actual_steering_angle !== undefined) {
      resolved.actual_steering_angle = msg.actual_steering_angle;
    }
    else {
      resolved.actual_steering_angle = 0.0
    }

    if (msg.driver_mode !== undefined) {
      resolved.driver_mode = msg.driver_mode;
    }
    else {
      resolved.driver_mode = 0
    }

    if (msg.battery !== undefined) {
      resolved.battery = msg.battery;
    }
    else {
      resolved.battery = 0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = linde_kob_feedback;
