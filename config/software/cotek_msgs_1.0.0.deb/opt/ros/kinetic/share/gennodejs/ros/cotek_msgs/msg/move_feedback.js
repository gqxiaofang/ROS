// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class move_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.actual_velocity = null;
      this.actual_omega = null;
    }
    else {
      if (initObj.hasOwnProperty('actual_velocity')) {
        this.actual_velocity = initObj.actual_velocity
      }
      else {
        this.actual_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('actual_omega')) {
        this.actual_omega = initObj.actual_omega
      }
      else {
        this.actual_omega = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type move_feedback
    // Serialize message field [actual_velocity]
    bufferOffset = _serializer.float32(obj.actual_velocity, buffer, bufferOffset);
    // Serialize message field [actual_omega]
    bufferOffset = _serializer.float32(obj.actual_omega, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type move_feedback
    let len;
    let data = new move_feedback(null);
    // Deserialize message field [actual_velocity]
    data.actual_velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [actual_omega]
    data.actual_omega = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/move_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b5cde89aaba903912390d9a90405e32c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 通过各模型转化后的 (v, w)
    float32 actual_velocity
    float32 actual_omega
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new move_feedback(null);
    if (msg.actual_velocity !== undefined) {
      resolved.actual_velocity = msg.actual_velocity;
    }
    else {
      resolved.actual_velocity = 0.0
    }

    if (msg.actual_omega !== undefined) {
      resolved.actual_omega = msg.actual_omega;
    }
    else {
      resolved.actual_omega = 0.0
    }

    return resolved;
    }
};

module.exports = move_feedback;
