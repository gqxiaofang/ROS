// Auto-generated. Do not edit!

// (in-package cotek_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let common_action_param = require('../msg/common_action_param.js');
let heap_fork_action_param = require('../msg/heap_fork_action_param.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class action_configRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.common_action_para = null;
      this.heap_fork_action_para = null;
    }
    else {
      if (initObj.hasOwnProperty('common_action_para')) {
        this.common_action_para = initObj.common_action_para
      }
      else {
        this.common_action_para = new common_action_param();
      }
      if (initObj.hasOwnProperty('heap_fork_action_para')) {
        this.heap_fork_action_para = initObj.heap_fork_action_para
      }
      else {
        this.heap_fork_action_para = new heap_fork_action_param();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type action_configRequest
    // Serialize message field [common_action_para]
    bufferOffset = common_action_param.serialize(obj.common_action_para, buffer, bufferOffset);
    // Serialize message field [heap_fork_action_para]
    bufferOffset = heap_fork_action_param.serialize(obj.heap_fork_action_para, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type action_configRequest
    let len;
    let data = new action_configRequest(null);
    // Deserialize message field [common_action_para]
    data.common_action_para = common_action_param.deserialize(buffer, bufferOffset);
    // Deserialize message field [heap_fork_action_para]
    data.heap_fork_action_para = heap_fork_action_param.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 33;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/action_configRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9fe6b70deaf6dab0eb3fdc65a6ae3cb8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cotek_msgs/common_action_param common_action_para
    cotek_msgs/heap_fork_action_param heap_fork_action_para
    
    
    ================================================================================
    MSG: cotek_msgs/common_action_param
    uint16 agv_type
    bool enable_loacl_debug
    bool enable_timeout
    bool check_pallet
    float64 action_timeout_value
    float64 control_period
    ================================================================================
    MSG: cotek_msgs/heap_fork_action_param
    int32 heap_liftload_height
    int32 heap_unload_height
    int32 heap_height_margin
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new action_configRequest(null);
    if (msg.common_action_para !== undefined) {
      resolved.common_action_para = common_action_param.Resolve(msg.common_action_para)
    }
    else {
      resolved.common_action_para = new common_action_param()
    }

    if (msg.heap_fork_action_para !== undefined) {
      resolved.heap_fork_action_para = heap_fork_action_param.Resolve(msg.heap_fork_action_para)
    }
    else {
      resolved.heap_fork_action_para = new heap_fork_action_param()
    }

    return resolved;
    }
};

class action_configResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type action_configResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type action_configResponse
    let len;
    let data = new action_configResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/action_configResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new action_configResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: action_configRequest,
  Response: action_configResponse,
  md5sum() { return '9fe6b70deaf6dab0eb3fdc65a6ae3cb8'; },
  datatype() { return 'cotek_msgs/action_config'; }
};
