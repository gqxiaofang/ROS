
"use strict";

let action_config = require('./action_config.js')
let navigation_config = require('./navigation_config.js')
let logic_config = require('./logic_config.js')

module.exports = {
  action_config: action_config,
  navigation_config: navigation_config,
  logic_config: logic_config,
};
