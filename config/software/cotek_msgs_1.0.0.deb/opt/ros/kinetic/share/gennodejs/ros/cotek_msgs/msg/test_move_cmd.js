// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class test_move_cmd {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.test_cmd_velcity = null;
      this.test_cmd_omega = null;
    }
    else {
      if (initObj.hasOwnProperty('test_cmd_velcity')) {
        this.test_cmd_velcity = initObj.test_cmd_velcity
      }
      else {
        this.test_cmd_velcity = 0.0;
      }
      if (initObj.hasOwnProperty('test_cmd_omega')) {
        this.test_cmd_omega = initObj.test_cmd_omega
      }
      else {
        this.test_cmd_omega = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type test_move_cmd
    // Serialize message field [test_cmd_velcity]
    bufferOffset = _serializer.float64(obj.test_cmd_velcity, buffer, bufferOffset);
    // Serialize message field [test_cmd_omega]
    bufferOffset = _serializer.float64(obj.test_cmd_omega, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type test_move_cmd
    let len;
    let data = new test_move_cmd(null);
    // Deserialize message field [test_cmd_velcity]
    data.test_cmd_velcity = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [test_cmd_omega]
    data.test_cmd_omega = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/test_move_cmd';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5dcbb1d15d55fe801dc5f50fff3884b0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 test_cmd_velcity
    float64 test_cmd_omega
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new test_move_cmd(null);
    if (msg.test_cmd_velcity !== undefined) {
      resolved.test_cmd_velcity = msg.test_cmd_velcity;
    }
    else {
      resolved.test_cmd_velcity = 0.0
    }

    if (msg.test_cmd_omega !== undefined) {
      resolved.test_cmd_omega = msg.test_cmd_omega;
    }
    else {
      resolved.test_cmd_omega = 0.0
    }

    return resolved;
    }
};

module.exports = test_move_cmd;
