// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class forklift_action {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.audio_control_type = null;
      this.audio_control_level = null;
      this.atomic_action_type = null;
      this.atomic_action_value = null;
    }
    else {
      if (initObj.hasOwnProperty('audio_control_type')) {
        this.audio_control_type = initObj.audio_control_type
      }
      else {
        this.audio_control_type = 0;
      }
      if (initObj.hasOwnProperty('audio_control_level')) {
        this.audio_control_level = initObj.audio_control_level
      }
      else {
        this.audio_control_level = 0;
      }
      if (initObj.hasOwnProperty('atomic_action_type')) {
        this.atomic_action_type = initObj.atomic_action_type
      }
      else {
        this.atomic_action_type = 0;
      }
      if (initObj.hasOwnProperty('atomic_action_value')) {
        this.atomic_action_value = initObj.atomic_action_value
      }
      else {
        this.atomic_action_value = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type forklift_action
    // Serialize message field [audio_control_type]
    bufferOffset = _serializer.uint8(obj.audio_control_type, buffer, bufferOffset);
    // Serialize message field [audio_control_level]
    bufferOffset = _serializer.uint8(obj.audio_control_level, buffer, bufferOffset);
    // Serialize message field [atomic_action_type]
    bufferOffset = _serializer.int32(obj.atomic_action_type, buffer, bufferOffset);
    // Serialize message field [atomic_action_value]
    bufferOffset = _serializer.float32(obj.atomic_action_value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type forklift_action
    let len;
    let data = new forklift_action(null);
    // Deserialize message field [audio_control_type]
    data.audio_control_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [audio_control_level]
    data.audio_control_level = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [atomic_action_type]
    data.atomic_action_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [atomic_action_value]
    data.atomic_action_value = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/forklift_action';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '365de88ae9e32198e4150da50ee7ee13';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 audio_control_type
    uint8 audio_control_level
    int32 atomic_action_type
    float32 atomic_action_value
    
    # enum class AtomicActionType : uint32_t {
    #   REST = 0,
    #   LOW_POWER_MODE = 1,
    #   PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
    #   PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
    #   HEAP_FORK_MOVE = 4,    // 堆高车叉腿移动  (operation_value 填 控制高度) // 暂时
    #   BRAKE = 5,             // 电机报闸  (operation_value 填0(关), 1(开))
    #   BEEP = 6,              // 喇叭  (operation_value 填0(关), 1(开))
    #   CURTIS_RESET  = 7,     // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
    #   CHARGE = 8             // 自动充电 (operation_value 填0(关), 1(开))
    # };
    
    # enum class AudioControlType : uint32_t {
    #   NONE = 0,
    #   BUMP_FAULT = 1,
    #   FORWARD = 2,
    #   BACKWARD = 3,
    #   OBSTACLE_WARN = 4,
    #   OBSTACLE_STOP = 5,
    #   LOW_BATTERY = 6
    # } 
    
    # audio_control_level  0 ~ 30 
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new forklift_action(null);
    if (msg.audio_control_type !== undefined) {
      resolved.audio_control_type = msg.audio_control_type;
    }
    else {
      resolved.audio_control_type = 0
    }

    if (msg.audio_control_level !== undefined) {
      resolved.audio_control_level = msg.audio_control_level;
    }
    else {
      resolved.audio_control_level = 0
    }

    if (msg.atomic_action_type !== undefined) {
      resolved.atomic_action_type = msg.atomic_action_type;
    }
    else {
      resolved.atomic_action_type = 0
    }

    if (msg.atomic_action_value !== undefined) {
      resolved.atomic_action_value = msg.atomic_action_value;
    }
    else {
      resolved.atomic_action_value = 0.0
    }

    return resolved;
    }
};

module.exports = forklift_action;
