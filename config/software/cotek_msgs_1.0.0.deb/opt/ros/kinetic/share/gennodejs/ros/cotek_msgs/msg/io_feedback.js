// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class io_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.di_1 = null;
      this.di_2 = null;
      this.di_3 = null;
      this.di_4 = null;
      this.di_5 = null;
      this.di_6 = null;
      this.di_7 = null;
      this.di_8 = null;
      this.di_9 = null;
      this.di_10 = null;
      this.do_1 = null;
      this.do_2 = null;
      this.do_3 = null;
      this.do_4 = null;
      this.do_5 = null;
      this.do_6 = null;
      this.do_7 = null;
      this.do_8 = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('di_1')) {
        this.di_1 = initObj.di_1
      }
      else {
        this.di_1 = false;
      }
      if (initObj.hasOwnProperty('di_2')) {
        this.di_2 = initObj.di_2
      }
      else {
        this.di_2 = false;
      }
      if (initObj.hasOwnProperty('di_3')) {
        this.di_3 = initObj.di_3
      }
      else {
        this.di_3 = false;
      }
      if (initObj.hasOwnProperty('di_4')) {
        this.di_4 = initObj.di_4
      }
      else {
        this.di_4 = false;
      }
      if (initObj.hasOwnProperty('di_5')) {
        this.di_5 = initObj.di_5
      }
      else {
        this.di_5 = false;
      }
      if (initObj.hasOwnProperty('di_6')) {
        this.di_6 = initObj.di_6
      }
      else {
        this.di_6 = false;
      }
      if (initObj.hasOwnProperty('di_7')) {
        this.di_7 = initObj.di_7
      }
      else {
        this.di_7 = false;
      }
      if (initObj.hasOwnProperty('di_8')) {
        this.di_8 = initObj.di_8
      }
      else {
        this.di_8 = false;
      }
      if (initObj.hasOwnProperty('di_9')) {
        this.di_9 = initObj.di_9
      }
      else {
        this.di_9 = false;
      }
      if (initObj.hasOwnProperty('di_10')) {
        this.di_10 = initObj.di_10
      }
      else {
        this.di_10 = false;
      }
      if (initObj.hasOwnProperty('do_1')) {
        this.do_1 = initObj.do_1
      }
      else {
        this.do_1 = false;
      }
      if (initObj.hasOwnProperty('do_2')) {
        this.do_2 = initObj.do_2
      }
      else {
        this.do_2 = false;
      }
      if (initObj.hasOwnProperty('do_3')) {
        this.do_3 = initObj.do_3
      }
      else {
        this.do_3 = false;
      }
      if (initObj.hasOwnProperty('do_4')) {
        this.do_4 = initObj.do_4
      }
      else {
        this.do_4 = false;
      }
      if (initObj.hasOwnProperty('do_5')) {
        this.do_5 = initObj.do_5
      }
      else {
        this.do_5 = false;
      }
      if (initObj.hasOwnProperty('do_6')) {
        this.do_6 = initObj.do_6
      }
      else {
        this.do_6 = false;
      }
      if (initObj.hasOwnProperty('do_7')) {
        this.do_7 = initObj.do_7
      }
      else {
        this.do_7 = false;
      }
      if (initObj.hasOwnProperty('do_8')) {
        this.do_8 = initObj.do_8
      }
      else {
        this.do_8 = false;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type io_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [di_1]
    bufferOffset = _serializer.bool(obj.di_1, buffer, bufferOffset);
    // Serialize message field [di_2]
    bufferOffset = _serializer.bool(obj.di_2, buffer, bufferOffset);
    // Serialize message field [di_3]
    bufferOffset = _serializer.bool(obj.di_3, buffer, bufferOffset);
    // Serialize message field [di_4]
    bufferOffset = _serializer.bool(obj.di_4, buffer, bufferOffset);
    // Serialize message field [di_5]
    bufferOffset = _serializer.bool(obj.di_5, buffer, bufferOffset);
    // Serialize message field [di_6]
    bufferOffset = _serializer.bool(obj.di_6, buffer, bufferOffset);
    // Serialize message field [di_7]
    bufferOffset = _serializer.bool(obj.di_7, buffer, bufferOffset);
    // Serialize message field [di_8]
    bufferOffset = _serializer.bool(obj.di_8, buffer, bufferOffset);
    // Serialize message field [di_9]
    bufferOffset = _serializer.bool(obj.di_9, buffer, bufferOffset);
    // Serialize message field [di_10]
    bufferOffset = _serializer.bool(obj.di_10, buffer, bufferOffset);
    // Serialize message field [do_1]
    bufferOffset = _serializer.bool(obj.do_1, buffer, bufferOffset);
    // Serialize message field [do_2]
    bufferOffset = _serializer.bool(obj.do_2, buffer, bufferOffset);
    // Serialize message field [do_3]
    bufferOffset = _serializer.bool(obj.do_3, buffer, bufferOffset);
    // Serialize message field [do_4]
    bufferOffset = _serializer.bool(obj.do_4, buffer, bufferOffset);
    // Serialize message field [do_5]
    bufferOffset = _serializer.bool(obj.do_5, buffer, bufferOffset);
    // Serialize message field [do_6]
    bufferOffset = _serializer.bool(obj.do_6, buffer, bufferOffset);
    // Serialize message field [do_7]
    bufferOffset = _serializer.bool(obj.do_7, buffer, bufferOffset);
    // Serialize message field [do_8]
    bufferOffset = _serializer.bool(obj.do_8, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.uint16(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type io_feedback
    let len;
    let data = new io_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [di_1]
    data.di_1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_2]
    data.di_2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_3]
    data.di_3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_4]
    data.di_4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_5]
    data.di_5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_6]
    data.di_6 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_7]
    data.di_7 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_8]
    data.di_8 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_9]
    data.di_9 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [di_10]
    data.di_10 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_1]
    data.do_1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_2]
    data.do_2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_3]
    data.do_3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_4]
    data.do_4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_5]
    data.do_5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_6]
    data.do_6 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_7]
    data.do_7 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [do_8]
    data.do_8 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/io_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7404e6d3242e8fcc7e97997c6946afee';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 时间戳
    uint32 time_stamp
    # IO驱动数据
    bool di_1
    bool di_2
    bool di_3
    bool di_4
    bool di_5
    bool di_6
    bool di_7
    bool di_8
    bool di_9
    bool di_10
    bool do_1
    bool do_2
    bool do_3
    bool do_4
    bool do_5
    bool do_6
    bool do_7
    bool do_8
    # 错误码
    uint16 error_code
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new io_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.di_1 !== undefined) {
      resolved.di_1 = msg.di_1;
    }
    else {
      resolved.di_1 = false
    }

    if (msg.di_2 !== undefined) {
      resolved.di_2 = msg.di_2;
    }
    else {
      resolved.di_2 = false
    }

    if (msg.di_3 !== undefined) {
      resolved.di_3 = msg.di_3;
    }
    else {
      resolved.di_3 = false
    }

    if (msg.di_4 !== undefined) {
      resolved.di_4 = msg.di_4;
    }
    else {
      resolved.di_4 = false
    }

    if (msg.di_5 !== undefined) {
      resolved.di_5 = msg.di_5;
    }
    else {
      resolved.di_5 = false
    }

    if (msg.di_6 !== undefined) {
      resolved.di_6 = msg.di_6;
    }
    else {
      resolved.di_6 = false
    }

    if (msg.di_7 !== undefined) {
      resolved.di_7 = msg.di_7;
    }
    else {
      resolved.di_7 = false
    }

    if (msg.di_8 !== undefined) {
      resolved.di_8 = msg.di_8;
    }
    else {
      resolved.di_8 = false
    }

    if (msg.di_9 !== undefined) {
      resolved.di_9 = msg.di_9;
    }
    else {
      resolved.di_9 = false
    }

    if (msg.di_10 !== undefined) {
      resolved.di_10 = msg.di_10;
    }
    else {
      resolved.di_10 = false
    }

    if (msg.do_1 !== undefined) {
      resolved.do_1 = msg.do_1;
    }
    else {
      resolved.do_1 = false
    }

    if (msg.do_2 !== undefined) {
      resolved.do_2 = msg.do_2;
    }
    else {
      resolved.do_2 = false
    }

    if (msg.do_3 !== undefined) {
      resolved.do_3 = msg.do_3;
    }
    else {
      resolved.do_3 = false
    }

    if (msg.do_4 !== undefined) {
      resolved.do_4 = msg.do_4;
    }
    else {
      resolved.do_4 = false
    }

    if (msg.do_5 !== undefined) {
      resolved.do_5 = msg.do_5;
    }
    else {
      resolved.do_5 = false
    }

    if (msg.do_6 !== undefined) {
      resolved.do_6 = msg.do_6;
    }
    else {
      resolved.do_6 = false
    }

    if (msg.do_7 !== undefined) {
      resolved.do_7 = msg.do_7;
    }
    else {
      resolved.do_7 = false
    }

    if (msg.do_8 !== undefined) {
      resolved.do_8 = msg.do_8;
    }
    else {
      resolved.do_8 = false
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = io_feedback;
