// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class velocity_paramer {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.max_v = null;
      this.min_v = null;
      this.acceleration = null;
      this.deceleration = null;
      this.margin = null;
      this.inertia_gain = null;
    }
    else {
      if (initObj.hasOwnProperty('max_v')) {
        this.max_v = initObj.max_v
      }
      else {
        this.max_v = 0.0;
      }
      if (initObj.hasOwnProperty('min_v')) {
        this.min_v = initObj.min_v
      }
      else {
        this.min_v = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration')) {
        this.acceleration = initObj.acceleration
      }
      else {
        this.acceleration = 0.0;
      }
      if (initObj.hasOwnProperty('deceleration')) {
        this.deceleration = initObj.deceleration
      }
      else {
        this.deceleration = 0.0;
      }
      if (initObj.hasOwnProperty('margin')) {
        this.margin = initObj.margin
      }
      else {
        this.margin = 0.0;
      }
      if (initObj.hasOwnProperty('inertia_gain')) {
        this.inertia_gain = initObj.inertia_gain
      }
      else {
        this.inertia_gain = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type velocity_paramer
    // Serialize message field [max_v]
    bufferOffset = _serializer.float64(obj.max_v, buffer, bufferOffset);
    // Serialize message field [min_v]
    bufferOffset = _serializer.float64(obj.min_v, buffer, bufferOffset);
    // Serialize message field [acceleration]
    bufferOffset = _serializer.float64(obj.acceleration, buffer, bufferOffset);
    // Serialize message field [deceleration]
    bufferOffset = _serializer.float64(obj.deceleration, buffer, bufferOffset);
    // Serialize message field [margin]
    bufferOffset = _serializer.float64(obj.margin, buffer, bufferOffset);
    // Serialize message field [inertia_gain]
    bufferOffset = _serializer.float64(obj.inertia_gain, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type velocity_paramer
    let len;
    let data = new velocity_paramer(null);
    // Deserialize message field [max_v]
    data.max_v = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [min_v]
    data.min_v = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acceleration]
    data.acceleration = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [deceleration]
    data.deceleration = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [margin]
    data.margin = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [inertia_gain]
    data.inertia_gain = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/velocity_paramer';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f209b154739d0279d6a0603518599ccc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 max_v
    float64 min_v
    float64 acceleration
    float64 deceleration
    float64 margin
    float64 inertia_gain
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new velocity_paramer(null);
    if (msg.max_v !== undefined) {
      resolved.max_v = msg.max_v;
    }
    else {
      resolved.max_v = 0.0
    }

    if (msg.min_v !== undefined) {
      resolved.min_v = msg.min_v;
    }
    else {
      resolved.min_v = 0.0
    }

    if (msg.acceleration !== undefined) {
      resolved.acceleration = msg.acceleration;
    }
    else {
      resolved.acceleration = 0.0
    }

    if (msg.deceleration !== undefined) {
      resolved.deceleration = msg.deceleration;
    }
    else {
      resolved.deceleration = 0.0
    }

    if (msg.margin !== undefined) {
      resolved.margin = msg.margin;
    }
    else {
      resolved.margin = 0.0
    }

    if (msg.inertia_gain !== undefined) {
      resolved.inertia_gain = msg.inertia_gain;
    }
    else {
      resolved.inertia_gain = 0.0
    }

    return resolved;
    }
};

module.exports = velocity_paramer;
