// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class avoid_ratio {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.slow_level1_decel_ratio = null;
      this.slow_level2_decel_ratio = null;
    }
    else {
      if (initObj.hasOwnProperty('slow_level1_decel_ratio')) {
        this.slow_level1_decel_ratio = initObj.slow_level1_decel_ratio
      }
      else {
        this.slow_level1_decel_ratio = 0.0;
      }
      if (initObj.hasOwnProperty('slow_level2_decel_ratio')) {
        this.slow_level2_decel_ratio = initObj.slow_level2_decel_ratio
      }
      else {
        this.slow_level2_decel_ratio = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type avoid_ratio
    // Serialize message field [slow_level1_decel_ratio]
    bufferOffset = _serializer.float64(obj.slow_level1_decel_ratio, buffer, bufferOffset);
    // Serialize message field [slow_level2_decel_ratio]
    bufferOffset = _serializer.float64(obj.slow_level2_decel_ratio, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type avoid_ratio
    let len;
    let data = new avoid_ratio(null);
    // Deserialize message field [slow_level1_decel_ratio]
    data.slow_level1_decel_ratio = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [slow_level2_decel_ratio]
    data.slow_level2_decel_ratio = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/avoid_ratio';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c833aa17cb096753f8fb96338a473d2f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 slow_level1_decel_ratio
    float64 slow_level2_decel_ratio
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new avoid_ratio(null);
    if (msg.slow_level1_decel_ratio !== undefined) {
      resolved.slow_level1_decel_ratio = msg.slow_level1_decel_ratio;
    }
    else {
      resolved.slow_level1_decel_ratio = 0.0
    }

    if (msg.slow_level2_decel_ratio !== undefined) {
      resolved.slow_level2_decel_ratio = msg.slow_level2_decel_ratio;
    }
    else {
      resolved.slow_level2_decel_ratio = 0.0
    }

    return resolved;
    }
};

module.exports = avoid_ratio;
