// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class audio_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.audio_type = null;
      this.audio_level = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('audio_type')) {
        this.audio_type = initObj.audio_type
      }
      else {
        this.audio_type = 0;
      }
      if (initObj.hasOwnProperty('audio_level')) {
        this.audio_level = initObj.audio_level
      }
      else {
        this.audio_level = 0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type audio_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [audio_type]
    bufferOffset = _serializer.uint8(obj.audio_type, buffer, bufferOffset);
    // Serialize message field [audio_level]
    bufferOffset = _serializer.uint8(obj.audio_level, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.uint16(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type audio_feedback
    let len;
    let data = new audio_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [audio_type]
    data.audio_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [audio_level]
    data.audio_level = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/audio_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6c29c6bbe07f483f9ade49c44af415c0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 时间戳
    uint32 time_stamp
    # 音频驱动数据
    uint8 audio_type
    uint8 audio_level
    # 错误码
    uint16 error_code
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new audio_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.audio_type !== undefined) {
      resolved.audio_type = msg.audio_type;
    }
    else {
      resolved.audio_type = 0
    }

    if (msg.audio_level !== undefined) {
      resolved.audio_level = msg.audio_level;
    }
    else {
      resolved.audio_level = 0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = audio_feedback;
