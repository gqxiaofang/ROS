// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class straight_line_gain {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.laterl_error_gain = null;
      this.orientation_error_gain = null;
    }
    else {
      if (initObj.hasOwnProperty('laterl_error_gain')) {
        this.laterl_error_gain = initObj.laterl_error_gain
      }
      else {
        this.laterl_error_gain = 0.0;
      }
      if (initObj.hasOwnProperty('orientation_error_gain')) {
        this.orientation_error_gain = initObj.orientation_error_gain
      }
      else {
        this.orientation_error_gain = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type straight_line_gain
    // Serialize message field [laterl_error_gain]
    bufferOffset = _serializer.float64(obj.laterl_error_gain, buffer, bufferOffset);
    // Serialize message field [orientation_error_gain]
    bufferOffset = _serializer.float64(obj.orientation_error_gain, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type straight_line_gain
    let len;
    let data = new straight_line_gain(null);
    // Deserialize message field [laterl_error_gain]
    data.laterl_error_gain = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [orientation_error_gain]
    data.orientation_error_gain = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/straight_line_gain';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '78406ed92fa8ee7b53d9f404efe0167d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 laterl_error_gain
    float64 orientation_error_gain
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new straight_line_gain(null);
    if (msg.laterl_error_gain !== undefined) {
      resolved.laterl_error_gain = msg.laterl_error_gain;
    }
    else {
      resolved.laterl_error_gain = 0.0
    }

    if (msg.orientation_error_gain !== undefined) {
      resolved.orientation_error_gain = msg.orientation_error_gain;
    }
    else {
      resolved.orientation_error_gain = 0.0
    }

    return resolved;
    }
};

module.exports = straight_line_gain;
