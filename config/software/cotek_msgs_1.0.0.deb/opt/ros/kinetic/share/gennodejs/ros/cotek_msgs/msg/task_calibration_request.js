// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class task_calibration_request {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.calibration_mode = null;
      this.calibration_operation_type = null;
    }
    else {
      if (initObj.hasOwnProperty('calibration_mode')) {
        this.calibration_mode = initObj.calibration_mode
      }
      else {
        this.calibration_mode = 0;
      }
      if (initObj.hasOwnProperty('calibration_operation_type')) {
        this.calibration_operation_type = initObj.calibration_operation_type
      }
      else {
        this.calibration_operation_type = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type task_calibration_request
    // Serialize message field [calibration_mode]
    bufferOffset = _serializer.int32(obj.calibration_mode, buffer, bufferOffset);
    // Serialize message field [calibration_operation_type]
    bufferOffset = _serializer.int32(obj.calibration_operation_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type task_calibration_request
    let len;
    let data = new task_calibration_request(null);
    // Deserialize message field [calibration_mode]
    data.calibration_mode = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [calibration_operation_type]
    data.calibration_operation_type = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/task_calibration_request';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e5451e6fe7dac54a33ca29bbd0d56168';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 获取标定地图信息包  1~10 为地图信息标定, 11~20 为车体机械传感器安装等参数标定,  21~30 为运动参数标定
    int32 calibration_mode  # 标定模式, 0:无  1:反光板标定, 2:slam地图标定 ...
    int32 calibration_operation_type  # 标定操作 1:开启, 2:关闭, 3:本地保存
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new task_calibration_request(null);
    if (msg.calibration_mode !== undefined) {
      resolved.calibration_mode = msg.calibration_mode;
    }
    else {
      resolved.calibration_mode = 0
    }

    if (msg.calibration_operation_type !== undefined) {
      resolved.calibration_operation_type = msg.calibration_operation_type;
    }
    else {
      resolved.calibration_operation_type = 0
    }

    return resolved;
    }
};

module.exports = task_calibration_request;
