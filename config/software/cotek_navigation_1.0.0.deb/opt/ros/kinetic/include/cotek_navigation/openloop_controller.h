/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_OPENLOOP_CONTROLLER_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_OPENLOOP_CONTROLLER_H_
#include <angles/angles.h>
#include <gtest/gtest_prod.h>
#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <boost/algorithm/clamp.hpp>
#include <eigen3/Eigen/Geometry>
#include "boost/geometry/geometries/multi_point.hpp"
#include "cotek_common/log_porting.h"
#include "cotek_msgs/pose_deviation.h"
#include "cotek_navigation/controller_interface.h"
#include "cotek_navigation/navigation_options.h"
#include "cotek_navigation/util.h"

namespace cotek_navigation {
using TaskPtr = std::shared_ptr<TaskServerManager>;
using StatePtr = std::shared_ptr<StateManager>;

class OpenloopController : public ControllerInterface {
 public:
  /**
   * \brief default constructor
   */
  OpenloopController() = delete;

  /**
   * \brief construct object with options
   * \param option all OpenloopController related parameters
   */
  explicit OpenloopController(const OpenloopControllerOption &option);

  void Update(const TaskPtr tm, const StatePtr sm) override;
  cotek_msgs::move_cmd GetCommandVelocity(const TaskPtr tm,
                                          const StatePtr sm) override;
  cotek_msgs::move_cmd StraightLine(const TaskPtr tm, const StatePtr sm,
                                    double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd SelfRotate(const TaskPtr tm, const StatePtr sm,
                                  double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd Arc(const TaskPtr tm, const StatePtr sm, double dy,
                           double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd BSplineCurves(const TaskPtr tm, const StatePtr sm,
                                     double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd Charging(const TaskPtr tm, const StatePtr sm, double dy,
                                double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd ForkliftUpload(const TaskPtr tm, const StatePtr sm,
                                      double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd QRUpStabilize(const TaskPtr tm, const StatePtr sm,
                                     double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd QRDownStabilize(const TaskPtr tm, const StatePtr sm,
                                       double dy, double dw) override {
    return ZeroCmdVel();
  }

 private:
  double GetYawBias(const TaskPtr tm, const StatePtr sm) override { return 0.; }
  double GetDeltaY(const TaskPtr tm, const StatePtr sm) override { return 0.; }
  void UpdateMovedOdom(const TaskPtr tm, const StatePtr sm);
  MoveFeedbackState AchievedGoal(const TaskPtr tm, const StatePtr sm);
  bool OffTheTrack(double dy, double dw);
  double GetLinearSpeed(double cur, double tar, double dist,
                        const SpeedOption &option);

  OpenloopControllerOption option_;

  double odom_;
  double theta_;
};
}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_OPENLOOP_CONTROLLER_H_
