/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_STATE_MANAGER_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_STATE_MANAGER_H_
#include <gtest/gtest_prod.h>
#include <ros/ros.h>
#include <memory>
#include <string>
#include "cotek_msgs/battery.h"
#include "cotek_msgs/io_feedback.h"
#include "cotek_msgs/move_cmd.h"
#include "cotek_msgs/move_feedback.h"
#include "cotek_msgs/pallet_fork_io_state.h"
#include "cotek_msgs/safety_state.h"
#include "cotek_navigation/task_server_manager.h"
#include "cotek_navigation/util.h"

namespace cotek_navigation {

using Pose = cotek_geometry::Pose;

struct BatteryData {
  uint8_t battery_type;
  uint8_t capacity;
  uint8_t current;
  uint8_t voltage;
};

class StateManager {
 public:
  StateManager() = delete;
  explicit StateManager(const std::shared_ptr<TaskServerManager> tm,
                        bool enableMagneticFeedback = true);
  ~StateManager();
  /**
   * \brief getter
   */
  inline bool pose_valid() const { return pose_valid_; }
  inline Pose pose() const { return pose_; }
  inline cotek_msgs::move_cmd last_cmd_vel() const { return cmd_vel_; }
  inline double delta_y() const { return delta_y_; }
  inline double yaw_bias() const { return yaw_bias_; }

  inline float last_cmd_velocity() const { return last_cmd_velocity_; }
  inline float velocity() const { return velocity_; }
  inline float omega() const { return omega_; }
  inline float fork_height() const { return fork_height_; }
  inline float mls_offset() const { return mls_plc_; }
  inline MlsState mls_state() const { return mls_state_; }
  inline bool on_maglane() const { return MlsState::NONE != mls_state_; }
  inline uint32_t rfid() const { return rfid_; }
  inline ForkState fork_state() const { return fork_state_; }
  inline ForkCheckerState fork_checker_state() const {
    return fork_checker_state_;
  }
  inline ChargeCheckerState charge_checker_state() const {
    return charge_checker_state_;
  }
  inline MoveFeedbackState move_feedback_state() const {
    return move_feedback_state_;
  }
  inline AvoidLevel avoid_level() const { return avoid_level_; }
  inline BatteryData battery() const { return battery_; }
  inline BatteryData last_battery() const { return last_battery_; }
  inline ErrorCode error() const { return err_; }

  /**
   * \brief setter
   */
  inline void set_agv_type(AgvType type) { agv_type_ = type; }
  inline void set_init_id(int id) { saved_id_ = static_cast<uint32_t>(id); }
  inline void set_pose(const Pose& pose) {
    pose_ = pose;
    pose_valid_ = true;
  }
  inline void set_last_cmd_velocity(float v) { last_cmd_velocity_ = v; }
  inline void set_pose_valid(bool val) { pose_valid_ = val; }
  inline void set_cmd_vel(cotek_msgs::move_cmd cmdVel) { cmd_vel_ = cmdVel; }
  inline void set_delta_y(double val) { delta_y_ = val; }
  inline void set_yaw_bias(double val) { yaw_bias_ = val; }
  inline void set_error_code(ErrorCode err) { err_ = err; }
  inline void set_move_feedback_state(MoveFeedbackState state) {
    move_feedback_state_ = state;
  }
  bool reachHeight(double targetHeight) {
    return nearZero(targetHeight - fork_height_, 0.01) ||
           nearZero(targetHeight);
  }

  /**
   * \brief function
   */
  bool IsBlind();

  void AddMoveFeedbackData(const cotek_msgs::move_feedback::ConstPtr& feedback);

  void AddSafetyStateData(const cotek_msgs::safety_state::ConstPtr& feedback);

  void AddPalletForkIoStateData(
      const cotek_msgs::pallet_fork_io_state::ConstPtr& feedback);

  void AddBatteryData(const cotek_msgs::battery::ConstPtr& feedback);

 private:
  inline void set_velocity(float v) { velocity_ = v; }
  inline void set_omega(float omega) { omega_ = omega; }
  inline void set_fork_height(float height) { fork_height_ = height; }
  inline void set_mls_plc(float mlsPlc) { mls_plc_ = mlsPlc; }
  inline void set_mls_state(MlsState state) { mls_state_ = state; }
  inline void set_rfid(uint32_t id) { rfid_ = id; }
  inline void set_fork_state(ForkState state) { fork_state_ = state; }
  inline void set_fork_checker_state(ForkCheckerState state) {
    fork_checker_state_ = state;
  }
  inline void set_avoid_level(AvoidLevel level) { avoid_level_ = level; }
  inline void set_battery(BatteryData val) {
    last_battery_ = battery_;
    battery_ = val;
  }

  std::shared_ptr<TaskServerManager> task_manager_;

  AgvType agv_type_;

  bool pose_valid_;
  double delta_y_;
  double yaw_bias_;
  float velocity_;
  float last_cmd_velocity_;
  float omega_;
  float fork_height_;
  float mls_plc_;
  cotek_msgs::move_cmd cmd_vel_;

  Pose pose_;
  uint32_t rfid_;
  uint32_t saved_id_;
  MlsState mls_state_;
  ForkState fork_state_;
  ForkCheckerState fork_checker_state_;
  ChargeCheckerState charge_checker_state_;
  MoveFeedbackState move_feedback_state_;
  AvoidLevel avoid_level_;
  BatteryData battery_;
  BatteryData last_battery_;
  ErrorCode err_;
  bool start_heartbeat_daemon_;
  bool enable_magnetic_feedback_;
  bool is_forward_;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_STATE_MANAGER_H_
