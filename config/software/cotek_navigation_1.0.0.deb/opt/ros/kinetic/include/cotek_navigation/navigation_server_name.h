/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#pragma once
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_CONSTANTS_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_CONSTANTS_H_

#include <actionlib/server/simple_action_server.h>
#include "cotek_common/log_porting.h"
#include "cotek_msgs/openloopAction.h"
#include "cotek_msgs/track_pathAction.h"

namespace cotek_navigation {
using TrackPathActionServer =
    actionlib::SimpleActionServer<cotek_msgs::track_pathAction>;
using OpenloopActionServer =
    actionlib::SimpleActionServer<cotek_msgs::openloopAction>;

}  // namespace cotek_navigation
#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_CONSTANTS_H_
