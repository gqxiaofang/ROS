/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_B_SPLINE_CURVE_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_B_SPLINE_CURVE_H_
#include <angles/angles.h>
#include <vector>
#include "cotek_common/log_porting.h"
#include "cotek_navigation/point.h"
#include "cotek_navigation/pose.h"

namespace cotek_navigation {

using Pose = cotek_geometry::Pose;
using Point = cotek_geometry::Point;
constexpr int kOrder = 3;
constexpr double kEndState = 0.999f;

/**
 * \class BSplineCurve
 * \brief a BSplineCurve is described in world-coordinate system
 */
class BSplineCurve {
 public:
  BSplineCurve();
  ~BSplineCurve() {}
  bool UpdateBSplineCurve(const std::vector<Point>& control_point,
                          bool is_forward, int order = kOrder);
  // 更新B样条上目标跟踪的点信息
  void UpdateGoalPose(const Pose& pose, double delta_state,
                      double distance_threshold);
  double GetDeltaY(const Pose& pose);
  double GetYawBias(const Pose& pose);
  double GetYawBias2(const Pose& pose);
  inline Pose GetGoalPose() { return goal_pose_; }
  inline const bool IsForward() { return is_forward_; }
  // 根据s得到B样条曲线上的点信息；
  Pose GetCurvePose(double state);

 private:
  std::vector<double> UQuasiUniform();

  double BaseFunction(int i, int order, double state);

  double DerivativeBCurve(double state, int order);

  int order_;
  double state_;
  int control_points_number_;
  bool is_forward_;
  std::vector<Point> control_points_;
  std::vector<double> node_vector_;
  Eigen::Vector2d move_orientation_criterion_;
  Pose end_pose_;
  Pose goal_pose_;
};

}  // namespace cotek_navigation
#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_B_SPLINE_CURVE_H_
