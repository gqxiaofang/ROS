/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_MAGNETIC_CONTROLLER_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_MAGNETIC_CONTROLLER_H_
#include "cotek_navigation/controller_interface.h"
#include "cotek_navigation/mini_pid.h"
#include "cotek_navigation/navigation_options.h"
#include "cotek_navigation/util.h"

namespace cotek_navigation {

class MagneticController : public ControllerInterface {
 public:
  /**
   * \brief default constructor
   */
  MagneticController() = delete;

  /**
   * \brief construct object with options
   * \param option all FreeController related parameters
   */
  explicit MagneticController(const MagneticControllerOption &option);
  void Update(const TaskPtr tm, const StatePtr sm) override;
  cotek_msgs::move_cmd GetCommandVelocity(const TaskPtr tm,
                                          const StatePtr sm) override;
  cotek_msgs::move_cmd StraightLine(const TaskPtr tm, const StatePtr sm,
                                    double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd SelfRotate(const TaskPtr tm, const StatePtr sm,
                                  double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd Arc(const TaskPtr tm, const StatePtr sm, double dy,
                           double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd BSplineCurves(const TaskPtr tm, const StatePtr sm,
                                     double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd Charging(const TaskPtr tm, const StatePtr sm, double dy,
                                double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd ForkliftUpload(const TaskPtr tm, const StatePtr sm,
                                      double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd QRUpStabilize(const TaskPtr tm, const StatePtr sm,
                                     double dy, double dw) override {
    return ZeroCmdVel();
  }
  cotek_msgs::move_cmd QRDownStabilize(const TaskPtr tm, const StatePtr sm,
                                       double dy, double dw) override {
    return ZeroCmdVel();
  }

 private:
  double GetYawBias(const TaskPtr tm, const StatePtr sm) override;
  double GetDeltaY(const TaskPtr tm, const StatePtr sm) override;

  MiniPID pid_;
  MagneticControllerOption option_;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_MAGNETIC_CONTROLLER_H_
