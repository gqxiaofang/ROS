/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_POSE_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_POSE_H_
#include <cmath>
#include <eigen3/Eigen/Geometry>
#include "cotek_navigation/point.h"

namespace cotek_geometry {

/**
 * \class Pose
 */
class Pose {
 public:
  /**
   * \brief default constructor, create an instance with point(0,0) and yaw(0)
   */
  Pose() : point_(0.0, 0.0), yaw_(0.0) {}

  /**
   * \brief construct a pose with (x, y, yaw)
   * \param x coordinate x
   * \param y coordinate y
   * \param yaw coordinate yaw
   */
  Pose(double x, double y, double yaw) : point_(x, y), yaw_(yaw) {}

  /**
   * \brief construct a pose with point p and yaw
   * \param p a point
   * \param yaw pose yaw
   */
  Pose(Point p, double yaw) : point_(p), yaw_(yaw) {}

  /**
   * \brief default copy constructor
   * \param another pose
   */
  Pose(const Pose &pose) : point_(pose.point_), yaw_(pose.yaw_) {}

  /**
   * \brief assign self with another pose
   * \param another pose
   * \return self
   */
  Pose &operator=(const Pose &pose) {
    if (this == &pose) {
      return *this;
    }

    this->point_ = pose.point_;
    this->yaw_ = pose.yaw_;
    return *this;
  }

  /**
   * \brief get the distance from self to another pose
   * \param pose another pose
   * \return the distance
   */
  inline double GetDistance(const Pose &pose) const {
    return point_.GetDistance(pose.point());
  }

  /**
   * \brief set pose by (x, y, yaw)
   * \param x point-x
   * \param y point-y
   * \param yaw point-yaw
   */
  inline void set(double x, double y, double yaw) {
    point_.set_x(x);
    point_.set_y(y);
    yaw_ = yaw;
  }

  /**
   * \brief point setter
   * \param p point to set
   */
  inline void set_point(Point p) { point_ = p; }

  /**
   * \brief yaw setter
   * \param yaw yaw to set
   */
  inline void set_yaw(double yaw) { yaw_ = yaw; }

  /**
   * \brief point getter
   * \return self point
   */
  inline const Point point() const { return point_; }

  /**
   * \brief point.x getter
   */
  inline const double x() const { return point_.x(); }

  /**
   * \brief point.y getter
   */
  inline const double y() const { return point_.y(); }

  /**
   * \brief yaw getter
   * \return self yaw
   */
  inline const double yaw() const { return yaw_; }

  /**
   * \brief get laser dist from (currentSite to nextSite)
   * \param,input site pose
   * \return dist
   */
  double GetVerticalDist(const Pose &pose) const {
    Point startPoint = pose.point();
    Point endPoint(startPoint.x() + std::cos(static_cast<float>(pose.yaw())),
                   startPoint.y() + std::sin(static_cast<float>(pose.yaw())));

    double triangleArea =
        ((startPoint.x() - point_.x()) * (endPoint.y() - point_.y()) -
         (startPoint.y() - point_.y()) * (endPoint.x() - point_.x())) /
        2.0;
    double a = endPoint.y() - startPoint.y();
    double b = startPoint.x() - endPoint.x();
    double c = endPoint.x() * startPoint.y() - startPoint.x() * endPoint.y();
    if (triangleArea <= 0) {
      return -std::abs((a * point_.x() + b * point_.y() + c) /
                       std::hypot(a, b));
    } else {
      return std::abs((a * point_.x() + b * point_.y() + c) / std::hypot(a, b));
    }
  }

  double GetSignedDistance2Pose(const Pose &pose) const {
    Eigen::Vector2d self(std::cos(static_cast<float>(this->yaw())),
                         std::sin(static_cast<float>(this->yaw())));
    Eigen::Vector2d connection(pose.x() - this->x(), pose.y() - this->y());
    auto sign = self.dot(connection) >= 0. ? 1. : -1.;

    return sign * std::hypot(pose.y() - this->y(), pose.x() - this->x());
  }

  double ProjectingDistance(const Pose &next) const {
    Eigen::Vector2d next_yaw(std::cos(next.yaw()), std::sin(next.yaw()));
    Eigen::Vector2d next2pose(this->x() - next.x(), this->y() - next.y());
    return -next2pose.dot(next_yaw);
  }

  Point Intersect(const Pose &pose) const {
    double a1 = std::sin(static_cast<float>(yaw_));
    double b1 = -std::cos(static_cast<float>(yaw_));
    double c1 = -a1 * point_.x() - b1 * point_.y();

    double a2 = std::sin(static_cast<float>(pose.yaw()));
    double b2 = -std::cos(static_cast<float>(pose.yaw()));
    double c2 = -a2 * pose.x() - b2 * pose.y();

    return Point((b1 * c2 - b2 * c1) / (a1 * b2 - a2 * b1),
                 (a1 * c2 - a2 * c1) / (a2 * b1 - a1 * b2));
  }

  Point GetCenterPoint(const Pose &pose) const {
    double a1 = std::cos(static_cast<float>(this->yaw_));
    double b1 = std::sin(static_cast<float>(this->yaw_));
    double c1 = -a1 * this->x() - b1 * this->y();

    double a2 = std::cos(static_cast<float>(pose.yaw()));
    double b2 = std::sin(static_cast<float>(pose.yaw()));
    double c2 = -a2 * pose.x() - b2 * pose.y();

    auto x = (b1 * c2 - b2 * c1) / (a1 * b2 - a2 * b1);
    auto y = (a1 * c2 - a2 * c1) / (a2 * b1 - a1 * b2);

    return Point(x, y);
  }

 private:
  Point point_;
  double yaw_;
};

}  // namespace cotek_geometry

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_POSE_H_
