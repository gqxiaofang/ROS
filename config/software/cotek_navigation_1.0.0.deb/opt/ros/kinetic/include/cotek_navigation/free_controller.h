/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_FREE_CONTROLLER_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_FREE_CONTROLLER_H_
#include <angles/angles.h>
#include <gtest/gtest_prod.h>
#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <boost/algorithm/clamp.hpp>
#include "boost/geometry/geometries/multi_point.hpp"
#include "cotek_msgs/pose_deviation.h"
#include "cotek_navigation/controller_interface.h"
#include "cotek_navigation/navigation_options.h"
#include "cotek_navigation/util.h"

namespace cotek_navigation {
using TaskPtr = std::shared_ptr<TaskServerManager>;
using StatePtr = std::shared_ptr<StateManager>;
using Pose = cotek_geometry::Pose;
using Point = cotek_geometry::Point;

class FreeController : public ControllerInterface {
 public:
  /**
   * \brief default constructor
   */
  FreeController() = delete;

  /**
   * \brief construct object with options
   * \param option all FreeController related parameters
   */
  explicit FreeController(const FreeControllerOption &option);

  void Update(const TaskPtr tm, const StatePtr sm) override;
  cotek_msgs::move_cmd GetCommandVelocity(const TaskPtr tm,
                                          const StatePtr sm) override;
  cotek_msgs::move_cmd StraightLine(const TaskPtr tm, const StatePtr sm,
                                    double dy, double dw) override;
  cotek_msgs::move_cmd SelfRotate(const TaskPtr tm, const StatePtr sm,
                                  double dy, double dw) override;
  cotek_msgs::move_cmd Arc(const TaskPtr tm, const StatePtr sm, double dy,
                           double dw) override;
  cotek_msgs::move_cmd BSplineCurves(const TaskPtr tm, const StatePtr sm,
                                     double dy, double dw) override;
  cotek_msgs::move_cmd Charging(const TaskPtr tm, const StatePtr sm, double dy,
                                double dw) override;
  cotek_msgs::move_cmd ForkliftUpload(const TaskPtr tm, const StatePtr sm,
                                      double dy, double dw) override;
  cotek_msgs::move_cmd QRUpStabilize(const TaskPtr tm, const StatePtr sm,
                                     double dy, double dw) override;
  cotek_msgs::move_cmd QRDownStabilize(const TaskPtr tm, const StatePtr sm,
                                       double dy, double dw) override;

 private:
  FreeControllerOption option_;
  bool find_site_flag_;
  double curvature_;
  double curvature_temp_;
  int GetTurningDirection(const TaskPtr tm, const StatePtr sm);
  double GetYawBias(const TaskPtr tm, const StatePtr sm) override;
  double GetDeltaY(const TaskPtr tm, const StatePtr sm) override;
  double GetYawBias2(const TaskPtr tm, const StatePtr sm);
  double GetOmega(double dy, double dw, double k1, double k2, double v, int dir,
                  double curvature = 0.);
  double GetOmegaWithBSpline(double dy, double dw, double dw1, double v,
                             double k1, double k2, double k3);
  MoveFeedbackState AchievedGoal(const TaskPtr tm, const StatePtr sm);
  bool OffTheTrack(double dy, double dw);
  void PublishPoseDeviation(Pose pose, double dy, double dw, double dw1,
                            const TaskPtr tm);
  double GetThetaOf2Pose(const Pose &from, const Pose &to) {
    return std::atan2(to.y() - from.y(), to.x() - from.x());
  }
  double GetLinearSpeed(double cur, double tar, double last_cmd, double dist,
                        const SpeedOption &option);
  /**
   * \brief to get the current posion
   */
  boost::shared_ptr<tf::TransformListener> tf_;

  ros::Publisher pose_and_deviation_pub_;
};
}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_FREE_CONTROLLER_H_
