/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_NAVIGATION_OPTIONS_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_NAVIGATION_OPTIONS_H_
#include <string>

namespace cotek_navigation {

struct AlgorithmOption {
  double straight_line_laterl_error_gain;
  double straight_line_orientation_error_gain;
  double arc_line_laterl_error_gain;
  double arc_line_orientation_error_gain;
  double arc_curvature;
  double b_spline_forward_laterl_error_gain;
  double b_spline_forward_orientation_error_gain;
  double b_spline_forward_los_error_gain;
  double b_spline_back_laterl_error_gain;
  double b_spline_back_orientation_error_gain;
  double b_spline_back_los_error_gain;
};

struct SpeedOption {
  double max;
  double min;
  double acceleration;
  double deceleration;
  double margin;
};

struct AvoidanceOption {
  double slow_level1_decel_ratio;
  double slow_level2_decel_ratio;
};

struct Residual {
  Residual() : xy(0.), yaw(0.) {}
  Residual(double dy, double dyaw) : xy(dy), yaw(dyaw) {}
  double xy;
  double yaw;
};

struct Tolerance {
  Residual derail;
  Residual anchor;
};

/**
 * \struct Option
 * \brief options for free controller
 */
struct FreeControllerOption {
  AlgorithmOption algorithm;
  SpeedOption velocityOption;
  SpeedOption rotationOption;
  SpeedOption stabilizationOption;
  SpeedOption manualOption;
  AvoidanceOption avoidance_option;
  Tolerance tolerance;

  double jacker_velocity;
  double controller_frequency;
  double pose_delay_threshold;
};

/**
 * \struct Option
 * \brief options for magnetic controller
 */
struct MagneticControllerOption {
  AvoidanceOption avoidance_option;
  double p;
  double i;
  double d;
  double max_i_out;
  double steeringangle_limit;
};

struct OpenloopControllerOption {
  SpeedOption velocityOption;
  AvoidanceOption avoidance_option;
  Tolerance tolerance;
  double controller_frequency;
};

struct ControllerOption {
  FreeControllerOption free_controller_option;
  MagneticControllerOption magnetic_controller_option;
  OpenloopControllerOption openloop_controller_option;
};

struct PlannerOption {
  ControllerOption controller_option;
  bool enable_free_controller;
  bool enable_mag_controller;
  bool enable_openloop_controller;
};

struct NavigationOption {
  bool enable_local_debug;
  PlannerOption planner_option;
  bool enable_lidar;
  bool enable_magnetic;
  double controller_frequency;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_NAVIGATION_OPTIONS_H_
