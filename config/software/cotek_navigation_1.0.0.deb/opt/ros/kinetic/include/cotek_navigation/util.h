/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_UTIL_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_UTIL_H_
#include <cmath>

namespace cotek_navigation {

template <typename T>
double deg2rad(T deg) {
  return deg / 180.0 * M_PI;
}

template <typename T>
double rad2deg(T rad) {
  return rad / M_PI * 180.0;
}

template <typename T>
T meter2millimeter(T meter) {
  return meter * 1000.0;
}

template <typename T>
T meter2centimeter(T meter) {
  return meter * 100.0;
}

template <typename T>
double centimeter2meter(T centimeter) {
  return centimeter / 100.0;
}

template <typename T>
bool nearZero(T val, double bound = 0.0001) {
  return std::fabs(static_cast<double>(val)) <= bound;
}

template <typename T>
int sign(T val) {
  return 0 == static_cast<double>(val) ? 0 : (val > 0 ? 1 : -1);
}

template <typename T>
int InsertGap(T val, int gap = 2000) {
  return static_cast<int>(val) + gap;
}

template <typename T>
void SmoothStep(T &from, T to, double delta = 0.01) {
  from += delta;
  if (delta > 0.) {
    if (from >= to) from = to;
  } else {
    if (from <= to) from = to;
  }
}

enum SpeedFormulaType { FROM, DISTANCE };

/**
 * \class SpeedFormula
 */
template <SpeedFormulaType DISTANCE>
class SpeedFormula {
 public:
  SpeedFormula(double from, double to, double acc)
      : from_(from), to_(to), acc_(acc) {}

  double get() {
    return std::fabs((std::pow(to_, 2) - std::pow(from_, 2)) / acc_ / 2.0);
  }

 private:
  double from_;
  double to_;
  double acc_;
};

template <>
class SpeedFormula<FROM> {
 public:
  SpeedFormula(double to, double acc, double distance)
      : to_(to), acc_(acc), distance_(distance) {}

  double get() {
    float to2 = std::pow(to_, 2) + 2 * acc_ * distance_;
    return to2 >= 0.0 ? std::sqrt(to2) : 0.0;
  }

 private:
  double to_;
  double acc_;
  double distance_;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_UTIL_H_
