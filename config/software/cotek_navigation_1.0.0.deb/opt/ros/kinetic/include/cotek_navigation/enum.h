/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_ENUM_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_ENUM_H_

namespace cotek_navigation {
enum class ChargeCheckerState { NOT_READY = 0, READY };
enum class ForkState { MIDDLE = 0, SHORT, LONG, ROTATING };
enum class MlsState { NONE = 0, ONLYONE = 2, TWO_RIGHTD, TWO_LEFTD = 6, ALL };
enum class ForkCheckerState { NONE = 0, LEFT_ONLY, RIGHT_ONLY, BOTH };
enum class RotatingOption { NONE = 0, LEFT, RIGHT, LEFT2RIGHT, RIGHT2LEFT };
enum class AvoidLevel { NONE = 0, LVL1, LVL2, LVL3 };

enum class ErrorCode {
  NONE = 0,
  INVALID_CMD,
  LOSS_CMD,
  ILLEGAL_OPTION,
  OFF_THE_TRACK,
  SITE_ERROR,
  MOTIONTYPE_ERROR,
  LOCATION_LOSS,
  LOCATION_OVERTIME,
  TASK_RECEIVE_CHECK_ERROR,
  TASK_FINISH_CHECK_ERROR
};

enum class TaskState { WAITING = 1, DOING = 2, HOLDING = 3 };

enum class TaskFinishType : int32_t {
  WAITING_NEW_GOAL = 0,
  WAIT_NEW_GOAL_FAILED,
  NORMAL_FINISH
};

enum class MoveFeedbackState : int32_t {
  NONE = 0,
  MOVING,
  WAITING_NEW_GOAL,  // when target speed doesnt equal to zero;
  ARRIVED_AND_NOT_CHECKED,
  ARRIVED_AND_CHECKED
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_ENUM_H_
