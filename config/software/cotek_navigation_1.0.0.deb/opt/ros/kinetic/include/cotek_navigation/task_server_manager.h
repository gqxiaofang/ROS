/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_TASK_MANAGER_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_TASK_MANAGER_H_
#include <angles/angles.h>
#include <gtest/gtest_prod.h>
#include <ros/ros.h>
#include <cmath>
#include <string>
#include <vector>
#include "cotek_navigation/b_spline_curve.h"
#include "cotek_navigation/navigation_server_name.h"
#include "cotek_navigation/enum.h"
#include "cotek_navigation/step.h"
#include "cotek_navigation/util.h"

namespace cotek_navigation {

using Pose = cotek_geometry::Pose;
using Point = cotek_geometry::Point;

/**
 * \class TaskServerManager
 */
class TaskServerManager {
 public:
  TaskServerManager();
  ~TaskServerManager();

  /**
   * \brief getter
   */
  inline TaskState task_state() const { return task_state_; }
  inline const std::shared_ptr<Step> &current_task() const { return step_ptr_; }
  inline int32_t avoid_strategy() const {
    return step_ptr_->avoid_strategy_code();
  }
  double TargetSpeed() const { return step_ptr_->target_speed(); }
  double MaxSpeed() const { return step_ptr_->max_speed(); }
  double MaxOmega() const { return step_ptr_->max_omega(); }

  inline const Site &start_site() const { return step_ptr_->start_site(); }
  inline const Site &end_site() const { return step_ptr_->end_site(); }
  inline NaviType navi_type() const { return step_ptr_->navi_type(); }
  inline MotionType motion_type() const { return step_ptr_->motion_type(); }
  inline PathType next_path_type() const { return step_ptr_->next_path_type(); }
  inline float intended_orientation() const {
    return step_ptr_->intended_orientation();
  }
  double Distance2EndSite(const Pose &pose) {
    return pose.GetDistance(step_ptr_->end_site().pose());
  }
  inline const double Odom() { return step_ptr_->odom(); }

  inline const Point &center_point() const { return center_point_; }
  inline const double radius() const { return radius_; }
  inline bool IsForward() const { return is_forward_; }
  inline std::shared_ptr<BSplineCurve> b_spline_curve() const {
    return b_spline_curve_;
  }

  const std::shared_ptr<TrackPathActionServer> track_as() { return track_as_; }
  const std::shared_ptr<OpenloopActionServer> openloop_as() {
    return openloop_as_;
  }
  /**
   * \brief setter
   */
  inline void set_task_state(TaskState state) { task_state_ = state; }
  inline void set_start_site(const Site &site) {
    step_ptr_->set_start_site(site);
  }
  inline void set_end_site(const Site &site) { step_ptr_->set_end_site(site); }
  inline void set_center_point(const Point &point) { center_point_ = point; }
  inline void set_radius(double radius) { radius_ = radius; }

  /**
   * \brief finish task
   */
  void TaskFinish(cotek_msgs::track_pathResult res, TaskFinishType type);

  void TaskFinish(cotek_msgs::openloopResult res);

  void TaskPreempt(cotek_msgs::track_pathResult res);

  void TaskPreempt(cotek_msgs::openloopResult res);

  void TaskFeedback(cotek_msgs::track_pathFeedback fb);

  void TaskFeedback(cotek_msgs::openloopFeedback fb);

  inline bool WaitingTask() { return TaskState::WAITING == task_state_; }

  /**
   * \brief check if arrived destination
   * \return true: arrived destination; false otherwise.
   */
  // bool ArrivedDestination() const;

  /**
   * \brief move forward by one site
   */
  void Moveforward();

  /**
   * \brief get task info string
   */
  inline std::string TaskInfoString() {
    return nullptr == step_ptr_ ? std::string("No task...")
                                : step_ptr_->ToString();
  }

  /**
   * \brief action task callback
   * \param task message
   */
  ErrorCode AddTrackPathActionTask(
      const cotek_msgs::track_pathGoalConstPtr &goal,
      std::shared_ptr<TrackPathActionServer> as);

  ErrorCode AddOpenloopActionTask(const cotek_msgs::openloopGoalConstPtr &goal,
                                  std::shared_ptr<OpenloopActionServer> as);

 private:
  /**
   * \brief replanRoute if necessary
   */
  // void ReplanRoute();

  /**
   * \brief a thread keep communicating with server of task state
   */
  void TaskRunner();

  bool is_doing_task_;
  bool start_task_daemon_;
  bool is_forward_;
  std::shared_ptr<Step> step_ptr_;

  TaskState task_state_;
  double radius_;
  Point center_point_;
  std::shared_ptr<BSplineCurve> b_spline_curve_;

  std::shared_ptr<TrackPathActionServer> track_as_;
  std::shared_ptr<OpenloopActionServer> openloop_as_;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_TASK_MANAGER_H_
