/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_CONTROLLER_INTERFACE_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_CONTROLLER_INTERFACE_H_

#include <memory>
#include "cotek_common/log_porting.h"
#include "cotek_msgs/move_cmd.h"
#include "cotek_navigation/enum.h"
#include "cotek_navigation/navigation_options.h"
#include "cotek_navigation/state_manager.h"
#include "cotek_navigation/task_server_manager.h"

namespace cotek_navigation {
using TaskPtr = std::shared_ptr<TaskServerManager>;
using StatePtr = std::shared_ptr<StateManager>;

constexpr double kNoneAvoidRatio = 1.0;
constexpr double kLevel3AvoidRatio = 0.0;

class ControllerInterface {
 public:
  ControllerInterface() {}
  virtual ~ControllerInterface() {}
  virtual void Update(const TaskPtr tm, const StatePtr sm) = 0;
  virtual cotek_msgs::move_cmd GetCommandVelocity(const TaskPtr tm,
                                                  const StatePtr sm) = 0;
  virtual double GetYawBias(const TaskPtr tm, const StatePtr sm) = 0;
  virtual double GetDeltaY(const TaskPtr tm, const StatePtr sm) = 0;
  virtual cotek_msgs::move_cmd StraightLine(const TaskPtr tm, const StatePtr sm,
                                            double dy, double dw) = 0;
  virtual cotek_msgs::move_cmd SelfRotate(const TaskPtr tm, const StatePtr sm,
                                          double dy, double dw) = 0;
  virtual cotek_msgs::move_cmd Arc(const TaskPtr tm, const StatePtr sm,
                                   double dy, double dw) = 0;
  virtual cotek_msgs::move_cmd BSplineCurves(const TaskPtr tm,
                                             const StatePtr sm, double dy,
                                             double dw) = 0;
  virtual cotek_msgs::move_cmd Charging(const TaskPtr tm, const StatePtr sm,
                                        double dy, double dw) = 0;
  virtual cotek_msgs::move_cmd ForkliftUpload(const TaskPtr tm,
                                              const StatePtr sm, double dy,
                                              double dw) = 0;
  virtual cotek_msgs::move_cmd QRUpStabilize(const TaskPtr tm,
                                             const StatePtr sm, double dy,
                                             double dw) = 0;
  virtual cotek_msgs::move_cmd QRDownStabilize(const TaskPtr tm,
                                               const StatePtr sm, double dy,
                                               double dw) = 0;

  inline cotek_msgs::move_cmd ZeroCmdVel() const {
    cotek_msgs::move_cmd cmd_vel;
    cmd_vel.cmd_velocity = 0.;
    cmd_vel.cmd_omega = 0.;
    return cmd_vel;
  }

  const double GetAvoidDecelrationRatio(AvoidanceOption option,
                                        const StatePtr sm) {
    switch (sm->avoid_level()) {
      case AvoidLevel::NONE: {
        return kNoneAvoidRatio;
      }
      case AvoidLevel::LVL1: {
        return option.slow_level1_decel_ratio;
      }
      case AvoidLevel::LVL2: {
        return option.slow_level2_decel_ratio;
      }
      case AvoidLevel::LVL3: {
        return kLevel3AvoidRatio;
      }
      default:
        return 0.;
    }
  }
};
}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_CONTROLLER_INTERFACE_H_
