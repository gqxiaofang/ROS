/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_STEP_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_STEP_H_
#include <ros/ros.h>
#include <string>
#include "cotek_navigation/enum.h"
#include "cotek_navigation/point.h"
#include "cotek_navigation/pose.h"
#include "cotek_navigation/util.h"

namespace cotek_navigation {
constexpr int32_t kInitSpeedValue = 0;

using Pose = cotek_geometry::Pose;
using Point = cotek_geometry::Point;

class Site {
 public:
  Site() : id_(0) {}
  explicit Site(int32_t id) : id_(id) {}
  Site(int32_t id, double x, double y, double yaw) : id_(id) {
    pose_.set(x, y, yaw);
  }

  int32_t id() const { return id_; }
  double x() const { return pose_.x(); }
  double y() const { return pose_.y(); }
  double yaw() const { return pose_.yaw(); }
  const Point point() const { return pose_.point(); }
  const Pose &pose() const { return pose_; }

  void set_id(int32_t id) { id_ = id; }
  void set_pose(const Pose &pose) { pose_ = pose; }
  void set_point(const Point &point) { pose_.set_point(point); }
  void set_yaw(double yaw) { pose_.set_yaw(yaw); }

 private:
  int32_t id_;
  Pose pose_;
};

class Step {
 public:
  /**
   * \brief default constuctor of step
   */
  Step()
      : navi_type_(NaviType::NONE),
        motion_type_(MotionType::NONE),
        next_path_type_(PathType::NONE),
        point_id_(0),
        point_(Point(0.0, 0.0)),
        yaw_(0.0),
        control_point0_(Point(0.0, 0.0)),
        control_point1_(Point(0.0, 0.0)),
        odom_(0.0),
        avoid_strategy_code_(-1),
        max_speed_(kInitSpeedValue),
        target_speed_(kInitSpeedValue) {}

  /**
   * \brief default setter of private variable
   */
  inline void set_navi_type(NaviType type) { navi_type_ = type; }
  inline void set_motion_type(MotionType type) { motion_type_ = type; }
  inline void set_next_path_type(PathType type) { next_path_type_ = type; }
  inline void set_point_id(int32_t id) { point_id_ = id; }
  inline void set_point(const Point &pt) { point_ = pt; }
  void set_control_point(const Point &pt0, const Point &pt1) {
    if (MotionType::B_SPLINE_CURVES == motion_type_) {
      control_point0_ = pt0;
      control_point1_ = pt1;
    } else if (MotionType::ARC == motion_type_) {
      control_point0_ = pt0;
    } else {
      // if not follow CURVES, set to 0
      // ROS_WARN("not follow route move, can not set control point");
      control_point0_ = Point(0., 0.);
      control_point1_ = Point(0., 0.);
    }
  }
  inline void set_intended_orientation(float yaw) { yaw_ = yaw; }
  inline void set_avoid_strategy_code(int32_t code) {
    avoid_strategy_code_ = code;
  }
  inline void set_odom(double odom) { odom_ = odom; }
  inline void set_max_speed(double speed) { max_speed_ = speed; }
  inline void set_max_omega(double omega) { max_omega_ = omega; }
  inline void set_target_speed(double speed) { target_speed_ = speed; }
  void set_start_site(const Site &site) { start_site_ = site; }
  void set_end_site(const Site &site) { end_site_ = site; }

  /**
   * \brief default getter of private variable
   */
  inline NaviType navi_type() const { return navi_type_; }
  inline MotionType motion_type() const { return motion_type_; }
  inline PathType next_path_type() const { return next_path_type_; }
  inline int32_t point_id() const { return point_id_; }
  inline const Point &point() const { return point_; }
  inline const Point &control_point_0() const { return control_point0_; }
  inline const Point &control_point_1() const { return control_point1_; }
  inline float intended_orientation() const { return yaw_; }
  inline int32_t avoid_strategy_code() const { return avoid_strategy_code_; }
  inline double odom() const { return odom_; }
  inline double max_speed() const { return max_speed_; }
  inline double max_omega() const { return max_omega_; }
  inline double target_speed() const { return target_speed_; }

  inline const Site &start_site() const { return start_site_; }
  inline const Site &end_site() const { return end_site_; }

  /**
   * \brief default step info to string
   */
  std::string ToString() {
    std::stringstream ss;
    ss << "NavigationInfo { "
       << "NaviType: " << static_cast<int32_t>(navi_type_)
       << ", MotionType: " << static_cast<int32_t>(motion_type_)
       << ", Next PathType:" << static_cast<int32_t>(next_path_type_)
       << ", pointId: " << point_id_ << ", pose: (" << point_.x() << ", "
       << point_.y() << ", " << yaw_ << ")"
       << ", controlPoint0: (" << control_point0_.x() << ", "
       << control_point0_.y() << ")"
       << ", controlPoint1: (" << control_point1_.x() << ", "
       << control_point1_.y() << ")"
       << ", odom: " << odom_ << ", avoidStrategyCode: " << avoid_strategy_code_
       << ", maxSpeed: " << max_speed_ << ", targetSpeed: " << target_speed_
       << "}";
    return ss.str();
  }

 private:
  NaviType navi_type_;
  MotionType motion_type_;
  PathType next_path_type_;
  int32_t point_id_;
  Point point_;
  float yaw_;
  Point control_point0_;
  Point control_point1_;
  int32_t avoid_strategy_code_;
  double odom_;
  double max_speed_;
  double target_speed_;
  double max_omega_;

  Site start_site_;
  Site end_site_;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_STEP_H_
