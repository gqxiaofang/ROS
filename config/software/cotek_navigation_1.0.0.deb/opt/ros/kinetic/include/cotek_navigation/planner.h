/**
 * Copyright (c) 2018 CoTEK Inc. All rights reserved.
 */

#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_PLANNER_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_PLANNER_H_
#include <map>
#include "cotek_navigation/free_controller.h"
#include "cotek_navigation/magnetic_controller.h"
#include "cotek_navigation/navigation_options.h"
#include "cotek_navigation/openloop_controller.h"
#include "cotek_navigation/state_manager.h"
#include "cotek_navigation/task_server_manager.h"
#include "ros/ros.h"

namespace cotek_navigation {

using TaskPtr = std::shared_ptr<TaskServerManager>;
using StatePtr = std::shared_ptr<StateManager>;
using Pose = cotek_geometry::Pose;
using Point = cotek_geometry::Point;

/**
 * \class Planner
 * \brief implemention of velocity command algorithm
 */
class Planner {
 public:
  /**
   * \brief default constructor
   */
  Planner() = delete;

  /**
   * \brief construct object with options
   * \param option all FreeController related parameters
   */
  explicit Planner(const PlannerOption &option);

  inline void EnableFreeController() { option_.enable_free_controller = true; }
  inline void EnableMagController() { option_.enable_mag_controller = true; }
  inline void EnableOpenloopController() {
    option_.enable_openloop_controller = true;
  }
  inline void DisableFreeController() {
    option_.enable_free_controller = false;
  }
  inline void DisableMagController() { option_.enable_mag_controller = false; }
  inline void DisableOpenloopController() {
    option_.enable_openloop_controller = false;
  }
  bool Update(const TaskPtr tm, const StatePtr sm);
  cotek_msgs::move_cmd Plan(const TaskPtr tm, const StatePtr sm);

 private:
  inline bool IsHybrid() {
    return option_.enable_free_controller && option_.enable_free_controller;
  }
  bool SetController(const TaskPtr tm, const StatePtr sm);
  bool SetMagController(const TaskPtr tm, const StatePtr sm);
  bool SetFreeController(const TaskPtr tm, const StatePtr sm);
  bool SetOpenloopController(const TaskPtr tm, const StatePtr sm);
  void EnableLocalizer(const Pose &pose);
  void DisableLocalizer();

  ControllerInterface *controller_;
  PlannerOption option_;
  MagneticController mag_ctrl_;
  FreeController free_ctrl_;
  OpenloopController openloop_ctrl_;
  ros::ServiceClient localizer_srv_;
};

}  // namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_PLANNER_H_
