/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_NAVIGATION_H_
#define COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_NAVIGATION_H_
#include <ros/ros.h>
#include <string>
#include <thread>
#include "cotek_common/cotek_topic_name.h"
#include "cotek_common/node_diagnostic_info.h"
#include "cotek_navigation/navigation_options.h"
#include "cotek_navigation/navigation_server_name.h"
#include "cotek_navigation/planner.h"
#include "cotek_navigation/state_manager.h"
#include "cotek_navigation/task_server_manager.h"

namespace cotek_navigation {
/**
 * class Navigation: start an action server and calculate cmd_vel
 */
class Navigation {
 public:
  Navigation();

  /**
   * \brief destructor
   */
  ~Navigation();

  /**
   * \brief option getter
   * \return LocalizerOption
   */
  inline NavigationOption Option() const { return option_; }

  /**
   * \brief do initialization
   * \return true if init succeeded
   */
  bool Init();

  /**
   * \brief start a thread and excute cycle
   */
  void Run();

  void AddTrackPathActionTask(const cotek_msgs::track_pathGoalConstPtr& goal,
                              std::shared_ptr<TrackPathActionServer> as);

  void AddOpenloopActionTask(const cotek_msgs::openloopGoalConstPtr& goal,
                             std::shared_ptr<OpenloopActionServer> as);

  void AddMoveFeedbackData(const cotek_msgs::move_feedback::ConstPtr& feedback);

  void AddSafetyStateData(const cotek_msgs::safety_state::ConstPtr& feedback);

  void AddPalletForkIoStateData(
      const cotek_msgs::pallet_fork_io_state::ConstPtr& feedback);

  void AddBatteryData(const cotek_msgs::battery::ConstPtr& feedback);

  bool UpdateOption(const NavigationOption& option);

  // TODO(@someone) 校验配置参数是否合法
  bool CheckOption(const NavigationOption& option);

 private:
  /**
   * \brief excute the task send by action client
   * \param goal task goal which contains the whole navigation route
   */
  void Runner();

  /**
   * \brief handle error
   * \return true if can continue, false otherwise
   */
  void HandleError();

  // 节点监控
  void NodeDiagnostic(const ros::TimerEvent& e);

  inline void SetNodeStatus(
      const cotek_diagnostic::NavigationNodeStatus& status) {
    node_status_ = static_cast<uint16_t>(status);
  }

  std::shared_ptr<TaskServerManager> ts_;
  std::shared_ptr<StateManager> sm_;
  NavigationOption option_;
  boost::shared_ptr<Planner> planner_;
  std::shared_ptr<std::thread> executor_;

  // publish velocity command
  ros::Publisher vel_pub_;

  std::map<std::string, ros::Publisher> msg_publishers_;
  uint16_t node_status_;
  ros::Timer node_diagnostic_timer_;

  bool config_init_success_;
};

}  // end of namespace cotek_navigation

#endif  // COTEK_NAVIGATION_INCLUDE_COTEK_NAVIGATION_NAVIGATION_H_
