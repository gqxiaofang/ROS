/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
// TODO(@someone)