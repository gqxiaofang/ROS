/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_RFID_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_RFID_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct rfidData {
  // RFID值
  uint32_t rfid_tag;
  uint8_t strength;
};

// RFID的驱动
class RfidDriver : public AbstractDriver {
 public:
  RfidDriver();
  ~RfidDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

 private:
  // 这里只是个demo，实际需根据业务对象来重命名回调函数，确保代码可读性
  void HinsonRfidFeedback(const VCI_CAN_OBJ data);

  int channel_;
  int feedback_id_;
  ros::Time time_;
  rfidData data_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_RFID_DRIVER_H_
