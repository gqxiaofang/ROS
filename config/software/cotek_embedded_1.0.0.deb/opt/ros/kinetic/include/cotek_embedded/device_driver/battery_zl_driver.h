/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_ZL_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_ZL_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct BatteryZLData {
  uint32_t time_stamp;
  uint16_t voltage;
  int16_t current;
  uint8_t soc;
};

class BatteryZLDriver : public AbstractDriver {
 public:
  BatteryZLDriver();
  ~BatteryZLDriver();
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  bool IsReady();

  void BatteryBMSRebotSetMsg3();
  void BatteryBMSRebotSetMsg4();

  inline void SetCharge(bool charge) { is_charge_ = charge; }

 private:
  void ZLBatteryFeedback(const VCI_CAN_OBJ data);

  bool is_charge_;

  int channel_;
  int battery_bms_zl_id_;

  BatteryZLData data_;
  ros::Time time_;
};

}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_ZL_DRIVER_H_
