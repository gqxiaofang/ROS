/**
 * Copyright (c) 2018 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ROS_VIRTUAL_DRIVER_ODOM_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ROS_VIRTUAL_DRIVER_ODOM_H_

#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <tf/tf.h>
#include <string>

namespace cotek_embedded {
class Odom {
 public:
  Odom() : x_(0.0), y_(0.0), theta_(0.0), init_(false), sequence_(0) {}

  inline double x() const { return x_; }
  inline double y() const { return y_; }
  inline double theta() const { return theta_; }
  inline uint32_t sequence() const { return sequence_; }

  void Update(const ros::Time &stamp, double v, double omega);

  nav_msgs::Odometry ToRosOdometryMsg();
  geometry_msgs::TransformStamped ToRosTransfrom();

 private:
  ros::Time stamp_;
  double x_;
  double y_;
  double theta_;
  double v_;
  double w_;
  bool init_;
  uint32_t sequence_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ROS_VIRTUAL_DRIVER_ODOM_H_
