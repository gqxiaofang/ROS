/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_OPTIONS_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_OPTIONS_H_
#include <string>
#include "cotek_common/cotek_option.h"

namespace cotek_embedded {
// 移动模型参数
struct MoveModelOption {
  BicycleModelOption bicycle_model_option;
  UnicycleModelOption unicycle_model_option;
};

struct EmbeddedControllerOption {
  double can_send_frequency;
  double clear_cycle_number;
  bool enable_local_debug;
  std::string config_filename;
  MoveModelOption move_model_option;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_OPTIONS_H_
