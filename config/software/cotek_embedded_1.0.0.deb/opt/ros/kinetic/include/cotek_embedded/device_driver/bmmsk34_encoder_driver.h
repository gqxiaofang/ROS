/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BMMSK34_ENCODER_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BMMSK34_ENCODER_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

//  Canopen波特率对照表
// 10kbit  00
// 20kbit  01
// 50kbit  02
// 100kbit  03
// 125kbit  04
// 250kbit  05
// 500kbit  06
// 800kbit  07
// 1000kbit  08

struct Bmmsk34EncoderData {
  uint32_t time_stamp;
  int length;  // 高度值， 当前值 - 初始化
};

// 堡盟拉线传感器驱动
class Bmmsk34EncoderDriver : public AbstractDriver {
 public:
  Bmmsk34EncoderDriver();
  ~Bmmsk34EncoderDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();


  // 保留
  // void SetSingleTurnResolution(uint32_t resolution);
  // void SetOverallResolution(uint32_t resolution);
  void SetNodeId(uint8_t node_id);
  void SetBaudrate(uint8_t index);
  void SaveParam();
  void SetUpdateTime(uint16_t ms);
  void IsDisconnected();

 private:
  // can 接收数据
  void DataFeedback(const VCI_CAN_OBJ data);
  void ParamFeedback(const VCI_CAN_OBJ data);
  void HeartBeatCallBack(const VCI_CAN_OBJ data);
  void NMTStart();
  void NMTStop();
  void NMTReset();

  std::shared_ptr<MessagePublisher> bmmsk34_encoder_pub_;
  std::shared_ptr<MessagePublisher> nmt_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int bmmsk34_encoder_id_;
  int param_feedback_id_;
  int data_feedback_id_;
  int heartbeat_id_;

  Bmmsk34EncoderData data_;

  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BMMSK34_ENCODER_DRIVER_H_
