/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_PGV_R2100_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_PGV_R2100_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct PgvR2100OriginData {
  uint8_t head[4];
  uint8_t distance[44];
  uint8_t reserv;
  uint8_t crc;
};
struct PgvR2100Data {
  int time_stamp;
  float distance[11];
  uint16_t error_code;
};
struct ObstacleData {
  float obstacle_distance;
};

class PgvR2100Driver : public AbstractDriver {
 public:
  PgvR2100Driver();
  ~PgvR2100Driver();

  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

  void SendPgvR2100Cmd();

 private:
  void HandleFeedback(const VCI_CAN_OBJ data);
  void ClearErrorCode();
  void SetBaudrate();
  void SetFeedbackFrequency(unsigned char ms);

  void NMTStart();
  void NMTStop();
  void NMTReset();

  std::shared_ptr<MessagePublisher> pr_pub_;
  std::shared_ptr<MessagePublisher> nmt_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int pr_set_id_;
  int feedback_id_;

  int num_of_pkg_;

  ObstacleData obstracle_data_;
  uint8_t origin_pgv_r2100_data_[50];

  PgvR2100Data data_;

  ros::Time time_;
};
}  // namespace cotek_embedded

#endif