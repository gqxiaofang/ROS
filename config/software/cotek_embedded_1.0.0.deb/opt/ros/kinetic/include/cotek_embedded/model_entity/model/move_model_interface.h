/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MODEL_MOVE_MODEL_INTERFACE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MODEL_MOVE_MODEL_INTERFACE_H_
#include <boost/algorithm/clamp.hpp>
#include <cmath>
#include <tuple>
#include "cotek_common/common.h"
#include "cotek_common/log_porting.h"
#include "cotek_common/math.h"
#include "cotek_embedded/embedded_controller_options.h"
#include "cotek_msgs/move_cmd.h"
#include "cotek_msgs/move_feedback.h"

namespace cotek_embedded {

class MoveModelInterface {
 public:
  virtual cotek_msgs::move_feedback GetMove(float, float) = 0;
  virtual std::tuple<float, float> SetMove(
      const cotek_msgs::move_cmd::ConstPtr& msg) = 0;

  virtual void UpdateWheelBase(float wheelbase) = 0;
};

class MoveBicycleModel : public MoveModelInterface {
  struct MoveData {
    double v;
    double w;
  };

 public:
  MoveBicycleModel() = delete;
  explicit MoveBicycleModel(const BicycleModelOption& option)
      : option_(option) {}

  /**
   *  @brief  自行车模型下 vd, theta 转化为 v, w
   *  [driver_velocity, steering_angle] --> [actual_velocity, actual_omega]
   *  @param  driver_velocity  舵轮速度 m/s
   *  @param  steering_angle   舵轮转角 弧度 (-1.57 ~ 1.57)
   */
  cotek_msgs::move_feedback GetMove(float driver_velocity,
                                    float steering_angle) {
    cotek_msgs::move_feedback msg;
    msg.actual_velocity = driver_velocity;
    msg.actual_omega =
        driver_velocity * std::sin(steering_angle) / option_.wheel_base;

    return msg;
  }

  /*
  (cmd_velocity, cmd_omega) --> (driver_velocity, steering_angle)
  */
  std::tuple<float, float> SetMove(const cotek_msgs::move_cmd::ConstPtr& msg) {
    float angle = 0.f;
    float speed = 0.f;

    if (option_.use_inertia_compensation) {
      double compensate_v =
          msg->cmd_velocity +
          (msg->cmd_velocity - cmd_fdbk.v) * 30 * option_.velocity_coefficient;
      double compensate_w = msg->cmd_omega + (msg->cmd_omega - cmd_fdbk.w) *
                                                 30 * option_.omega_coefficient;

      angle = std::atan(compensate_w * option_.wheel_base / compensate_v);
      speed = msg->cmd_velocity;
    } else {
      angle =
          std::atan(msg->cmd_omega * option_.wheel_base / msg->cmd_velocity);
      float temp = math::NearZero(std::cos(angle)) ? 0.001 : std::cos(angle);
      // 限速 -3m/s ~ 3m/s
      speed = msg->cmd_velocity;
    }

    return std::make_tuple(speed, angle);
  }

  // 更新轴距 m
  void UpdateWheelBase(float wheelbase) { option_.wheel_base = wheelbase; }

 private:
  BicycleModelOption option_;
  MoveData cmd_fdbk;
  MoveData last_cmd;
};

class MoveUnicycleModel : public MoveModelInterface {
 public:
  MoveUnicycleModel() = delete;

  explicit MoveUnicycleModel(const UnicycleModelOption& option)
      : option_(option) {}

  /**
   *  @brief  独轮车模型下 v_l, v_r 转化为 v, w
   *  [left_rpm, right_rpm] --> [actual_velocity, actual_omega]
   *  @param  left_rpm  左轮转速
   *  @param  right_rpm  右轮转速
   */
  cotek_msgs::move_feedback GetMove(float left_rpm, float right_rpm) {
    cotek_msgs::move_feedback msg;
    auto left_vel = common::RPMToWheelVelocity(left_rpm, option_.wheel_diameter,
                                               option_.move_motor_reduce_ratio);
    auto right_vel = -common::RPMToWheelVelocity(
        right_rpm, option_.wheel_diameter, option_.move_motor_reduce_ratio);

    msg.actual_velocity = common::WheelVelToVelocity(left_vel, right_vel);
    msg.actual_omega =
        common::WheelVelToOmega(left_vel, right_vel, option_.wheel_track);
    return msg;
  }

  /*
  (cmd_velocity, cmd_omega) --> (left_rpm, right_rpm)
  */
  std::tuple<float, float> SetMove(const cotek_msgs::move_cmd::ConstPtr& msg) {
    auto left_velocity = common::CalcLeftVelocity(
        msg->cmd_velocity, msg->cmd_omega, option_.wheel_track);
    auto right_velocity = common::CalcRightVelocity(
        msg->cmd_velocity, msg->cmd_omega, option_.wheel_track);

    auto left_rpm = common::WheelVelocityToRPM(
        left_velocity, option_.wheel_diameter, option_.move_motor_reduce_ratio);
    auto right_rpm =
        -common::WheelVelocityToRPM(right_velocity, option_.wheel_diameter,
                                    option_.move_motor_reduce_ratio);

    return std::make_tuple(left_rpm, right_rpm);
  }

  void UpdateWheelBase(float wheelbase) {}

 private:
  UnicycleModelOption option_;
};

}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MODEL_MOVE_MODEL_INTERFACE_H_
