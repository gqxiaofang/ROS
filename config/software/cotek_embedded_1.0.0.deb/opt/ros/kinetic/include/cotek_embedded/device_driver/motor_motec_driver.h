/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_MOTOR_MOTEC_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_MOTOR_MOTEC_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"
#include "cotek_embedded/message_publisher.h"

namespace cotek_embedded {

struct MotecData {
  int16_t rpm;
  int16_t current;
};
// 柯蒂斯的驱动
class MotorMotecDriver : public AbstractDriver {
 public:
  MotorMotecDriver();
  ~MotorMotecDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  // 私有接口
  void SetControl(double speed);

 private:
  // 状态量的Getters
  void HandleMotorMotecDataFeedback(const VCI_CAN_OBJ data);
  void SetEnable();

  // 消息发送句柄，每个publisher拥有一个消息的设备ID
  std::shared_ptr<MessagePublisher> control_pub_;
  std::shared_ptr<MessagePublisher> enable1_pub_;
  std::shared_ptr<MessagePublisher> enable2_pub_;

  int channel_;
  int enableCmd_;
  int enableCmd_1;
  int enableCmd_2;
  int enableCmd_3;
  int enableCmd_4;
  int disenableCmd;

  int feedback_id_;
  int heartback_id_;
  int control_id_;
  int enable_id2_;
  int enable_id1_;

  MotecData data_;
  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_MOTOR_MOTEC_DRIVER_H_
