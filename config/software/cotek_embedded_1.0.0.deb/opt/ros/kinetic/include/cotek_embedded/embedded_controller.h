/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_H_
#include <ros/ros.h>
#include <unistd.h>
#include <map>
#include <memory>
#include <string>
#include <thread>
#include "cotek_common/config_helper.h"
#include "cotek_common/cotek_topic_name.h"
#include "cotek_embedded/can_message_center.h"
#include "cotek_embedded/embedded_controller_options.h"
#include "cotek_embedded/model_entity/forklift_hardware.h"
#include "cotek_embedded/model_entity/heap_forklift_hardware.h"
#include "cotek_embedded/model_entity/jack_up_hardware.h"
#include "cotek_embedded/model_entity/linde_forklift_hardware.h"
#include "cotek_embedded/model_entity/model/hardware_interface.h"
#include "cotek_embedded/model_entity/nuo_li_pallet_forklift_hardware.h"
#include "cotek_embedded/model_entity/tractor_car_hardware.h"
#include "cotek_embedded/model_entity/transplant_hardware.h"
#include "cotek_msgs/node_diagnostic.h"

namespace cotek_embedded {

enum class EmbeddedNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  DEVICE_INIT_ERROR = 1,
  CAN_INIT_ERROR = 2,
  AGV_HARDWARE_INIT_ERROR = 3,
  CAN0_SEND_FAILED = 4,
  CAN1_SEND_FAILED = 5,
  // 警告(自行增加)
  CAN_CYCLE_TIME_OUT = 21
};

class EmbeddedController {
 public:
  /**
   * \brief delete default constructor, embedded controller cannot work properly
   * without options
   */
  EmbeddedController() = delete;

  /**
   * \brief construct object with options
   * \param option all embedded controller related parameters
   */
  explicit EmbeddedController(const EmbeddedControllerOption& option);

  ~EmbeddedController();

  bool Init();

  // 输入 v,w
  inline void AddMoveCmdMsg(const cotek_msgs::move_cmd::ConstPtr& move_cmd) {
    hardware_builder_->InputMoveCmdMsg(move_cmd);
  }
  // 输入 safety_setting
  inline void AddSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr& safety_setting) {
    hardware_builder_->InputSafetySettingMsg(safety_setting);
  }

  // 不同车型的动作抽象数据不一样
  // 输入叉车动作
  void AddForkLiftActionMsg(
      const cotek_msgs::forklift_action::ConstPtr& forklift_action) {
    hardware_builder_->InputActionMsg(forklift_action);
  }

  // 输入顶升动作
  void AddJackUpActionMsg(
      const cotek_msgs::jack_up_action::ConstPtr& jack_up_action) {
    hardware_builder_->InputActionMsg(jack_up_action);
  }

  void Run();

 private:
  void Runner();

  inline void SendCanMsg() {
    if (!CanMessageCenter::Instance().SendCan0MsgBuffer()) {
      LOG_ERROR("can0 send msg failed!");
      SetNodeStatus(EmbeddedNodeStatus::CAN0_SEND_FAILED);
    }

    if (!CanMessageCenter::Instance().SendCan1MsgBuffer()) {
      LOG_ERROR("can1 send msg failed!");
      SetNodeStatus(EmbeddedNodeStatus::CAN1_SEND_FAILED);
    }
  }

  EmbeddedControllerOption option_;
  EmbeddedNodeStatus status_;
  ros::Timer timer_;
  ros::Publisher node_diagnostic_pub_;
  std::shared_ptr<HardwareInterface> hardware_builder_;

  std::shared_ptr<std::thread> run_executor_;
  bool clear_control_data_flag_;

  void NodeDiagnostic(const ros::TimerEvent& e);
  inline void SetNodeStatus(const EmbeddedNodeStatus& status) {
    status_ = status;
  }
};

}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_H_
