/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_UDP_MESSAGE_H_
#define COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_UDP_MESSAGE_H_
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>
#include "cotek_common/cotek_protocal.h"

namespace cotek_communicate {

/**
 * \class UdpMessage
 * \brief data message for udp communication
 */
class UdpMessage {
 public:
  UdpMessage() {}

  explicit UdpMessage(std::string bind_id, std::string msg_type)
      : buffer_{0}, msg_length_(0) {
    protocal_pack_.bind_id = bind_id;
    protocal_pack_.msg_type = msg_type;
  }

  inline bool ParseMsgToJson() {
    std::string msg_string(buffer_);
    std::string err;
    msg_json_ = json11::Json::parse(msg_string, err);
    if (!err.empty()) {
      return false;
    }
    return true;
  }

  inline void PackMsg() {
    // 打包整个数据包
    json11::Json msg_json =
        json11::Json::object{{"bindId", protocal_pack_.bind_id},
                             {"msgType", protocal_pack_.msg_type},
                             {"msgHash", protocal_pack_.msg_hash},
                             {"msgData", protocal_pack_.msg_data}};
    std::string msg_string(msg_json.dump());
#if 0
    LOG_INFO_STREAM("send udp msg size: " << msg_string.size());
    LOG_DEBUG_STREAM("udp msg: " << msg_string);
#endif
    msg_length_ = msg_string.copy(buffer_, msg_string.size());
    // std::strcpy(buffer_, msg_string.c_str());
    buffer_[msg_length_] = '\0';
  }

  inline void Clear() {
    std::memset(buffer_, 0, cotek_protocal::kMaxUdpBuffer);
    msg_length_ = 0;
    protocal_pack_.bind_id.clear();
    protocal_pack_.msg_type.clear();
    protocal_pack_.msg_data.clear();
    protocal_pack_.msg_hash.clear();
    msg_json_ = json11::Json();
  }

  /**
   * 设置数据接口
   */
  inline void SetMsgBind(const std::string &bind_id) {
    protocal_pack_.bind_id = bind_id;
  }

  inline void SetMsgType(const std::string &msg_type) {
    protocal_pack_.msg_type = msg_type;
  }

  inline void SetMsgData(const std::string &msg_data) {
    protocal_pack_.msg_data = msg_data;
  }

  inline void GenerateMsgHash() {
    protocal_pack_.msg_hash = CalculateMd5Sum(protocal_pack_.msg_data);
  }

  /**
   * 获取数据接口
   */
  inline std::string MsgBind() { return msg_json_["bindId"].string_value(); }

  inline std::string MsgType() { return msg_json_["msgType"].string_value(); }

  inline std::string MsgData() { return msg_json_["msgData"].string_value(); }

  inline bool CheckMsgHash() {
    // return msg_json_["msgHash"].string_value() ==
    //                CalculateMd5Sum(msg_json_["msgData"].string_value())
    //            ? true
    //            : false;
    return true;
  }

  inline char *Data() { return buffer_; }

  inline std::size_t ReadBufferSize() { return cotek_protocal::kMaxUdpBuffer; }

  inline std::size_t SendBufferSize() { return msg_length_; }

 private:
  // 计算校验码 md5sum
  std::string CalculateMd5Sum(const std::string &msg_data) {
    unsigned char md5_sum[16];
    MD5_CTX ctx;
    MD5_Init(&ctx);
    MD5_Update(&ctx, protocal_pack_.msg_data.data(),
               protocal_pack_.msg_data.size());
    MD5_Final(md5_sum, &ctx);
#if 0
      for (int i = 0; i < 16; ++i) {
        LOG_DEBUG("%02x ", md5_sum[i]);
      }
#endif
    return Char2String(md5_sum, sizeof(md5_sum));
  }

  // 例： 0xa1 --> "a1"
  std::string Char2String(const unsigned char *chr, int num) {
    std::string temp;
    for (int i = 0; i < num; i++) {
      unsigned char temp_high = *(chr + i) / 16;
      unsigned char temp_low = *(chr + i) % 16;
      temp_high = temp_high > 9 ? temp_high - 10 + 'a' : temp_high + '0';
      temp_low = temp_low > 9 ? temp_low - 10 + 'a' : temp_low + '0';
      temp.push_back(temp_high);
      temp.push_back(temp_low);
    }
    return temp;
  }

  // 数据缓存, 发送接收的单个数据包都不能超过最大缓存 kMaxUdpBuffer
  char buffer_[cotek_protocal::kMaxUdpBuffer];
  // 发送数据长度
  std::size_t msg_length_;
  // 协议包
  cotek_protocal::CotekUdpProtocal protocal_pack_;
  // 协议包反序列化后的 json对象
  json11::Json msg_json_;
};

}  // end of namespace cotek_communicate

#endif  // COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_UDP_MESSAGE_H_
