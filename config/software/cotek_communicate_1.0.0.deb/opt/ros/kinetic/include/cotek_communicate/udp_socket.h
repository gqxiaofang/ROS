/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_UDP_SOCKET_H_
#define COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_UDP_SOCKET_H_

#include <ros/ros.h>
#include <boost/asio.hpp>
#include <boost/thread/thread.hpp>
#include <deque>
#include <functional>
#include <iostream>
#include <string>
#include <utility>

namespace cotek_communicate {

using boost::asio::ip::address_v4;
using boost::asio::ip::udp;

template <typename MessageType>
class UdpSocket {
 public:
  /**
   * \brief constructor
   * \param ip remote ip address
   * \param port remote service port
   */
  explicit UdpSocket(std::string ip, unsigned int port)
      : local_host_(udp::v4(), port),
        remote_host_(address_v4::from_string(ip), port) {
    socket_ = boost::make_shared<udp::socket>(service_, local_host_);
  }

  /**
   * \brief destructor
   */
  ~UdpSocket() {
    service_.post([this]() { socket_->close(); });
    service_.stop();
  }

  void Run() {
    runner_ = boost::make_shared<boost::thread>([this]() {
      try {
        service_.run();
      } catch (boost::system::system_error &e) {
        LOG_ERROR_STREAM(e.what());
      }
    });
  }

  void Close() {
    service_.post([this]() {
      socket_->close();
      LOG_INFO_STREAM("Udp socket closed...");
    });
  }

  void Listen(std::function<void(MessageType)> handler) { DoRead(handler); }

  void Send(const MessageType &msg) {
    service_.post([this, msg]() {
      bool write_in_progress = !w_messageQueue_.empty();
      w_messageQueue_.push_back(msg);

      if (!write_in_progress) {
        DoWrite();
      }
    });
  }

 protected:
  void DoRead(std::function<void(MessageType)> handler) {
    r_message_.Clear();
    socket_->async_receive_from(
        boost::asio::buffer(r_message_.Data(), r_message_.ReadBufferSize()),
        local_host_,
        [this, handler](boost::system::error_code ec, std::size_t length) {
          if (!ec) {
            if (length <= 0) {
              LOG_ERROR_STREAM("Receive data length = 0.");
            } else {
              LOG_DEBUG_STREAM("udp async read length: " << length);
              handler(r_message_);
            }
          } else {
            LOG_ERROR_STREAM(ec.message());
            // socket_->close();
          }

          DoRead(handler);
        });
  }

  void DoWrite() {
    socket_->async_send_to(
        boost::asio::buffer(w_messageQueue_.front().Data(),
                            w_messageQueue_.front().SendBufferSize()),
        remote_host_, [this](boost::system::error_code ec, std::size_t length) {
          if (!ec) {
            w_messageQueue_.pop_front();

            if (!w_messageQueue_.empty()) {
              DoWrite();
            }
          } else {
            LOG_ERROR_STREAM(ec.message());
            // socket_->close();
          }
        });
  }

 private:
  std::deque<MessageType> w_messageQueue_;
  MessageType r_message_;

  boost::asio::io_service service_;
  boost::shared_ptr<udp::socket> socket_;
  boost::shared_ptr<boost::thread> runner_;

  udp::endpoint local_host_;
  udp::endpoint remote_host_;
};

}  // namespace cotek_communicate

#endif  // COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_UDP_SOCKET_H_
