/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_COMMUNICATE_H_
#define COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_COMMUNICATE_H_
#include <arpa/inet.h>
#include <net/if.h>
#include <netinet/in.h>
#include <ros/ros.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>
#include <boost/asio.hpp>
#include <boost/thread/thread.hpp>
#include <cstring>
#include <iostream>
#include <map>
#include <memory>
#include <numeric>
#include <string>
#include <thread>
#include <vector>
#include "cotek_common/cotek_config_helper.h"
#include "cotek_common/cotek_topic_name.h"
#include "cotek_common/log_porting.h"
#include "cotek_common/node_diagnostic_info.h"
#include "cotek_common/ping_tool.h"
#include "cotek_communicate/communicate_options.h"
#include "cotek_communicate/udp_message.h"
#include "cotek_communicate/udp_socket.h"
#include "cotek_msgs/node_diagnostic.h"
#include "cotek_msgs/task_calibration_request.h"
#include "cotek_msgs/task_control_request.h"
#include "cotek_msgs/task_finish_request.h"
#include "cotek_msgs/task_get_map_request.h"
#include "cotek_msgs/task_request.h"
#include "cotek_msgs/task_response.h"
#include "cotek_msgs/update_event.h"

namespace cotek_communicate {
class Communicate {
 public:
  Communicate();

  Communicate &operator=(const Communicate &) = delete;
  ~Communicate() {
    if (network_checking_daemon_) {
      network_checking_daemon_->join();
      network_checking_daemon_ = nullptr;
    }
  }

  bool Init();

  bool Start();

  bool UpdateOption(const CommunicateOption &option);

  // 输入其他节点数据
  void AddUpdateEventMsg(
      const cotek_msgs::update_event::ConstPtr &update_event);

  void AddTaskResponseMsg(
      const cotek_msgs::task_response::ConstPtr &task_response);

  void AddTaskFinishRequestMsg(
      const cotek_msgs::task_finish_request::ConstPtr &task_finish_request);

 private:
  // 发送数据接口 输入数据包类型和数据包数据
  void Send(const std::string &msg_type, const std::string &msg_data);
  void Send(const std::string &bind_id, const std::string &msg_type,
            const std::string &msg_data);

  // 得到本机ip接口
  bool GetIP(const std::string &vNetType, std::string *strip);

  // udp 数据回调终端, 校验数据 并 分发给不同的回调函数
  void MessageCallback(UdpMessage msg);

  // 不同数据包数据 回调函数
  void TaskResponseHandler(std::string data);
  void TaskRequestHandler(std::string data);
  void TaskControlRequestHandler(std::string data);
  void TaskCalibrationRequestHandler(std::string data);
  void TaskGetMapRequestHandler(std::string data);
  // 参数上传
  void TaskPushParamRequestHandler(std::string data);
  // 参数更新
  void TaskUpdateNavigationParamHandler(std::string data);
  void TaskUpdateActionParamHandler(std::string data);

  // 节点监控
  void NodeDiagnostic(const ros::TimerEvent &e);

  // 通讯链路保持连接,掉线检测
  void NetWorkLinkCheck();

  inline void SetNodeStatus(
      const cotek_diagnostic::CommunicateNodeStatus &status) {
    node_status_ = static_cast<uint16_t>(status);
  }

  std::shared_ptr<std::thread> network_checking_daemon_;

  uint16_t node_status_;
  ros::Timer node_diagnostic_timer_;
  ros::Timer network_link_timer_;

  CommunicateOption option_;
  std::map<std::string, ros::Publisher> msg_publishers_;
  std::map<std::string, std::function<void(std::string)>> handler_;
  std::shared_ptr<UdpSocket<UdpMessage>> socket_;
  cotek_tool::PingTool ping_tool_;

  ros::ServiceClient update_logic_config_service_client_;
  ros::ServiceClient update_navigation_config_service_client_;
  ros::ServiceClient update_action_config_service_client_;
};

}  // namespace cotek_communicate

#endif  // COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_COMMUNICATE_H_
