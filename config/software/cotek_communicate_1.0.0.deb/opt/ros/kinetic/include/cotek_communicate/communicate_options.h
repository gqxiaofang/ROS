/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_COMMUNICATE_OPTIONS_H_
#define COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_COMMUNICATE_OPTIONS_H_
#include <string>

namespace cotek_communicate {
struct CommunicateOption {
  std::string server_ip;
  int server_port;
};

}  // namespace cotek_communicate

#endif  // COTEK_COMMUNICATE_INCLUDE_COTEK_COMMUNICATE_COMMUNICATE_OPTIONS_H_
