/**
 * Copyright (c) 201906 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_ENUM_TYPE_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_ENUM_TYPE_H_
#include <iostream>

namespace cotek_calibration {

// calibration模块内部错误码
enum class ErrorType : uint16_t {
  NORMAL = 0,
  LASER_MESSAGE_EMPTY = 1,
  DYNAMIC_MATCH_ERROR = 2
};

enum class CalibrationOperationType : uint32_t {
  NONE = 0,
  ENABLED = 1,
  DISABLED = 2,
  SAVED = 3
};

enum class CalibrationMode : uint32_t {
  NONE = 0,
  REFLECTOR = 1,
  SLAM = 2,
  QR = 3,
  SENSOR = 4,
  VEHICLE = 5,
  MOVEMENT = 6
};

enum class LaserType : int { PPF = 0, SICK = 1, UAM = 2 };

enum class GetMapMethod : uint32_t { NONE = 0, HTTP = 1 };

enum class GetMapType : uint32_t { NONE = 0, REFLECTOR_JSON = 1 };

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_ENUM_TYPE_H_
