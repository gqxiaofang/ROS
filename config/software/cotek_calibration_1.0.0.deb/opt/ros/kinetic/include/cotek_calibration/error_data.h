/**
 * Copyright (c) 201906 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_ERROR_DATA_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_ERROR_DATA_H_
#include <string>
#include "cotek_calibration/enum_type.h"

namespace cotek_calibration {

class ErrorData {
 public:
  static ErrorData *get() {
    static ErrorData instance;
    return &instance;
  }

  // 按错误优先级排序
  void SetError(ErrorType error) {
    if (error_ == ErrorType::NORMAL) {
      error_ = error;
    } else {
      error_ = static_cast<uint16_t>(error_) <= static_cast<uint16_t>(error)
                   ? error_
                   : error;
    }
  }

  inline ErrorType error() { return error_; }
  void ClearError() { error_ = ErrorType::NORMAL; }

 private:
  ErrorData() : error_(ErrorType::NORMAL) {}
  ErrorType error_;
};

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_ERROR_DATA_H_
