/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_CALIBRATION_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_CALIBRATION_H_
#include <ros/ros.h>
#include <cmath>
#include <deque>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include "cotek_calibration/calibration_options.h"
#include "cotek_calibration/enum_type.h"
#include "cotek_calibration/error_data.h"
#include "cotek_calibration/map_calibration.h"
#include "cotek_calibration/movement_calibration.h"
#include "cotek_calibration/reflector_calibration.h"
#include "cotek_calibration/reflector_map.h"
#include "cotek_calibration/sensor_calibration.h"
#include "cotek_calibration/vehicle_calibration.h"
#include "cotek_reflector_localizer/geometry.h"
#include "cotek_reflector_localizer/scan_data.h"
namespace cotek_calibration {

class Calibration final {
 public:
  Calibration() = delete;
  explicit Calibration(const CalibrationOption &option);

  bool Init();

  void SetCalibrationMode(const CalibrationMode &mode);

  void AddVelocityData(double actual_velocity, double actual_omega);

  void AddMoveCmd(const cotek_msgs::move_cmd::ConstPtr& cmd);

  void UpdateScanData(const ScanData &data, const Pose &pose);

  const ReflectorMap GetReflectorMap() const;

  const Pose GetPose() const;

  const std::vector<double> GetParam() const;

  const std::vector<double> GetTestResult() const;

  ErrorType GetError() { return ErrorData::get()->error(); }

  void ClearError() { ErrorData::get()->ClearError(); }

 private:
  CalibrationOption option_;
  std::shared_ptr<VehicleCalibration> vehicle_calibration_ptr_;
  std::shared_ptr<SensorCalibration> sensor_calibration_ptr_;
  std::shared_ptr<MapCalibration> map_calibration_ptr_;
  std::shared_ptr<MovementCalibration> movement_calibration_ptr_;
  CalibrationMode mode_;
};
}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_CALIBRATION_H_
