/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_MOVEMENT_CALIBRATION_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_MOVEMENT_CALIBRATION_H_
#include <ros/ros.h>
#include <memory>
#include <vector>
#include "cotek_calibration/calibration_options.h"
#include "cotek_msgs/move_cmd.h"
#include "cotek_msgs/move_feedback.h"

namespace cotek_calibration {

class MovementCalibration {
 public:
  MovementCalibration();
  ~MovementCalibration() {}

  void AddMoveFedbk(double actual_velociy, double actual_omega);

  void AddMoveCmd(const cotek_msgs::move_cmd::ConstPtr& cmd);

  std::vector<double> GetParam();

  std::vector<double> GetTestResult();

  static MoveData cmd_;
  static MoveData fedbk_;
  static std::vector<MoveData> his_cmd_;
  static uint64_t v_cnt;
  static uint64_t o_cnt;
  static std::vector<std::vector<double>> v_list;

 private:
  MoveData pre_cmd_;
};

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_MOVEMENT_CALIBRATION_H_
