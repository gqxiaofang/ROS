/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_REFLECTOR_CALIBRATION_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_REFLECTOR_CALIBRATION_H_
#include <angles/angles.h>
#include <cmath>
#include <deque>
#include <fstream>
#include <memory>
#include <string>
#include <vector>
#include "cotek_calibration/calibration_options.h"
#include "cotek_calibration/enum_type.h"
#include "cotek_calibration/error_data.h"
#include "cotek_calibration/map_calibration.h"
#include "cotek_common/json11.h"
#include "cotek_common/kalman/ExtendedKalmanFilter.hpp"
#include "cotek_common/log_porting.h"
#include "cotek_common/math.h"
#include "cotek_common/remote_service.h"

namespace cotek_calibration {

using EkfPose = State<double>;
using EkfTransform = State<double>;
using LaserInstallOffset = State<double>;

class ReflectorCalibration : public MapCalibration {
  enum class CalibrationLocalizeMode { STATIC, DYNAMIC };

 public:
  explicit ReflectorCalibration(const CalibrationOption &option);

  void UpdateScanData(const ScanData &data, const Pose &pose) override;

  void AddVelocityData(double actual_velociy, double actual_omega) override;

  void AddScanData(const ScanData &scan_data);

  const ReflectorMap GetReflectorMap() const { return reflector_map_; }

  Pose &GetPose() override { return pose_; }

  inline void AddReflector(double x, double y) { reflector_map_.Add(x, y); }

  std::string ReflectorMap2String();

  void UpdateLaserBaseTransform(double x, double y, double yaw);

 private:
  /**
   * \brief  decompose strong points into several parts, each part is a possible
   * landmark \param
   */
  LandmarkList FilterLandmarks(StrongPointQueue &&sp_queue);

  /**
   * \brief  dynamic match
   * \param
   */
  LandmarkList DynamicMatching(const EkfPose &predictPose,
                               const LandmarkList &landmarks);

  /**
   * \brief dynamic location using sequential extend kalman filter
   * \param predictPose predicted pose
   * \return (updated-pose, error)
   */
  Pose SequentialEkfUpdate(EkfPose predictPose, const LandmarkList &landmarks);

  /**
   * \brief: to update mode.
   * \param mode - change currentmode to mode
   */
  inline void SetMode(CalibrationLocalizeMode mode) { mode_ = mode; }

  /**
   * \brief: update landmarks to reflectors, used for reflector auto
   * calibration.
   */
  void LandmarksToReflectors(const LandmarkList &landmarks,
                             const Pose &from_pose);

  /**
   * \brief: update calibrated reflectors to map, and map used to localize.
   */
  void UpdateReflectorsToMap();

  inline double CosineTheorem(double r1, double r2, double angle) {
    return std::sqrt(std::pow(r1, 2) + std::pow(r2, 2) -
                     2 * r1 * r2 * std::cos(angle));
  }

  std::deque<ScanData> scan_data_queue_;

  ReflectorMap reflector_map_;
  ReflectorMap reflector_mapTemp_;

  // Extended Kalman Filter
  Kalman::ExtendedKalmanFilter<EkfPose> ekf_;
  SystemModel<double> system_model_;
  PositionMeasurementModel<double> position_measurement_model_;
  Control<double> control_;

  CalibrationOption option_;
  CalibrationLocalizeMode mode_;
  int count_;
  Pose pose_;
  std::shared_ptr<StrongPointFilter> strong_point_filter_ptr_;
  double duration_;
  int updateMapFrequency_;
  int switchToDynamicThres_;
  uint32_t isReflectorThres_;
  double sameReflector_;
  double difReflector_;
};

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_REFLECTOR_CALIBRATION_H_
