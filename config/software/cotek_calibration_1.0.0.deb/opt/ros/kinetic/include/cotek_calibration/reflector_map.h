/**
 * Copyright (c) 201906 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_REFLECTOR_MAP_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_REFLECTOR_MAP_H_
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include "cotek_common/json11.h"
#include "cotek_reflector_localizer/geometry.h"

namespace cotek_calibration {
using Point = reflector_localizer::Point;
using PointSet = reflector_localizer::PointSet;
class Reflector {
 public:
  Reflector() : x_(0.), y_(0.), count_(1), accumulateX_(0.), accumulateY_(0.) {}
  Reflector(double x, double y)
      : x_(x), y_(y), count_(1), accumulateX_(x), accumulateY_(y) {}

  void Update(double x, double y) {
    if (std::hypot((x - x_), (y - y_)) > 0.06) {
      return;
    }
    ++count_;
    accumulateX_ += x;
    accumulateY_ += y;
    x_ = accumulateX_ / count_;
    y_ = accumulateY_ / count_;
  }

  inline double X() { return x_; }
  inline double Y() { return y_; }
  inline Point ToPoint() { return Point(x_, y_); }
  inline uint32_t Count() { return count_; }

 private:
  double x_;
  double y_;
  uint32_t count_;
  double accumulateX_;
  double accumulateY_;
};

typedef std::vector<Reflector> Section;

/**
 * ReflectorMap: to save map infomation from a file.
 */
class ReflectorMap {
 public:
  ReflectorMap() : current_section_idx_(0) {}
  /**
   * \brief update current section with current section_id
   * \return true update succeed; false if some error occurs
   */
  bool UpdateSection(int id);

  /**
   * \brief get reflectors of current section
   * \return current section's reflectors
   */
  inline Section &Get() { return sections_[current_section_idx_]; }

  inline void Add(double x, double y) {
    if (sections_.count(current_section_idx_) > 0) {
      sections_[current_section_idx_].emplace_back(x, y);
    } else {
      Section sec{Reflector(x, y)};
      sections_[current_section_idx_] = sec;
    }
  }

  inline void Add(int section_id, const Reflector &reflector) {
    if (sections_.count(section_id) > 0) {
      sections_[section_id].push_back(reflector);
    } else {
      Section sec{reflector};
      sections_[section_id] = sec;
    }
  }

  inline void Add(int section_id, double x, double y) {
    if (sections_.count(section_id) > 0) {
      sections_[section_id].emplace_back(x, y);
    } else {
      Section sec{Reflector(x, y)};
      sections_[section_id] = sec;
    }
  }

  PointSet ToPointSet() {
    PointSet ps;
    if (sections_.count(current_section_idx_) > 0) {
      ps.reserve(sections_[current_section_idx_].size());
      for (auto &reflector : sections_[current_section_idx_]) {
        ps.push_back(reflector.ToPoint());
      }
    }
    return ps;
  }

  void InitMap() {
    if (sections_[current_section_idx_].empty()) {
      return;
    }
    double max_x, min_x, max_y, min_y;
    max_x = min_x = sections_[current_section_idx_].front().X();
    max_y = min_y = sections_[current_section_idx_].front().Y();
    for (auto &reflector : sections_[current_section_idx_]) {
      if (reflector.X() > max_x) {
        max_x = reflector.X();
      } else {
        min_x = reflector.X();
      }

      if (reflector.Y() > max_y) {
        max_y = reflector.Y();
      } else {
        min_y = reflector.Y();
      }
    }

    // outline point
    Point pt1(min_x, min_y);
    Point pt2(min_x, max_y);
    Point pt3(max_x, max_y);
    Point pt4(max_x, min_y);

    // set origin value
    origin_in_map_ = Point(0., 0.);
    outline_.push_back(pt1);
    outline_.push_back(pt2);
    outline_.push_back(pt3);
    outline_.push_back(pt4);
    sensor_max_range_ = 20.0;
    max_speed_ = 1.0;
  }

  int idx() { return current_section_idx_; }
  double origin_x() { return origin_in_map_.x(); }
  double origin_y() { return origin_in_map_.y(); }
  const std::vector<Point> &outline() { return outline_; }
  double sensor_max_range() { return sensor_max_range_; }
  double max_speed() { return max_speed_; }

 private:
  std::map<int, Section> sections_;
  int current_section_idx_;
  Point origin_in_map_;
  std::vector<Point> outline_;
  double sensor_max_range_;
  double max_speed_;
};

class ReflectorMapService {
 public:
  // static ReflectorMap ParseFromJsonString(const std::string &json_str);
  static std::string Map2String(ReflectorMap map);
};
}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_REFLECTOR_MAP_H_
