/**
 * Copyright (c) 201906 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_CALIBRATION_OPTIONS_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_CALIBRATION_OPTIONS_H_
#include <string>

namespace cotek_calibration {

struct LaserOption {
  int count;
  int type;
  std::string vendor;
  double angle_min;
  double angle_max;
  double range_min;
  double range_max;
};

struct ReflectorOption {
  double radius;
  double geometry_match_threshold;
  double continous_range_threshold;
  double dynamic_match_threshold;
};

struct EkfOption {
  double process_noise_x;
  double procsss_noise_y;
  double process_noise_theta;
  double measurement_noise_x;
  double measurement_noise_y;
};

struct LaserInstallationOption {
  double offset_x;
  double offset_y;
  double offset_yaw;
};

struct ReflectorAutoCalibrationOption {
  double control_duration;
  int switchToDynamicThres;
  int updateMapFrequency;
  int isReflectorThres;  // > isReflectorThres, is a reflector;
  double sameReflector;  // < sameReflector, is a same reflector;
  double difReflector;   // > difReflector, are different reflectors;
};

struct ServerOption {
  std::string ip;
  int port;
  std::string reflector_map_api;
  std::string local_filename;
};

struct CalibrationOption {
  bool enable_local_debug;
  bool enable_calibration;
  ServerOption server;
  LaserOption laser;
  ReflectorOption reflector;
  EkfOption ekf;
  LaserInstallationOption laser_install;
  ReflectorAutoCalibrationOption auto_calibration;
};

struct MoveData {
  double velocity;
  double omega;
};

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_CALIBRATION_OPTIONS_H_
