/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_MAP_CALIBRATION_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_MAP_CALIBRATION_H_
#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <cmath>
#include <deque>
#include <memory>
#include <string>
#include <vector>
// #include <functional>
#include "cotek_calibration/reflector_map.h"
#include "cotek_reflector_localizer/geometry.h"
#include "cotek_reflector_localizer/landmark.h"
#include "cotek_reflector_localizer/position_measurement_model.h"
#include "cotek_reflector_localizer/scan_data.h"
#include "cotek_reflector_localizer/strong_point_filter.h"
#include "cotek_reflector_localizer/system_model.h"

namespace cotek_calibration {

using namespace reflector_localizer;

class MapCalibration {
 public:
  virtual void AddVelocityData(double actual_velociy, double actual_omega) = 0;

  virtual const ReflectorMap GetReflectorMap() const { return ReflectorMap(); }

  virtual void UpdateScanData(const ScanData& data, const Pose& from_pose) = 0;

  virtual Pose& GetPose() = 0;

 private:
};  // namespace cotek_calibration

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_MAP_CALIBRATION_H_
