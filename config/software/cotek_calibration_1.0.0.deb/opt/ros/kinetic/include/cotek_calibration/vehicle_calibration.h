/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_VEHICLE_CALIBRATION_H_
#define COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_VEHICLE_CALIBRATION_H_
#include <ros/ros.h>
#include <cmath>
#include <deque>
#include <memory>
#include <string>
#include <vector>
#include "cotek_calibration/calibration_options.h"

namespace cotek_calibration {

class VehicleCalibration {
 public:
  VehicleCalibration();
  /**
   *  fill in constructor and function
   */

 private:
};

}  // namespace cotek_calibration

#endif  // COTEK_CALIBRATION_INCLUDE_COTEK_CALIBRATION_VEHICLE_CALIBRATION_H_
