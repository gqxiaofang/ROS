/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_ACTION_BOOM_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_ACTION_BOOM_H_
#include <iostream>
// 动作枚举, decision_maker action 和 embedded 统一用这个枚举
namespace cotek_common {

enum class ActionBoom : uint16_t {
  /*------------通用动作:(0-199)------------*/
  // 所有车型通用
  NONE = 0,  // 无动作 (value:默认填0)
  REST = 1,  // 休息 (value:默认填0)

  // 以下为临时适应老调度
  PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
  PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度) // 暂时
  CHARGE = 5,  // 自动充电 (operation_value 填0(关), 1(开))
  BEEP = 6,    // 喇叭  (operation_value 填0(关), 1(开))
  CURTIS_RESET = 7,  // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
  BRAKE = 8,  // 电机报闸  (operation_value 填0(关), 1(开))
  LOW_POWER_MODE = 9,
  REACH_FORK_MOVE = 10,     // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_FORWARD = 11,  // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_BACKWARD = 12,  // 前移车叉腿后移(operation_value 默认填0)
  HEAP_LIFT_LOAD = 13,       // 堆高车库位抬货
  HEAP_UN_LOAD = 14,         // 堆高车库位卸货
  PALLET_NOMOVE = 88,        //
  INIT = 99

#if 0
  /*------------托盘车动作:(200-299)------------*/
  /* 编号200~229 完全抽象动作  decision节点分解成次抽象动作给action */

  PALLET_UP_LOAD = 201,
  PALLET_DOWN_LOAD = 202,

  /* 编号230~259 次抽象动作  action节点分解成原子动作给embedded */

  PALLET_FORK_UP_DOWN = 231,  // 托盘车叉腿移动 (value: 0:无 1:上升 2:下降)

  /* 编号260~299 原子动作  embedded节点执行原子 发送给相应执行机构 */
  PALLET_FORK_UP = 261,    // 托盘车叉腿抬升 (默认填0)
  PALLET_FORK_DOWN = 262,  // 托盘车叉腿下降 (默认填0)

  /*------------堆高车原子动作:(300-399)------------*/

  /* 编号300~329 完全抽象动作  decision节点分解成次抽象动作给action */
  HEAP_UP_LOAD = 301,
  HEAP_DOWN_LOAD = 302,

  /* 编号330~359 次抽象动作  action节点分解成原子动作给embedded */
  HEAP_FORK_UP_DOWN = 331,  // 堆高车叉腿移动 (value: 高度值)

  /* 编号360~399 原子动作  embedded节点执行原子 发送给相应执行机构 */
  HEAP_FORK_UP = 361,    // 堆高车叉腿抬升 (value: 高度值)
  HEAP_FORK_DOWN = 362,  // 堆高车叉腿下降 (value: 高度值)

  /*------------三向车原子动作:(400-499)------------*/

  /* 编号400~429 完全抽象动作  decision节点分解成次抽象动作给action */
  TRANS_UP_LOAD = 401,
  TRANS_DOWN_LOAD = 402,

  /* 编号430~459 次抽象动作  action节点分解成原子动作给embedded */
  TRANS_FORK_UP_DOWN = 431,  // 三向车叉腿抬降 (value: 高度值)
  TRANS_FORK_ROTATE =
      432,  // 三向车叉腿左右旋转 (0:不旋转 1:向左旋转 2:向右旋转)
  TRANS_FORK_LATERAL_SHIFT = 433,  // 三向车叉腿左右侧移 (value: 左右侧移值)

  /* 编号460~499 原子动作  embedded节点执行原子 发送给相应执行机构 */
  TRANS_FORK_UP = 461,           // 三向车叉腿抬升 (value: 高度值)
  TRANS_FORK_DOWN = 462,         // 三向车叉腿下降 (value: 高度值)
  TRANS_FORK_ROTATE_LEFT = 463,  // 三向车叉腿向左旋转 (value:默认填0)
  TRANS_FORK_ROTATE_RIGHT = 464,  // 三向车叉腿向右旋转 (value:默认填0)
  TRANS_FORK_LEFT_SHIFT = 465,   // 三向车叉腿左侧移 (value: 侧移值)
  TRANS_FORK_RIGHT_SHIFT = 466,  // 三向车叉腿右侧移 (value: 侧移值)

  /*------------前移车原子动作:(500-599)------------*/

  /* 编号500~529 完全抽象动作  decision节点分解成次抽象动作给action */
  REACH_UP_LOAD = 501,
  REACH_DOWN_LOAD = 502,

  /* 编号530~559 次抽象动作  action节点分解成原子动作给embedded */
  REACH_FORK_UP_DOWN = 531,  // 前移车叉腿升降 (value: 升降高度值)
  REACH_FORK_LATERAL_SHIFT = 532,  // 前移车叉腿前后移动 (value:叉腿前后移动值)

  /* 编号560~599 原子动作  embedded节点执行原子 发送给相应执行机构 */
  REACH_FORK_UP = 561,        // 前移车叉腿抬升 (value:高度值)
  REACH_FORK_DOWN = 562,      // 前移车叉腿下降 (value:高度值)
  REACH_FORK_FORWARD = 563,   // 前移车叉腿前移 (value:侧移值)
  REACH_FORK_BACKWARD = 564,  // 前移车叉腿后移 (value:侧移值)

  /*------------牵引车原子动作:(600-699)------------*/

  /*------------全向车原子动作:(700-799)------------*/

  /*------------顶升车原子动作:(800-799)------------*/
  // TODO(@someone)
  JACKUP_PALLET_UP_DOWN = 801,   // 顶升车托盘升降
  JACKUP_PALLET_UP = 802,        // 顶升车托盘抬升
  JACKUP_PALLET_DOWN = 803,      // 顶升车托盘下降
  JACKUP_PALLET_ROTATION = 804,  // 顶升车托盘旋转
  JACKUP_PALLET_ZERO = 805,      // 顶升车托盘找零
  JACKUP_MOTOR_DISABLE = 806,    // 顶升车电机失能
  JACKUP_MOTOR_ENABLE = 807,     // 顶升车电机使能
  JACKUP_PALLET_NO_MOVE = 808    // 顶升车托盘固定
#endif
};
}  // namespace cotek_common
#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_ACTION_BOOM_H_
