/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_CONFIG_HELPER_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_CONFIG_HELPER_H_
#include <ros/package.h>
#include <map>
#include <string>
#include "cotek_common/enum_type.h"
#include "cotek_common/json11.h"
#include "cotek_common/log_porting.h"

// TODO(@someone) 做成通用配置助手, 用来处理cotek标准配置文件
struct ChildDeviceParam {
  int node_id;
  int channel;
  int can_baudrate;
};

struct ChannelBaudrateParam {
  int can0;
  int can1;
};

// <child name, device param>
using DeviceConfig = std::map<std::string, ChildDeviceParam>;

// 读取 json 文件 加载配置
class ConfigHelper {
 public:
  ~ConfigHelper() {}
  // 单例实现
  static ConfigHelper& Instance() {
    static ConfigHelper instance;
    return instance;
  }

  ConfigHelper(const ConfigHelper&) = delete;
  ConfigHelper& operator=(const ConfigHelper&) = delete;

  // 加载 json 文件获取配置
  bool LoadConfig(const std::string& json_str);

  inline const AgvType GetAgvType() { return static_cast<AgvType>(agv_type_); }

  inline const ChannelBaudrateParam ChannelBaudrate() {
    return channel_baudrate_;
  }

  inline const DeviceConfig& GetConfig(std::string device_name) {
    return device_config_map_.at(device_name);
  }

  inline const std::map<std::string, DeviceConfig>& GetDeviceList() {
    return device_config_map_;
  }

  // 入口参数为 di_1 ~ di_10, do_1 ~ do_7;
  inline const unsigned char& GetIoIndex(const std::string& io_channel) {
    return io_map_.at(io_channel);
  }

  inline const std::map<std::string, unsigned char> GetIoMapping() {
    return io_map_;
  }

 private:
  ConfigHelper() {}

  // <parent name, install device>
  std::map<std::string, DeviceConfig> device_config_map_;
  std::map<std::string, unsigned char> io_map_;
  ChannelBaudrateParam channel_baudrate_;
  int agv_type_;
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_CONFIG_HELPER_H_
