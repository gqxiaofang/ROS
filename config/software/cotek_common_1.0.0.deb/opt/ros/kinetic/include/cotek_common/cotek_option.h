/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_OPTION_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_OPTION_H_

#include <string>

struct UnicycleModelOption {
  float wheel_track;              // 轮间距 m
  float wheel_diameter;           // 轮子直径 m
  float move_motor_reduce_ratio;  // 移动电机减速比 系数
};

struct BicycleModelOption {
  float wheel_base;  // 轴距 m
  float max_wheel_base;
  float min_wheel_base;

  // TODO(@someone) 这参数不放这里
  bool use_inertia_compensation;
  double velocity_coefficient;
  double omega_coefficient;
};

struct LaserSensorInstallOption {
  double laser_offset_x;
  double laser_offset_y;
  double laser_offset_theta;
};

// struct ServerOption {
//   std::string server_ip;
//   int server_port;
// };

struct MechanicalOption {
  int model_type;
  UnicycleModelOption unicle_model_option;
  BicycleModelOption bicycle_modle_option;
  LaserSensorInstallOption laser_sensor_install_option;
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_OPTION_H_
