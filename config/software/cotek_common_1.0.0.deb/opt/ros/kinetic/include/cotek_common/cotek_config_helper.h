/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_CONFIG_HELPER_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_CONFIG_HELPER_H_
#include <ros/package.h>
#include <map>
#include <string>
#include "cotek_common/cotek_option.h"
#include "cotek_common/enum_type.h"
#include "cotek_common/json11.h"
#include "cotek_common/local_service.h"
#include "cotek_common/log_porting.h"
#include "cotek_common/msg_conversion.h"
#include "cotek_common/remote_service.h"

namespace cotek_config {
enum class ConfigType : uint8_t {
  NONE = 0,
  AGV_BASIC_CONFIG = 1,
  LOGIC_CONFIG = 2,
  LOCALIZER_CONFIG = 3,
  NAVIGATION_CONFIG = 4,
  ACTION_CONFIG = 5,
  AVOID_CONFIG = 6,
  EMBEDDED_CONFIG = 7,
  // 用来测试代码
  TEST_CONFIG = 0xFF
};
constexpr float kConfigWaitTime = 0.5;

// agv_basic_config.json 所在目录的前缀
constexpr char kConfigFilePrefix[] = "/home/cotek/config/";
constexpr char kAgvBasicConfigPath[] = "agv_basic_config.json";
constexpr char kLogicConfigPath[] = "logic_config.json";
constexpr char kLocalizerConfigPath[] = "localizer_config.json";
constexpr char kNavigationConfigPath[] = "navigation_config.json";
constexpr char kActionConfigPath[] = "action_config.json";
constexpr char kAvoidConfigPath[] = "avoid_config.json";
constexpr char kEmbeddedConfigPath[] = "embedded_config.json";
constexpr char kTestConfigPath[] = "test.json";

constexpr char kUpdateLogicConfigService[] = "update_logic_config";
constexpr char kUpdateNavigationConfigService[] = "update_navigation_config";
constexpr char kUpdateActionConfigService[] = "update_action_config";
}  // namespace cotek_config

// 读取 json 文件 加载配置
class BasicConfigHelper {
 public:
  ~BasicConfigHelper() {}
  // 单例实现
  static BasicConfigHelper& Instance() {
    static BasicConfigHelper instance;
    return instance;
  }

  BasicConfigHelper(const BasicConfigHelper&) = delete;
  BasicConfigHelper& operator=(const BasicConfigHelper&) = delete;

  // 加载 json 文件获取配置
  bool LoadConfig();

  // 动态更新后保存到本地
  bool SaveLocal(cotek_config::ConfigType type, std::string);

  // 调度读取配置
  std::string GetConfig(cotek_config::ConfigType type);

  inline const AgvType agv_type() { return static_cast<AgvType>(agv_type_); }

  inline const std::string server_ip() { return server_ip_; }

  inline const int server_port() { return server_port_; }

  inline const int http_reflector_map_port() {
    return http_reflector_map_port_;
  }

  inline const std::string http_get_reflector_map_url() {
    return http_get_reflector_map_url_;
  }

  inline const std::string http_update_reflector_map_url() {
    return http_update_reflector_map_url_;
  }

  inline const int current_map_id() { return current_map_id_; }

  inline const int current_section_id() { return current_section_id_; }

  inline const MechanicalOption mechanical_option() {
    return mechanical_option_;
  }

  inline const std::string logic_config_file_name() {
    return logic_config_file_name_;
  }

  inline const std::string navigation_config_file_name() {
    return navigation_config_file_name_;
  }

  inline const std::string action_config_file_name() {
    return action_config_file_name_;
  }

  inline const std::string embedded_config_file_name() {
    return embedded_config_file_name_;
  }

 private:
  BasicConfigHelper()
      : has_been_loaded_(false),
        agv_type_(0),
        server_port_(0),
        current_map_id_(0),
        current_section_id_(0),
        http_reflector_map_port_(0),
        local_debug_(false) {
    config_map_[cotek_config::ConfigType::AGV_BASIC_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kAgvBasicConfigPath);
    config_map_[cotek_config::ConfigType::LOCALIZER_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kLocalizerConfigPath);
    config_map_[cotek_config::ConfigType::LOGIC_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kLogicConfigPath);
    config_map_[cotek_config::ConfigType::NAVIGATION_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kNavigationConfigPath);
    config_map_[cotek_config::ConfigType::ACTION_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kActionConfigPath);
    config_map_[cotek_config::ConfigType::AVOID_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kAvoidConfigPath);
    config_map_[cotek_config::ConfigType::EMBEDDED_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kEmbeddedConfigPath);

    config_map_[cotek_config::ConfigType::TEST_CONFIG] =
        std::string(cotek_config::kConfigFilePrefix) +
        std::string(cotek_config::kTestConfigPath);
  }

  bool has_been_loaded_;

  int agv_type_;
  std::string server_ip_;
  int server_port_;
  int current_map_id_;
  int current_section_id_;
  std::string http_get_reflector_map_url_;
  std::string http_update_reflector_map_url_;
  int http_reflector_map_port_;
  MechanicalOption mechanical_option_;
  bool local_debug_;
  std::string logic_config_file_name_;
  std::string navigation_config_file_name_;
  std::string action_config_file_name_;
  std::string embedded_config_file_name_;

  std::map<cotek_config::ConfigType, std::string> config_map_;
  std::map<cotek_config::ConfigType, std::string> local_config_map_;
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_CONFIG_HELPER_H_
