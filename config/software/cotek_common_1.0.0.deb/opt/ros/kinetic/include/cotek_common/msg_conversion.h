/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_MSG_CONVERSION_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_MSG_CONVERSION_H_
#include <string>
#include "cotek_common/json11.h"
#include "cotek_common/log_porting.h"
#include "cotek_msgs/action_config.h"
#include "cotek_msgs/avoid_ratio.h"
#include "cotek_msgs/logic_config.h"
#include "cotek_msgs/navigation_config.h"

cotek_msgs::logic_config LogicConfigToRosServiceMsg(std::string data);

cotek_msgs::navigation_config NavigationConfigToRosServiceMsg(std::string data);

cotek_msgs::action_config ActionConfigToRosServiceMsg(std::string data);
#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_MSG_CONVERSION_H_
