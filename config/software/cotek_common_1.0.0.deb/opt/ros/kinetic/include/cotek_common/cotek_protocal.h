/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_PROTOCAL_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_PROTOCAL_H_
#include <string>
#include "cotek_common/json11.h"

namespace cotek_protocal {
// 100K 缓存
constexpr uint32_t kMaxUdpBuffer = 102400;

// 协议总包
struct CotekUdpProtocal {
  std::string bind_id;
  std::string msg_type;  // 数据包类型
  std::string msg_data;  // 数据包应用数据段
  std::string msg_hash;
};

// 协议数据包类型
namespace msg_type {
/**
 * a.定时触发型
 */
constexpr char kUpdateEvent[] = "UpdateEvent";

/**
 * b.请求应答型
 */
// 任务接收回复
constexpr char kTaskResponse[] = "TaskResponse";

// agv <--> ds  请求从 agv 发出
// 任务完成请求
constexpr char kTaskFinishRequest[] = "TaskFinishRequest";

// ds <--> agv  请求从 ds 发出
// 任务请求
constexpr char kTaskRequest[] = "TaskRequest";

// 任务控制请求
constexpr char kTaskControlRequest[] = "TaskControlRequest";

// 标定功能请求
constexpr char kTaskCalibrationRequest[] = "TaskCalibrationRequest";

// 车载地图上传请求
constexpr char kTaskGetMapRequest[] = "TaskGetMapRequest";

// 参数配置包上传请求
constexpr char kTaskPushParamRequest[] = "TaskPushParamRequest";

// 导航相关参数配包
constexpr char kTaskUpdateNavigationParam[] = "TaskUpdateNavigationParam";

// 动作相关参数配置包
constexpr char kTaskUpdateActionParam[] = "TaskUpdateActionParam";

// 业务相关参数配置包
constexpr char kTaskUpdateLogicParam[] = "TaskUpdateLogicParam";

constexpr char kTaskUpdateParamOk[] = "TaskUpdateParamOk";
}  // namespace msg_type
}  // namespace cotek_protocal

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_PROTOCAL_H_
