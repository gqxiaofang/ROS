/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */

// 几何
// point, pose

// 运动
struct MoveData {
  float velocity;
  float omega;
};

// 动作
struct ActionData {
  int32_t action_type;
  float action_value;
};

// 小车数据
struct AgvEventUpdate {
  uint8_t battery_;
};
