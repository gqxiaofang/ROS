/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_LOG_PORTING_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_LOG_PORTING_H_
#include <ros/ros.h>
#include <ctime>
#include <string>
#include "cotek_common/enum_type.h"

#define LOG_DEBUG ROS_DEBUG
#define LOG_DEBUG_ONCE ROS_DEBUG_ONCE
#define LOG_DEBUG_COND ROS_DEBUG_COND
#define LOG_DEBUG_STREAM ROS_DEBUG_STREAM
#define LOG_DEBUG_STREAM_ONCE ROS_DEBUG_STREAM_ONCE
#define LOG_DEBUG_STREAM_COND ROS_DEBUG_STREAM_COND
#define LOG_INFO ROS_INFO
#define LOG_INFO_ONCE ROS_INFO_ONCE
#define LOG_INFO_COND ROS_INFO_COND
#define LOG_INFO_STREAM ROS_INFO_STREAM
#define LOG_INFO_STREAM_ONCE ROS_INFO_STREAM_ONCE
#define LOG_INFO_STREAM_COND ROS_INFO_STREAM_COND
#define LOG_WARN ROS_WARN
#define LOG_WARN_ONCE ROS_WARN_ONCE
#define LOG_WARN_COND ROS_WARN_COND
#define LOG_WARN_STREAM ROS_WARN_STREAM
#define LOG_WARN_STREAM_ONCE ROS_WARN_STREAM_ONCE
#define LOG_WARN_STREAM_COND ROS_WARN_STREAM_COND
#define LOG_ERROR ROS_ERROR
#define LOG_ERROR_ONCE ROS_ERROR_ONCE
#define LOG_ERROR_COND ROS_ERROR_COND
#define LOG_ERROR_STREAM ROS_ERROR_STREAM
#define LOG_ERROR_STREAM_ONCE ROS_ERROR_STREAM_ONCE
#define LOG_ERROR_STREAM_COND ROS_ERROR_STREAM_COND
#define LOG_FATAL ROS_FATAL
#define LOG_FATAL_COND ROS_FATAL_COND
#define LOG_FATAL_STREAM ROS_FATAL_STREAM
#define LOG_FATAL_STREAM_ONCE ROS_FATAL_STREAM_ONCE
#define LOG_FATAL_STREAM_COND ROS_FATAL_STREAM_COND

static std::string TimeInfo() {
  time_t timep;
  time(&timep);
  char tmp[64];
  strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S", localtime(&timep));
  std::string s(tmp + '\0');
  return s;
}

// 输入枚举值 打印字符串
// void LOG_AGV_STATUS(AGVStateType state) {
//   switch (state) {
//     case AGVStateType::NONE: {
//       LOG_INFO("agv state None");
//       break;
//     }
//     case AGVStateType::WAITING: {
//       LOG_INFO("agv state Waiting");
//       break;
//     }
//     case AGVStateType::DOING: {
//       LOG_INFO("agv state Doing");
//       break;
//     }
//     case AGVStateType::LOWPOWERMODE: {
//       LOG_INFO("agv state Lowpower mode");
//       break;
//     }
//     case AGVStateType::PAUSE: {
//       LOG_INFO("agv state Pause");
//       break;
//     }
//     case AGVStateType::MANUAL: {
//       LOG_INFO("agv state Manual");
//       break;
//     }
//     case AGVStateType::FINISHING: {
//       LOG_INFO("agv state Finishing");
//       break;
//     }
//     case AGVStateType::CHARGING: {
//       LOG_INFO("agv state Charging");
//       break;
//     }

//     default:
//       break;
//   }
// }

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_LOG_PORTING_H_
