/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_ENUM_TYPE_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_ENUM_TYPE_H_
#include <iostream>

// 状态机状态
enum class AGVStateType : int32_t {
  NONE = 0,
  WAITING = 1,
  DOING = 2,
  LOWPOWERMODE = 4,
  PAUSE = 5,
  MANUAL = 6,
  FINISHING = 7,
  CHARGING = 8,
  FAULT = 9
};

// 将多个包共用的枚举变量移步于此
namespace cotek_action {
// 各车型动作类型
enum class PalletForkliftActionType : uint32_t {
  REST = 0,
  MOVE = 1,
  PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
  PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度)
  BRAKE = 5,           // 电机报闸  (operation_value 默认填0)
  BEEP = 6,            // 喇叭  (operation_value 默认填0)
  CURTIS_RESET = 7,  // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
  CHARGE = 8,  // 自动充电 (operation_value 填0(关), 1(开))
  // 手动操作
  ROTATE_ANGLE = 9,
  REACH_FORK_MOVE = 10,  // 前移车叉腿移动(operation_value 控制侧移量)
  REACH_FORK_FORWARD = 11,  // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_BACKWARD = 12  // 前移车叉腿后移(operation_value 默认填0)
};

enum class HeapForkliftActionType : uint32_t {
  REST = 0,
  MOVE = 1,
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度)
  BRAKE = 5,           // 电机报闸  (operation_value 默认填0)
  BEEP = 6,            // 喇叭  (operation_value 默认填0)
  CURTIS_RESET = 7,  // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
  CHARGE = 8,  // 自动充电 (operation_value 填0(关), 1(开))
  // 手动操作
  ROTATE_ANGLE = 9
};

enum class JackupActionType : uint32_t {
  ACTION_NONE = 0,
  LOW_POWER_MODE = 1,
  PALLET_UP = 2,
  PALLET_DOWN = 3,
  PALLET_ROTATION = 4,
  PALLET_ZERO = 5,
  MOTOR_DISABLE = 6,
  MOTOR_ENABLE = 7,
  AGV_CHARGE = 8,
  MOTOR_CLEARALARM = 9,
  ACTION_WAITING = 10,
  PALET_NOMOVE = 11,
};

enum class TranspalntActionType {
  ACTION_NONE = 0,
  ACTION_TRANS_RIGHT = 1,
  ACTION_TRANS_LEFT = 2,
  ACTION_TRANS_UP = 3,
  ACTION_TRANS_DOWN = 4,
};
}  // namespace cotek_action

enum class AgvType : uint32_t {
  UNKONW = 0,
  FORKLIFT = 1,
  JACK_UP = 2,
  TRANSPLANT = 3,
  HEAP_FORKLIFT = 4,
  LINDE_FROKLIFT = 5,
  NUOLI_FROKLIFT = 6,
  TRACTOR_CAR = 7,
  UN_FORWARD_FORKLIFT = 8,
  MAGNETC_JACK_UP = 9
};

enum class BatteryType : uint8_t {
  NONE = 0,
  CURTIS = 1,
  BAOE = 2,
  ZHONG_LI = 3,
  LINDE = 4
};

enum class PathType : int32_t {
  NONE = 0,
  POINT = 1,
  STRAIGHT_LINE = 2,
  B_SPLINE_CURVES = 3,
  ARC = 4,
};

enum class MotionType : int32_t {
  NONE = 0,
  // jack_up
  START_POINT = 1,
  STRAIGHT_LINE = 2,
  ARC = 4,
  B_SPLINE_CURVES = 3,
  FORKLIFT_UPLOAD = 5,
  // forklift
  SELF_ROTATE = 10,
  CHARGING = 11,
  QR_UP_STABILIZE = 12,    // 载货前整定动作, agv -> shelf
  QR_DOWN_STABILIZE = 13,  // 卸货前整定，shelf->map
};

enum class NaviType : int32_t {
  NONE = 0,
  FREE = 1,
  MAGNETIC = 2,
  OPENLOOP = 3
};

// 移动模型类型
enum class MoevModelType : uint32_t { UNKONW = 0, UNICYCLE = 1, BICYCLE = 2 };
enum class ForkStateType : uint8_t { DOWN = 0, MIDDLE = 1, UP = 2 };

// 叉腿防撞检测
enum class ForkLegCheckType : uint8_t {
  NONE = 0,         // 左右都无检测
  LEFT_CHECK = 1,   // 左边检测到
  RIGHT_CHECK = 2,  // 右边检测到
  BOTH = 3          // 左右都检测到
};

// 货架检测
enum class ForkPalletState : uint8_t {
  NONE = 0,         // 左右都无检测
  LEFT_CHECK = 1,   // 左边检测到
  RIGHT_CHECK = 2,  // 右边检测到
  BOTH = 3          // 左右都检测到
};

// 载货状态
enum class LoadStateType : int32_t { UNKONW = 0, ON_LOAD = 1, NO_LOAD = 2 };

// 叉车原子动作
enum class AtomicActionType : uint32_t {
  REST = 0,
  MOVE = 1,
  PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
  PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度)
  CHARGE = 5,          // 自动充电 (operation_value 填0(关), 1(开))
  BEEP = 6,            // 喇叭  (operation_value 填0(关), 1(开))
  CURTIS_RESET = 7,  // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
  BRAKE = 8,  // 电机报闸  (operation_value 填0(关), 1(开))
  LOW_POWER_MODE = 9,
  REACH_FORK_MOVE = 10,  // 前移车叉腿移动(operation_value 控制侧移量)
  REACH_FORK_FORWARD = 11,  // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_BACKWARD = 12,  // 前移车叉腿后移(operation_value 默认填0)
  FORK_ROTATE_ANGLE = 77     // 手动操作,旋转角度
};

enum class AvoidMapType : int {
  INIT = 0,
  AVOID_DIY_MAP_23 = 23,
  AVOID_DIY_MAP_24 = 24,
  AVOID_DIY_MAP_25 = 25,  // 避障减弱
  NONE = 26,              // 无避障
  BACK_LEFT = 27,         // 后退右转
  BACK_RIGHT = 28,        // 后退左转
  FORWARD_LEFT = 29,      // 前进左转
  FORWARD_RIGHT = 30,     // 前进右转
  FORWARD = 31            // 直行避障
};

enum class AvoidLevel : uint8_t {
  NONE = 0,            // 无避障
  LEVEL_I = 1,         // 避障区域 避障等级1 - slowlevel1
  LEVEL_II = 2,        // 避障区域 避障等级2 - slowlevel2
  LEVEL_III = 3,       // 避障区域 避障等级3 - stop
  BUMP = 4,            // 防撞条
  FORK_LEFT_LEG = 5,   // 叉车左叉腿防撞
  FORK_RIGHT_LEG = 6,  // 叉车右叉腿防撞
  FORK_LEG_BOTH = 7    // 叉车左右叉腿都检测到
};

enum class AvoidSpeedLevel : uint32_t {
  FREE = 0,
  SLOWLEVEL1 = 1,
  SLOWLEVEL2 = 2,
  STOP = 3
};

enum class StateType : int {
  MANUAL = 1,     // 手动
  AUTO = 2,       // 自动
  BUMP_ERROR = 3  // 防撞触发
};

// 功耗模式
// SLEEPING: 低功耗模式
// ACTIVE: 正常功耗模式
enum class PowerMode { UNKNOWN, SLEEPING, ACTIVE };

// 顶升车托盘状态
enum class JackUpDownState {
  UP_NONE = 0,
  UP_1 = 1,
  UP_2 = 2,
  UP_BOTH = 3,
  DOWN_NONE = 4,
  DOWN_1 = 5,
  DOWN_2 = 6,
  DOWN_BOTH = 7,
};
// 顶升车托盘找零状态
enum class JackUpZeroType : uint8_t {
  ROATE_NONE = 0,
  ROATE_1 = 1,
  ROATE_2 = 2,
  ROATE_BOTH = 3,
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_ENUM_TYPE_H_
