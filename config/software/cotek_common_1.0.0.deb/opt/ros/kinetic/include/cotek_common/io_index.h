/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_IO_INDEX_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_IO_INDEX_H_
#include <iostream>
#include <string>

// IO设备集编号: 所有的IO设备及其编号

namespace io {
// 可添加设备与设备编号, 不可修改!!!
constexpr uint8_t kNoneIoDevice = 0;
// 防撞条
constexpr uint8_t kBumper = 1;

// 输入 1~100
// 托盘叉车上下限位 (诺力)
constexpr uint8_t kForkUpperLimitSwitch = 11;
constexpr uint8_t kForkDownerLimitSwitch = 12;
// 托盘叉车左右叉腿防撞 (诺力)
constexpr uint8_t kLeftForkLegSwitch = 13;
constexpr uint8_t kRghtForkLegSwitch = 14;
// 托盘叉车货架位置左右检测 (诺力)
constexpr uint8_t kLeftPositionSwitch = 15;
constexpr uint8_t kRightPositionSwitch = 16;
// 叉车避障等级输入(诺力 / 中力)
constexpr uint8_t kLaserObstacleLevelI = 17;
constexpr uint8_t kLaserObstacleLevelII = 18;
constexpr uint8_t kLaserObstacleLevelIII = 19;

// 叉车挡板检测开关(中力)
constexpr uint8_t kPalletPositionSwitch = 20;

// 门架高度开关 2个 (三向车)
constexpr uint8_t kHeightSwitch_1 = 21;
constexpr uint8_t kHeightSwitch_2 = 22;

// 侧移到位开关 2个 (三向车)
constexpr uint8_t kLateralLeftSwitch = 23;
constexpr uint8_t kLateralRightSwitch = 24;

// 旋转到位开关 3个 左到位,右到位,旋转减速 (三向车)
constexpr uint8_t kRotateLeftSwitch = 25;
constexpr uint8_t kRotateRightSwitch = 26;
constexpr uint8_t kRotateDecelSwtich = 27;

constexpr uint8_t kManualSwtich = 28;

// 叉车输出 71~90
// 柯蒂斯复位继电器 (诺力托盘车)
constexpr uint8_t kCurtisReset = 71;
// 避障传感器选择地图4输出通道 (诺力托盘车 / 堆高车 / 三向车)
constexpr uint8_t kLaserObstacleChannelI = 72;
constexpr uint8_t kLaserObstacleChannelII = 73;
constexpr uint8_t kLaserObstacleChannelIII = 74;
constexpr uint8_t kLaserObstacleChannelIV = 75;
constexpr uint8_t kLaserObstacleChannelV = 76;
// 叉车自动充电继电器
constexpr uint8_t kChargeRelay = 80;

// 顶升
// 顶升输入 91~150
// 顶升车上下限位
constexpr uint8_t kJackUpUpperLimitSwitchI = 91;
constexpr uint8_t kJackUpUpperLimitSwitchII = 92;
constexpr uint8_t kJackUpDownerLimitSwitchI = 93;
constexpr uint8_t kJackUpDownerLimitSwitchII = 94;

// 顶升托盘 归零光电开关
constexpr uint8_t kJackUpPalletZeroSwitchI = 95;
constexpr uint8_t kJackUpPalletZeroSwitchII = 96;

// 顶升输出 151~180
constexpr uint8_t kJackUpLedRed = 151;
constexpr uint8_t kJackUpLedYellow = 152;
constexpr uint8_t kJackUpLedGreen = 153;
constexpr uint8_t kJackUpCharge = 154;
constexpr uint8_t kJackUpLiftMotorBreak = 155;
constexpr uint8_t kJackUpRotateMotorBreak = 156;
constexpr uint8_t kJackUp24vLowpower = 157;
constexpr uint8_t kJackUp48vLowpower = 158;

}  // namespace io

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_IO_INDEX_H_
