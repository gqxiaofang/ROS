/*
 * @Descripttion: 
 * @version: v1.0
 * @Author: wangjy
 * @Date: 2019-11-26 18:35:41
 * @LastEditors: wangjy
 * @LastEditTime: 2019-11-26 18:35:42
 * @FilePath: /src/cotek_common/include/cotek_common/math.h
 */
/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_MATH_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_MATH_H_
#include <cmath>

// TODO(@someone) 做成通用数学运算库
namespace math {
template <typename T>
T deg2rad(const T& deg) {
  return deg / 180.0 * M_PI;
}

template <typename T>
T rad2deg(const T& rad) {
  return rad / M_PI * 180.0;
}

template <typename T>
T Meter2Millimeter(const T& meter) {
  return meter * 1000.0;
}

template <typename T>
T Meter2Centimeter(const T& meter) {
  return meter * 100.0;
}

template <typename T>
T Centimeter2meter(const T& centimeter) {
  return centimeter / 100.0;
}

template <typename T>
T Meter2Decimetre(const T& meter) {
  return meter * 10.0;
}

template <typename T>
T Decimetre2meter(const T& decimetre) {
  return decimetre / 10.0;
}

template <typename T>
bool NearZero(const T& val, double bound = 0.0001) {
  return std::fabs(static_cast<double>(val)) <= bound;
}

template <typename T>
double CosineTheorem(T r1, T r2, T angle) {
  return std::sqrt(std::pow(r1, 2) + std::pow(r2, 2) -
                   2 * r1 * r2 * std::cos(angle));
}

}  // namespace math

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_MATH_H_
