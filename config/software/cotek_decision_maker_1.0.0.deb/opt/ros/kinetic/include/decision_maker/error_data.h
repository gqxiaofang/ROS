/**
 * Copyright (c) 201906 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_ERROR_DATA_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_ERROR_DATA_H_
#include <string>
#include "decision_maker/enum.h"

namespace decision_maker {
// decision 内部错误模块

class ErrorData {
 public:
  static ErrorData *get() {
    static ErrorData instance;
    return &instance;
  }

  // 按错误优先级排序
  void SetError(ErrorType error) {
    if (error_ == ErrorType::NORMAL) {
      error_ = error;
    } else {
      error_ = static_cast<uint16_t>(error_) <= static_cast<uint16_t>(error)
                   ? error_
                   : error;
    }
  }

  inline ErrorType error() { return error_; }
  void ClearError() { error_ = ErrorType::NORMAL; }

 private:
  ErrorData() : error_(ErrorType::NORMAL) {}
  ErrorType error_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_ERROR_DATA_H_
