/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_ACTION_CLIENT_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_ACTION_CLIENT_H_
#include <actionlib/client/simple_action_client.h>
#include <string>
#include "cotek_msgs/agv_actionAction.h"

namespace decision_maker {

class ActionClient {
 public:
  ActionClient() = delete;
  explicit ActionClient(const std::string action_name, bool flag = true)
      : client_(action_name, flag) {
    is_finish_ = false;
    is_client_available_ = false;
    percent_ = 0;
  }

  void SendActionGoal(cotek_msgs::agv_actionGoal goal) {
    ROS_DEBUG("Waiting for [action] server to start.");
    client_.waitForServer();
    ROS_DEBUG("[Action] server started.");
    client_.sendGoal(goal, boost::bind(&ActionClient::doneCb, this, _1, _2),
                     boost::bind(&ActionClient::activeCb, this),
                     boost::bind(&ActionClient::feedbackCb, this, _1));
  }

  void CancelActionGoal() {
    if (is_client_available_) {
      client_.cancelGoal();
    } else {
      ROS_ERROR("[Action] state error, cancel goal failed!");
    }
  }

  bool ActionDone() { return is_finish_; }
  bool ActionAccepted() { return is_client_available_; }
  bool ActionError() {
    return false;
  }
  void SetNewTaskState() { is_finish_ = false; }

 private:
  void doneCb(const actionlib::SimpleClientGoalState& state,
              const cotek_msgs::agv_actionResultConstPtr& result) {
    ROS_INFO("Finish [action]!");
    state_ = state.state_;
    is_finish_ = result->is_finish;
    if (is_finish_ == true) {
      is_client_available_ = false;
    }
  }

  void activeCb() {
    is_client_available_ = true;
    ROS_DEBUG("Goal is active! Begin [action].");
  }

  void feedbackCb(const cotek_msgs::agv_actionFeedbackConstPtr& feedback) {
    ROS_DEBUG("[Action] percent: %d", feedback->percent);
    percent_ = feedback->percent;
  }

  actionlib::SimpleActionClient<cotek_msgs::agv_actionAction> client_;

  actionlib::SimpleClientGoalState::StateEnum state_;

  bool is_finish_;

  bool is_client_available_;

  uint32_t percent_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_ACTION_CLIENT_H_
