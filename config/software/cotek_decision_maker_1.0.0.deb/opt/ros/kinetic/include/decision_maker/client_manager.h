/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_MANAGER_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_MANAGER_H_
#include <ros/ros.h>
#include <memory>
#include <string>
#include <vector>
#include "cotek_msgs/agv_actionAction.h"
#include "cotek_msgs/openloopAction.h"
#include "cotek_msgs/track_pathAction.h"
#include "decision_maker/action_client.h"
#include "decision_maker/openloop_client.h"
#include "decision_maker/task_manager.h"
#include "decision_maker/track_path_client.h"

namespace decision_maker {
// state manager, choose client, send goal, and update state
class ClientManager {
 public:
  ClientManager(const std::string actionName, const std::string trackPathName,
                const std::string openloopName) {
    action_ptr_ = boost::make_shared<ActionClient>(actionName);
    track_path_ptr_ = boost::make_shared<TrackPathClient>(trackPathName);
    open_loop_ptr_ = boost::make_shared<OpenloopClient>(openloopName);
  }
  ~ClientManager() {}

  void SendActionClientGoal(const cotek_msgs::agv_actionGoal goal) {
    action_ptr_->SendActionGoal(goal);
  }

  void SendTrackPathClientGoal(const cotek_msgs::track_pathGoal goal) {
    track_path_ptr_->SendTrackPathGoal(goal);
  }

  void SendOpenloopClientGoal(const cotek_msgs::openloopGoal goal) {
    open_loop_ptr_->SendOpenloopGoal(goal);
  }

  void ResetActionClient() { action_ptr_->SetNewTaskState(); }

  void ResetTrackPathClient() { track_path_ptr_->SetNewTaskState(); }

  void ResetOpenloopClient() { open_loop_ptr_->SetNewTaskState(); }

  bool ActionClientActive() { return action_ptr_->ActionAccepted(); }

  bool TrackPathClientActive() { return track_path_ptr_->ActionAccepted(); }

  bool OpenloopClientActive() { return open_loop_ptr_->ActionAccepted(); }

  void GetGoal() {}

  void CancelActionGoal() { action_ptr_->CancelActionGoal(); }

  void CancelTrackPathGoal() { track_path_ptr_->CancelTrackPathGoal(); }

  void CancelOpenloopGoal() { open_loop_ptr_->CancelOpenloopGoal(); }

  bool IsActionClientFinishGoal() { return action_ptr_->ActionDone(); }

  bool IsTrackPathClientFinishGoal() { return track_path_ptr_->ActionDone(); }

  bool IsOpenloopClientFinishGoal() { return open_loop_ptr_->ActionDone(); }

  bool IsActionError() { return action_ptr_->ActionError(); }

  bool IsOpenLoopError() { return open_loop_ptr_->ActionError(); }

  bool IsTrackPathError() { return track_path_ptr_->ActionError(); }

  bool GetCurrentTrackPathMotionType() {
    return track_path_ptr_->ActionMotionType();
  }

 private:
  boost::shared_ptr<ActionClient> action_ptr_;
  boost::shared_ptr<TrackPathClient> track_path_ptr_;
  boost::shared_ptr<OpenloopClient> open_loop_ptr_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_STEP_MANAGER_H_
