/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_INTERFACE_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_INTERFACE_H_
#include "cotek_msgs/switch_map.h"
#include "cotek_msgs/track_pathAction.h"
#include "decision_maker/action_client.h"
#include "decision_maker/client_manager.h"
#include "decision_maker/enum.h"
#include "decision_maker/openloop_client.h"
#include "decision_maker/task_manager.h"
#include "ros/ros.h"

namespace decision_maker {
struct MixGoal {
  GoalType g_type;
  cotek_msgs::track_pathGoal t_goal;
  cotek_msgs::agv_actionGoal a_goal;
};

class AGVState;
class AGVModel;

class AGVState {
 public:
  explicit AGVState(AGVStateType s) : state_(s) {}
  virtual ~AGVState() {}
  AGVStateType State() { return state_; }
  static bool start_timer_;
  virtual boost::shared_ptr<AGVState> handle(
      boost::shared_ptr<TaskManager> tm, boost::shared_ptr<ClientManager> cm,
      boost::shared_ptr<AGVModel> am, boost::shared_ptr<Event> event,
      IndicatorType* indicate, const StateOption option) = 0;

 private:
  AGVStateType state_;
};

class AGVModel {
 public:
  AGVModel(): load_state_(0) {}
  virtual ~AGVModel() {}
  virtual boost::shared_ptr<AGVState> LogicHandle(
      boost::shared_ptr<TaskManager> tm, boost::shared_ptr<ClientManager> cm,
      boost::shared_ptr<Event> event, IndicatorType* indicator,
      const StateOption option) = 0;
  void SetLoadState(uint32_t state) { load_state_ = state; }
  uint32_t GetLoadState() { return load_state_; }
  virtual void ResetState() = 0;
  uint32_t load_state_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_INTERFACE_H_
