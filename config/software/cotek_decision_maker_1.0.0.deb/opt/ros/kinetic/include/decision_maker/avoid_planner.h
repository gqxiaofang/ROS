/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 * map_id
 * 0 : default
 * 1 - 31 : 叉车车型 FORKLIFT
 *     1 - 3 : 前进（长 - 中 - 短）
 *     4 - 6 : 前进左转
 *     7 - 9 : 前进右转
 *     10 - 12 : 后退
 *     13 - 15 : 后退左转
 *     16 - 18 : 后退右转
 *     19 - 31 : 保留
 * 32 - 50 : 顶升车型 JACKUP
 *     32 - 34 : 前进
 *     35 - 37 : 后退
 *     38 - 40 : 前进载货
 *     40 - 50 : 保留
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AVOID_PLANNER_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AVOID_PLANNER_H_
#include <nav_msgs/OccupancyGrid.h>
#include <ros/ros.h>
#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include "decision_maker/geometry.h"
#include "cotek_msgs/safety_setting.h"

namespace decision_maker {

class AvoidPlanner {
  enum class AgvType : uint32_t { FORKLIFT = 1, JackUp = 2 };

  enum class AvoidCode : uint32_t {
    NONE = 0,
    // forklift
    FORK_FORWARD_LONG = 1,
    FORK_FORWARD_MIDDLE = 2,
    FORK_FORWARD_SHORT = 3,
    FORK_FORWARD_LEFT_LONG = 4,
    FORK_FORWARD_LEFT_MIDDLE = 5,
    FORK_FORWARD_LEFT_SHORT = 6,
    FORK_FORWARD_RIGHT_LONG = 7,
    FORK_FORWARD_RIGHT_MIDDLE = 8,
    FORK_FORWARD_RIGHT_SHORT = 9,
    FORK_BACK_LONG = 10,
    FORK_BACK_MIDDLE = 11,
    FORK_BACK_SHORT = 12,
    FORK_BACK_LEFT_LONG = 13,
    FORK_BACK_LEFT_MIDDDLE = 14,
    FORK_BACK_LEFT_SHORT = 15,
    FORK_BACK_RIGHT_LONG = 16,
    FORK_BACK_RIGHT_MIDDLE = 17,
    FORK_BACK_RIGHT_SHORT = 18,
    // jack up
    JACK_FORWARD_LONG = 32,
    JACK_FORWARD_MIDDLE = 33,
    JACK_FORWARD_SHORT = 34,
    JACK_BACK_LONG = 35,
    JACK_BACK_MIDDLE = 36,
    JACK_BACK_SHORT = 37,
    JACK_FORWARD_UPLOAD_LONG = 38,
    JACK_FORWARD_UPLOAD_MIDDLE = 39,
    JACK_FORWARD_UPLOAD_SHORT = 40,
  };

 public:
  AvoidPlanner() {}
  ~AvoidPlanner() {}

  inline void set_agv_pose(Pose pose) { agv_pose_ = pose; }

  /**
   * get avoid strategy according to agv_pose, agv_shape, and enviroment_map
   * return a number from 0 ~ 50 (FORKLIFT: 1 ~ 31, JACKUP: 32~50)
   **/
  AvoidCode GetAvoidStrategy();

 private:
  // load enviroment map from server, and convert to OccupancyGrid
  void LoadEnviromentMap(const std::string &ip, int port,
                         const std::string &api);

  // update enviroment map
  void UpdateEnviromentMap(const std::string &ip, int port,
                           const std::string &api);

  // load agv config file, and get agv type and shape
  void LoadAgvConfig(std::string filename);

  // a thread keep publishing safety setting
  void SafetySettingRunner();
  // bool safety_setting_daemon_;
  // boost::shared_ptr<boost::thread> safety_daemon_;
  // ros::Publisher safety_publisher;

  // nav_msgs::OccupancyGrid enviroment_map_;
  Pose agv_pose_;
  // AgvType agv_type_;
  // std::vector<Point> agv_shape_;  // points according to agv center
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AVOID_PLANNER_H_
