/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_OPENLOOP_CLIENT_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_OPENLOOP_CLIENT_H_
#include <actionlib/client/simple_action_client.h>
#include <string>
#include "cotek_msgs/openloopAction.h"

namespace decision_maker {

class OpenloopClient {
 public:
  OpenloopClient() = delete;
  explicit OpenloopClient(const std::string action_name, bool flag = true)
      : client_(action_name, flag) {
    is_finish_ = false;
    is_client_available_ = false;
    percent_ = 0;
  }

  void SendOpenloopGoal(cotek_msgs::openloopGoal goal) {
    ROS_DEBUG("Waiting for [openloop] server to start.");
    client_.waitForServer();
    ROS_DEBUG("[openloop] server started.");
    client_.sendGoal(goal, boost::bind(&OpenloopClient::doneCb, this, _1, _2),
                     boost::bind(&OpenloopClient::activeCb, this),
                     boost::bind(&OpenloopClient::feedbackCb, this, _1));
  }

  void CancelOpenloopGoal() {
    if (state_ == actionlib::SimpleClientGoalState::StateEnum::PENDING ||
        state_ == actionlib::SimpleClientGoalState::StateEnum::ACTIVE) {
      client_.cancelGoal();
    }

    ROS_ERROR("[openloop] state error, cancel goal failed!");
  }

  bool ActionDone() { return is_finish_; }
  bool ActionAccepted() { return is_client_available_; }
  bool ActionError() { return false; }
  void SetNewTaskState() { is_finish_ = false; }

 private:
  void doneCb(const actionlib::SimpleClientGoalState& state,
              const cotek_msgs::openloopResultConstPtr& result) {
    ROS_INFO("Finish [openloop]!");
    state_ = state.state_;
    is_finish_ = result->is_finish;
    if (is_finish_ == true) {
      is_client_available_ = false;
    }
  }

  void activeCb() {
    is_client_available_ = true;
    ROS_DEBUG("Goal is active! Begin [openloop].");
  }

  void feedbackCb(const cotek_msgs::openloopFeedbackConstPtr& feedback) {
    ROS_DEBUG("[openloop] percent: %d", feedback->percent);
    percent_ = feedback->percent;
  }

  actionlib::SimpleActionClient<cotek_msgs::openloopAction> client_;

  actionlib::SimpleClientGoalState::StateEnum state_;

  bool is_finish_;
  bool is_client_available_;

  uint32_t percent_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_OPENLOOP_CLIENT_H_
