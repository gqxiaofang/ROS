/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_TASK_MANAGER_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_TASK_MANAGER_H_
#include <ros/ros.h>
#include <map>
#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include "cotek_msgs/task_request.h"
#include "decision_maker/step.h"
#include "decision_maker/error_data.h"

namespace decision_maker {

enum class TaskFinishRequestState { NONE = 0, FINISHING_TASK };
enum class TaskResponseState : int32_t {
  NONE = 0,
  ADD_TASK = 1,
  CANCEL_TASK = 2,
  CONTROL_TASK = 3
};

class Task : public std::vector<Step> {
 public:
  Task() = delete;

  explicit Task(std::string id, int sequence_num, int step_size)
      : order_id_(id), sequence_num_(sequence_num), step_size_(step_size) {}
  inline std::string order_id() const { return order_id_; }
  inline int sequence_num() const { return sequence_num_; }
  inline void set_sequence_num(int num) { sequence_num_ = num; }

  std::string ToString() const {
    std::stringstream ss;
    ss << std::endl
       << "TASK: orderId: " << order_id_ << " , sequenceNum: " << sequence_num_
       << " , stepSize: " << step_size_ << std::endl;
    for (const auto& step : *this) {
      ss << "Step: { sequenceId: " << step.sequence_id()
         << ", naviType: " << static_cast<int32_t>(step.navi_type())
         << ", stepType: " << static_cast<int32_t>(step.step_type())
         << ", moveType: " << static_cast<int32_t>(step.move_type())
         << ", pathType: " << static_cast<int32_t>(step.path_type())
         << ", point_id: " << static_cast<int32_t>(step.point_id())
         << ", pose: "
         << "(" << step.point().x() << ", " << step.point().y() << ", "
         << step.point_yaw() << ")"
         << ", plate_relative: " << static_cast<int32_t>(step.plate_relative())
         << ", plate_angle: " << static_cast<float>(step.plate_angle())
         << ", control_point_0: "
         << "(" << static_cast<float>(step.control_point_0().x()) << ", "
         << static_cast<float>(step.control_point_0().y()) << ")"
         << ", control_point_1: "
         << "(" << static_cast<float>(step.control_point_1().x()) << ", "
         << static_cast<float>(step.control_point_1().y()) << ")"
         << ", current_sec_id: " << static_cast<int32_t>(step.current_sec_id())
         << ", target_sec_id: " << static_cast<int32_t>(step.target_sec_id())
         << ", switch_point_id: "
         << static_cast<int32_t>(step.switch_point_id()) << ", switch_point: "
         << "(" << step.switch_point().x() << ", " << step.switch_point().y()
         << ", " << step.switch_point_yaw() << ")"
         << ", odom: " << step.odom() << ", speed: " << step.speed()
         << ", avoid_strategy_code: "
         << static_cast<int32_t>(step.avoid_strategy_code())
         << ", operationType: " << static_cast<int32_t>(step.operation_type())
         << ", operationValue: " << step.operation_value() << " }" << std::endl;
    }

    return ss.str();
  }

 private:
  std::string order_id_;
  int sequence_num_;
  int step_size_;
};

class TaskManager {
 public:
  TaskManager()
      : task_ptr_(nullptr),
        is_doing_task_(false),
        task_cancle_(false),
        current_order_id_("0") {}

  ~TaskManager() {}

  inline std::string TaskOrderId() { return current_order_id_; }

  inline const Step CurrentStep() const { return current_step_; }
  inline const Step NextStep() const { return next_step_; }
  inline const Step NextNextStep() const { return next_next_step_; }

  bool TaskAvailable();

  bool AddTaskData(const cotek_msgs::task_request::ConstPtr& task_req);

  void Moveforward();

  bool MoveTo(int32_t siteId);

  bool CancleTask();

  bool GetTaskCancle() { return task_cancle_; }

  bool FinishTask();

  bool IsNextStepTerminal() const;

  bool IsNextStepFinal() const;

  bool IsNextStepRotation() const;

  bool IsCurrentStepTerminal() const;

  bool IsCurrentStepFinal() const;

  bool IsNextNextStepFinal() const;

  bool IsNextNextStepOperation() const;

  bool IsNextNextStepCurve() const;

  bool IsNextNextStepRotation() const { return false; }

  bool IsVelocityReserve() const;

 private:
  bool AddSteps(boost::shared_ptr<Task> task, bool append,
                std::vector<Step>::iterator* cur,
                const cotek_msgs::task_request::ConstPtr& task_req);

  bool StartTask();

  std::vector<Step>::iterator iter_;
  boost::shared_ptr<Task> task_ptr_;
  Step current_step_;
  Step next_step_;
  Step next_next_step_;

  bool task_cancle_;
  bool is_doing_task_;
  std::string current_order_id_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_TASK_MANAGER_H_
