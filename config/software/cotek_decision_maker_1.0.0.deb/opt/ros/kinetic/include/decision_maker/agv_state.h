/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_STATE_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_STATE_H_
#include "cotek_msgs/switch_map.h"
#include "cotek_msgs/track_pathAction.h"
#include "decision_maker/action_client.h"
#include "decision_maker/agv_interface.h"
#include "decision_maker/enum.h"
#include "decision_maker/openloop_client.h"
#include "decision_maker/client_manager.h"
#include "decision_maker/task_manager.h"
#include "ros/ros.h"

namespace decision_maker {

class Manual;
class Waiting;
class LowPowerMode;
class Doing;
class Finishing;
class Pause;
class Charging;
class Fault;

class Manual : public AGVState {
 public:
  Manual() : AGVState(AGVStateType::MANUAL) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;
};

class Waiting : public AGVState {
 public:
  Waiting() : AGVState(AGVStateType::WAITING), last_time_(0) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;

 private:
  ros::Time last_time_;
};

class LowPowerMode : public AGVState {
 public:
  LowPowerMode() : AGVState(AGVStateType::LOWPOWERMODE) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;
};

class Doing : public AGVState {
 public:
  Doing() : AGVState(AGVStateType::DOING), openloop_(false) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;

 private:
  bool openloop_;
};

class Finishing : public AGVState {
 public:
  Finishing() : AGVState(AGVStateType::FINISHING), last_time_(0) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;

 private:
  ros::Time last_time_;
};

class Pause : public AGVState {
 public:
  Pause() : AGVState(AGVStateType::PAUSE) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;
};

class Charging : public AGVState {
 public:
  Charging() : AGVState(AGVStateType::CHARGING) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;
};

class Fault : public AGVState {
 public:
  Fault() : AGVState(AGVStateType::FAULT) {}
  boost::shared_ptr<AGVState> handle(boost::shared_ptr<TaskManager> tm,
                                     boost::shared_ptr<ClientManager> cm,
                                     boost::shared_ptr<AGVModel> am,
                                     boost::shared_ptr<Event> event,
                                     IndicatorType* indicate,
                                     const StateOption option) override;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_STATE_H_
