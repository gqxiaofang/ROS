/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_ENUM_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_ENUM_H_
#include <string>
#include "cotek_common/enum_type.h"
#include "cotek_msgs/audio_control.h"
#include "cotek_msgs/battery.h"
#include "cotek_msgs/error_state.h"
#include "cotek_msgs/fault_report.h"
#include "cotek_msgs/led_control.h"
#include "cotek_msgs/load_state.h"
#include "cotek_msgs/manual.h"
#include "cotek_msgs/move_feedback.h"
#include "cotek_msgs/node_diagnostic.h"
#include "cotek_msgs/pgv100_feedback.h"
#include "cotek_msgs/safety_io_state.h"
#include "cotek_msgs/safety_state.h"
#include "cotek_msgs/task_control_request.h"
#include "cotek_msgs/task_finish_request.h"
#include "cotek_msgs/task_request.h"
#include "cotek_msgs/task_response.h"
#include "cotek_msgs/update_event.h"

namespace decision_maker {

enum class ErrorType : uint16_t {
  NORMAL = 0,
  TASK_SEQUENCE_NUMBER_ERROR = 1,
  TASK_ORDER_ID_ERROR = 2,
  SEQUENCE_ID_ERROR = 3,
  // 警告(自行增加)
};

enum class GoalType : uint32_t {
  NONE = 0,
  TRACK_PATH_GOAL = 1,
  ACTION_GOAL = 2,
  TRACK_PATH_ACTION_GOAL = 3,
  END = 4
};

enum class AtomicActionType : uint32_t {
  NONE = 0,
  REST = 1,
  PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
  PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度) // 暂时
  CHARGE = 5,  // 自动充电 (operation_value 填0(关), 1(开))
  BEEP = 6,    // 喇叭  (operation_value 填0(关), 1(开))
  CURTIS_RESET = 7,  // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
  BRAKE = 8,  // 电机报闸  (operation_value 填0(关), 1(开))
  LOW_POWER_MODE = 9,
  REACH_FORK_MOVE = 10,     // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_FORWARD = 11,  // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_BACKWARD = 12,  // 前移车叉腿后移(operation_value 默认填0)
  HEAP_LIFT_LOAD = 13,       // 堆高车库位抬货
  HEAP_UN_LOAD = 14,         // 堆高车库位卸货
  PALLET_NOMOVE = 88,       //
  INIT = 99
};

enum class OperationType : uint32_t {
  NONE = 0,
  REST = 1,
  PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
  PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度)
  CHARGE = 5,          // 自动充电 (operation_value 填0(关), 1(开))
};

enum class MotionType : int32_t {
  NONE = 0,
  STARTPOINT = 1,
  LINE = 2,
  BCURVE = 3,
  ARC = 4,
  FORKVAN = 5,
  ROTATE = 10,
  CHARGE = 11,
  UPSTABILIZE = 12,
  DOWNSTABILIZE = 13
};

enum class MoveType : int32_t {
  NONE = 0,
  TRACKPATH = 1,
};

enum class PathType : int32_t {
  NONE = 0,
  POINT = 1,
  LINE = 2,
  BCURVE = 3,
  ARC = 4
};

enum class NaviType : int32_t { NONE = 0, LASER = 1, MAGNETIC = 2, QRCODE = 3 };

enum class StepType : int32_t {
  NONE = 0,
  MOVE = 1,
  OPERATION = 2,
  MOVEOPERATION = 3,
  END_POINT = 4,
  START_POINT = 5
};

enum class StateType : int32_t {
  NONE = 0,
  MANUAL = 1,
  WAITING = 2,
  DOING = 3,
  PAUSE = 4,
  LOWPOWERMODE = 5,
  FINISHING = 6,
  CHARGING = 7,
  FAULT = 8
};

enum class TaskControlType : int32_t {
  NONE = 0,
  STOP_RECOVER = 1,
  PAUSE_STOP = 2,
  EMERGENCY_STOP = 3,
  TASK_CANCEL = 11
};

enum class LoadStateType : int32_t { UNKONW = 0, ON_LOAD = 1, NO_LOAD = 2 };

enum class SafetyStateType : int32_t {
  NONE = 0,
  LEVEL_I = 1,
  LEVEL_II = 2,
  LEVEL_III = 3,
};

enum class AgvErrorLevel : uint16_t {
  NONE = 0,
  WAITING = 1,
  ERROR = 2,
  FATAL = 3
};

enum class ResponseType : int32_t {
  NONE = 0,
  TASK_RECEIVED = 1,
  TASK_ABNORMAL = 2,
  CONTROL_RECEIVED = 3
  // FINISH_RESPONSE = 4,
};

enum class LedStateType : int32_t {
  DEAD = 0,
  RED_CONSTANT = 1,
  RED_BLINK = 2,
  YELLOW_CONSTANT = 3,
  YELLOW_BLINK = 4,
  GREEN_CONSTANT = 5,
  GREEN_BLINK = 6
};

// enum class AudioType : int32_t {
//   NONE = 0,
//   IDLE = 1,
//   FORWARD = 2,
//   BACKWARD = 3,
//   TURNLEFT = 4,
//   TURNRIGHT = 5,
//   FORKERROR = 6,
//   CHARGEERROR = 7,
//   FORKLEGERROR = 8,
//   BUMPER = 9,
//   ATTENTION = 10,
//   AVOID = 11,
//   NOPOWER = 12,
//   FAULT = 13
// };

// 先使用以下的
enum class AudioType : uint8_t {
  NONE = 0,
  BUMP_FAULT = 1,
  FORWARD = 2,
  BACKWARD = 3,
  OBSTACLE_WARN = 4,
  OBSTACLE_STOP = 5,
  LOW_BATTERY = 6,
  FORK_LEG_SAFETY = 7,
  NETWORK_TIMEOUT = 8,
  TASK_PAUSE = 9
};

enum class StateErrorType {
  NONE = 0,
  CHARGEERROR = 1,
  FORKERROR = 2,
  FAULT = 3
};

struct FinishResponseType {
  std::string type;
  bool state;
};

struct Event {
  // 控制信号
  TaskControlType task_control;
  // 手自动
  bool manual;
  // 是否充电
  bool charging;
  // 结束任务响应
  FinishResponseType task_finish_response;
  // 载货状态
  LoadStateType load_state;
  // 错误等级
  AgvErrorLevel agv_error_level;
};

struct IndicatorType {
  bool finish_request;

  bool bummp_error;

  StateErrorType error_code;
};

struct AudioStateType {
  AudioType type;
  uint8_t level;
};

struct Cmd {
  float velocity;
  float omega;
};

struct ReportType {
  std::string order_id;
  // task_manager current_step pointId
  std::string node_id;
  int point_id;  // 表示agv当前所处的位置点
  // 状态机状态
  int agv_status;  // agv 状态, 双方约定枚举类型
  // task_manager current_step sequenceId
  int task_sequence;  // 当前正在处理的任务指令的序列号
  // safety setting
  int avoid_strategy_code;  // 目前先用调度发下来的避障区域

  // 先不考虑
  // int current_section_id;  // 当前所在区域
  // int switch_section_id;   // 需要切换的目标区域
  // std::string task_type;   //
  // 当前正在处理的任务类型，与消息类型与消息体对象对照表对应
};

enum class AGVType : uint32_t {
  UNKONW = 0,
  FORKLIFT = 1,
  QR_JACK_UP = 2,
  HEAP_FORKLIFT = 4
  // JACK_UP = 5,
  // TRANSPLANT = 3, 
};
struct StateOption {
  // 车型
  int agv_type;
  // 等待状态超时时间 s
  int waiting_time_out;
  // 结束任务请求超时时间 s
  int finishing_time_out;
  // 抬货时延长距离open_low_power_mode
  double extend_threshold;

  bool use_lose_pallet_check;

  bool open_low_power_mode;

  bool open_current_detection;
};

// TODO(@someone) 逻辑参数
struct LogicOption {
  // 等待状态超时时间 s
  int waiting_time_out;
  // 结束任务请求超时时间 s
  int finishing_time_out;
  // 抬货时延长距离open_low_power_mode
  double extend_threshold;
  // 车型
  int agv_type;

  bool use_lose_pallet_check;

  bool open_low_power_mode;

  bool open_current_detection;
};

struct DecisionMakerOption {
  int control_cycle;
  int update_event_frequency;
  bool open_shelf_tf;
  bool open_localizer_tf;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_ENUM_H_
