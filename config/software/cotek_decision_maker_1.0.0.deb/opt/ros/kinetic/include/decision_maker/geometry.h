/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_GEOMETRY_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_GEOMETRY_H_

namespace decision_maker {

/**
 * \class Point
 */
class Point {
 public:
  Point() : x_(0.0), y_(0.0) {}
  Point(double x, double y) : x_(x), y_(y) {}
  Point(const Point &p) : x_(p.x_), y_(p.y_) {}

  Point &operator=(const Point &p) {
    if (this == &p) {
      return *this;
    }

    this->x_ = p.x_;
    this->y_ = p.y_;
    return *this;
  }

  inline void set_x(double x) { x_ = x; }
  inline void set_y(double y) { y_ = y; }
  inline const double x() const { return x_; }
  inline const double y() const { return y_; }

 private:
  double x_;
  double y_;
};

/**
 * \class Pose
 */
class Pose {
 public:
  Pose() : point_(0.0, 0.0), yaw_(0.0) {}
  Pose(double x, double y, double yaw) : point_(x, y), yaw_(yaw) {}
  Pose(Point p, double yaw) : point_(p), yaw_(yaw) {}
  Pose(const Pose &pose) : point_(pose.point_), yaw_(pose.yaw_) {}

  Pose &operator=(const Pose &pose) {
    if (this == &pose) {
      return *this;
    }

    this->point_ = pose.point_;
    this->yaw_ = pose.yaw_;
    return *this;
  }

  inline void set_point(Point p) { point_ = p; }
  inline void set_yaw(double yaw) { yaw_ = yaw; }
  inline void set(double x, double y, double yaw) {
    point_.set_x(x);
    point_.set_y(y);
    yaw_ = yaw;
  }

  inline const Point point() const { return point_; }
  inline const double x() const { return point_.x(); }
  inline const double y() const { return point_.y(); }
  inline const double yaw() const { return yaw_; }

 private:
  Point point_;
  double yaw_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_GEOMETRY_H_
