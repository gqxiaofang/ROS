/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_DECISION_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_DECISION_H_
#include <ros/ros.h>
#include <memory>
#include <string>
#include <vector>
#include "decision_maker/agv_model.h"
#include "decision_maker/agv_state.h"
#include "decision_maker/avoid_planner.h"
#include "decision_maker/client_manager.h"
#include "decision_maker/enum.h"
#include "decision_maker/task_manager.h"

namespace decision_maker {

constexpr int k10A = 100;
constexpr int kFullCapacity = 90;
class Decision {
 public:
  Decision(const std::string actionName, const std::string trackPathName,
           const std::string openloopName, StateOption option)
      : option_(option), communicate_online_(true) {
    state_ = boost::make_shared<Waiting>();
    task_manager_ptr_ = boost::make_shared<TaskManager>();
    client_manager_ptr_ = boost::make_shared<ClientManager>(
        actionName, trackPathName, openloopName);
    event_ptr_ = boost::make_shared<Event>();

    switch (static_cast<AGVType>(option_.agv_type)) {
      case AGVType::FORKLIFT: {
        agv_model_ptr_ = boost::make_shared<ForkLiftModel>();
        break;
      }
      case AGVType::HEAP_FORKLIFT: {
        agv_model_ptr_ = boost::make_shared<HeapForkLiftModel>();
        break;
      }
        // case AGVType::JACK_UP: {
        //   agv_model_ptr_ = boost::make_shared<JackUpModel>();
        //   break;
        // }
        // case AGVType::LASER_JACK_UP: {
        //   agv_model_ptr_ = boost::make_shared<LaserJackUpModel>();
        //   break;
        // }
        // case AGVType::TRANSPLANT: {
        //   agv_model_ptr_ = boost::make_shared<TransPlantModel>();
        //   break;
      // }
      default: { ROS_ERROR("unknow agv type !!!"); }
    }

    // event
    event_ptr_->manual = false;
    event_ptr_->charging = false;
    event_ptr_->task_control = TaskControlType::NONE;
    event_ptr_->agv_error_level = AgvErrorLevel::NONE;
    event_ptr_->load_state = LoadStateType::UNKONW;
    event_ptr_->task_finish_response.state = false;
    // indicator
    indicator_.error_code = StateErrorType::NONE;
    indicator_.finish_request = false;
    indicator_.bummp_error = false;

    led_state_ = LedStateType::GREEN_CONSTANT;
    safety_state_ = SafetyStateType::NONE;
    safety_io_state_ = AvoidLevel::NONE;
    response_state_ = ResponseType::NONE;
    audio_state_ = {AudioType::NONE, 25};  // 0 ~ 30
    battery_ = 100;
    feedback_cmd_ = {0, 0};

    report_.agv_status = static_cast<int>(AGVStateType::NONE);
    report_.order_id = "0";
    report_.node_id = "0";
    report_.avoid_strategy_code = 0;
    report_.point_id = 0;
    report_.task_sequence = 0;
  }
  ~Decision() {}

  // step ptr send goal, update goal, avoid ptr set pose
  void Run();
  // 发送应答响应
  inline ReportType Report() const { return report_; }
  inline IndicatorType IndicatorState() const { return indicator_; }
  inline LedStateType LedState() const { return led_state_; }
  inline SafetyStateType SafetyState() const { return safety_state_; }
  inline AudioStateType AudioState() const { return audio_state_; }
  inline AvoidLevel SafetyIoState() const { return safety_io_state_; }
  inline bool IsManual() const { return event_ptr_->manual; }

  inline bool UpdateOption(const StateOption& option) { option_ = option; }

  inline bool TaskAvailable() const {
    return task_manager_ptr_->TaskAvailable();
  }

  // inline ResponseType Response() const { return response_state_; }
  // inline void ClearResponse() { response_state_ = ResponseType::NONE; }
  inline void ClearFinishResopnseEvent() {
    event_ptr_->task_finish_response = {"", false};
  }

  void AddTaskData(const cotek_msgs::task_request::ConstPtr& task_req) {
    if (!event_ptr_->manual) {
      response_state_ = task_manager_ptr_->AddTaskData(task_req)
                            ? ResponseType::TASK_RECEIVED
                            : ResponseType::TASK_ABNORMAL;
      ROS_DEBUG("add task state: %d", static_cast<int>(response_state_));
    } else {
      ROS_ERROR("manual mode can not add task");
      response_state_ = ResponseType::TASK_ABNORMAL;
    }
  }

  void AddTaskFinishResponseData(
      const cotek_msgs::task_response::ConstPtr& task_resp) {
    event_ptr_->task_finish_response.type = task_resp->task_type;
    event_ptr_->task_finish_response.state = task_resp->state;
  }

  void AddMoveFeedbackData(
      const cotek_msgs::move_feedback::ConstPtr& move_feedback) {
    feedback_cmd_.velocity = move_feedback->actual_velocity;
    feedback_cmd_.omega = move_feedback->actual_omega;
  }

  void AddBatteryData(const cotek_msgs::battery::ConstPtr& battery) {
    battery_ = battery->capacity;
    if (option_.open_current_detection) {
      event_ptr_->charging = battery->current > k10A ? true : false;
    } else {
      if (battery_ > kFullCapacity) {
        event_ptr_->charging = false;
      } else {
        event_ptr_->charging = true;
      }
    }
  }

  void AddLoadStateData(const cotek_msgs::load_state::ConstPtr& load_state) {
    event_ptr_->load_state = (LoadStateType)load_state->load_state;
    agv_model_ptr_->SetLoadState(load_state->load_state);
  }

  void AddErrorLevelData(uint16_t error_level) {
    event_ptr_->agv_error_level = (AgvErrorLevel)error_level;
  }

  void AddSafetyStateData(
      const cotek_msgs::safety_state::ConstPtr& safety_state) {
    safety_state_ = (SafetyStateType)safety_state->avoid_level;
  }

  void AddSafetyIoStateData(
      const cotek_msgs::safety_io_state::ConstPtr& safety_io_state) {
    safety_io_state_ = (AvoidLevel)safety_io_state->avoid_io_state;
  }
  void AddControlRequestData(
      const cotek_msgs::task_control_request::ConstPtr& control_request) {
    event_ptr_->task_control = (TaskControlType)control_request->control_type;
  }

  void AddManualData(const cotek_msgs::manual::ConstPtr& manual) {
    event_ptr_->manual = manual->mode;
  }

  void AddCommunocateStateData(bool state) { communicate_online_ = state; }

  inline ErrorType GetError() { return ErrorData::get()->error(); }

  void ClearError() { ErrorData::get()->ClearError(); }

 private:
  void LedAudioProcess();

  boost::shared_ptr<TaskManager> task_manager_ptr_;
  boost::shared_ptr<ClientManager> client_manager_ptr_;
  boost::shared_ptr<AGVModel> agv_model_ptr_;
  // boost::shared_ptr<AvoidPlanner> avoid_ptr_;

  // 只是改变灯的颜色，音乐类型
  // 避障状态
  SafetyStateType safety_state_;
  // led 颜色
  LedStateType led_state_;
  // 不同部位避障情况，用于音频
  AvoidLevel safety_io_state_;
  bool communicate_online_;
  // 音乐类型
  AudioStateType audio_state_;
  // 电池电量百分比
  uint8_t battery_;
  // 当前agv运行速度
  Cmd feedback_cmd_;

  // task_request, control_request响应
  ResponseType response_state_;
  // 状态机状态
  boost::shared_ptr<AGVState> state_;
  // 内部信号
  IndicatorType indicator_;
  // 外部事件: 手自动信号，控制信号，载货状态，超时时间，结束任务响应
  boost::shared_ptr<Event> event_ptr_;
  // 状态机参数
  StateOption option_;
  // 当前车的信息
  ReportType report_;
};  // namespace decision_maker

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_DECISION_H_
