/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_MODEL_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_MODEL_H_
#include <deque>
#include "cotek_common/cotek_action_boom.h"
#include "cotek_common/math.h"
#include "decision_maker/agv_interface.h"

namespace decision_maker {

class ForkLiftModel : public AGVModel {
 public:
  ForkLiftModel() {
    ros::NodeHandle nh;
    ros::ServiceClient switch_map_srv_ =
        nh.serviceClient<cotek_msgs::switch_map>("switch_map");
  }
  ~ForkLiftModel() {}
  boost::shared_ptr<AGVState> LogicHandle(boost::shared_ptr<TaskManager> tm,
                                          boost::shared_ptr<ClientManager> cm,
                                          boost::shared_ptr<Event> event,
                                          IndicatorType* indicator,
                                          const StateOption option) override;
  ros::ServiceClient switch_map_srv_;
  void ResetState() override {}
  bool carry_pallet_;
};

class HeapForkLiftModel : public AGVModel {
 public:
  HeapForkLiftModel() {
    ros::NodeHandle nh;
    ros::ServiceClient switch_map_srv_ =
        nh.serviceClient<cotek_msgs::switch_map>("switch_map");
  }
  ~HeapForkLiftModel() {}
  boost::shared_ptr<AGVState> LogicHandle(boost::shared_ptr<TaskManager> tm,
                                          boost::shared_ptr<ClientManager> cm,
                                          boost::shared_ptr<Event> event,
                                          IndicatorType* indicator,
                                          const StateOption option) override;
  ros::ServiceClient switch_map_srv_;
  void ResetState() override {}
  bool carry_pallet_;
};

class JackUpModel : public AGVModel {
 public:
  JackUpModel() : step_processed_(true), init_step_(true) {}
  ~JackUpModel() {}
  boost::shared_ptr<AGVState> LogicHandle(boost::shared_ptr<TaskManager> tm,
                                          boost::shared_ptr<ClientManager> cm,
                                          boost::shared_ptr<Event> event,
                                          IndicatorType* indicator,
                                          const StateOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  // 根据next step任务类型生成goals
  bool ProcessStep(boost::shared_ptr<TaskManager> tm,
                   boost::shared_ptr<Event> event, const StateOption option);
  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

class LaserJackUpModel : public AGVModel {
 public:
  LaserJackUpModel() {}
  ~LaserJackUpModel() {}
  boost::shared_ptr<AGVState> LogicHandle(boost::shared_ptr<TaskManager> tm,
                                          boost::shared_ptr<ClientManager> cm,
                                          boost::shared_ptr<Event> event,
                                          IndicatorType* indicator,
                                          const StateOption option) override;
  void ResetState() override {
    step_processed_ = true;
    init_step_ = true;
    step_goals_.clear();
  }

 private:
  bool ProcessStep(boost::shared_ptr<TaskManager> tm,
                   boost::shared_ptr<Event> event, const StateOption option);

  std::deque<MixGoal> step_goals_;
  MixGoal current_goal_;
  bool step_processed_;
  bool init_step_;
};

class TransPlantModel : public AGVModel {
 public:
  TransPlantModel() {}
  ~TransPlantModel() {}

  boost::shared_ptr<AGVState> LogicHandle(boost::shared_ptr<TaskManager> tm,
                                          boost::shared_ptr<ClientManager> cm,
                                          boost::shared_ptr<Event> event,
                                          IndicatorType* indicator,
                                          const StateOption option) override;
  void ResetState() override {}
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_AGV_MODEL_H_
