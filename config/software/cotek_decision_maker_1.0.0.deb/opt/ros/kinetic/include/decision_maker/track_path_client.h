/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef DECISION_MAKER_INCLUDE_DECISION_MAKER_TRACK_PATH_CLIENT_H_
#define DECISION_MAKER_INCLUDE_DECISION_MAKER_TRACK_PATH_CLIENT_H_
#include <actionlib/client/simple_action_client.h>
#include <string>
#include "cotek_msgs/track_pathAction.h"
#include "ros/ros.h"

namespace decision_maker {

class TrackPathClient {
 public:
  TrackPathClient() = delete;
  explicit TrackPathClient(const std::string action_name, bool flag = true)
      : client_(action_name, flag) {
    is_finish_ = false;
    is_client_available_ = false;
    error_ = false;
    motion_type_ = 0;
  }

  void SendTrackPathGoal(cotek_msgs::track_pathGoal goal) {
    ROS_DEBUG("Waiting for [track_path] server to start.");
    client_.waitForServer();
    ROS_DEBUG("[track_path] server started.");
    client_.sendGoal(goal, boost::bind(&TrackPathClient::doneCb, this, _1, _2),
                     boost::bind(&TrackPathClient::activeCb, this),
                     boost::bind(&TrackPathClient::feedbackCb, this, _1));
  }

  void CancelTrackPathGoal() {
    if (is_client_available_) {
      client_.cancelGoal();
      return;
    }
    ROS_ERROR("[track_path] state error, cancel goal failed!");
  }

  bool ActionDone() { return is_finish_; }

  bool ActionAccepted() { return is_client_available_; }

  bool ActionError() { return error_; }

  uint32_t ActionMotionType() { return motion_type_; }

  void SetNewTaskState() { is_finish_ = false; }

 private:
  void doneCb(const actionlib::SimpleClientGoalState& state,
              const cotek_msgs::track_pathResultConstPtr& result) {
    ROS_INFO("navigation finish track_path.");
    is_finish_ = result->is_finish;
    if (is_finish_ == true) {
      is_client_available_ = false;
    }
  }

  void activeCb() {
    is_client_available_ = true;
    ROS_DEBUG("Goal is active! Begin [track_path].");
  }

  void feedbackCb(const cotek_msgs::track_pathFeedbackConstPtr& feedback) {
    ROS_DEBUG("[track_path] state: %d", feedback->error);
    ROS_DEBUG("[track_path] motion_type: %d", feedback->motion_type);
    error_ = feedback->error;
    motion_type_ = feedback->motion_type;
  }

  actionlib::SimpleActionClient<cotek_msgs::track_pathAction> client_;

  bool is_finish_;
  bool is_client_available_;
  bool error_;
  uint32_t motion_type_;
};

}  // namespace decision_maker

#endif  // DECISION_MAKER_INCLUDE_DECISION_MAKER_TRACK_PATH_CLIENT_H_
