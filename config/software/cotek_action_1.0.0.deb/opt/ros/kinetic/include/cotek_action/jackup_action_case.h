/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_JACKUP_ACTION_CASE_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_JACKUP_ACTION_CASE_H_
// #include <geometry_msgs/TransformStamped.h>
#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <map>
#include "cotek_action/action_interface.h"
#include "cotek_msgs/jack_up_action.h"
#include "tf/transform_broadcaster.h"

namespace cotek_action {
#if 0
class JackupAction : public ActionInterface {
 public:
  JackupAction() : timeout(false) {
    ros::NodeHandle nh;
    jackup_action_pub_ = nh.advertise<cotek_msgs::jack_up_action>(
        cotek_topic::kJackUpActionTopic, kTopicSendCacheSize);
    shelf_tf_ = boost::make_shared<tf::TransformListener>(ros::Duration(5.0));
    ActionInit();
  }
  // virtual ~JackupAction(){}

  void UpdateData(AgvData *Get_info) override;

  uint32_t FeedBack() override;

  bool IsFinished() override;

  void DataReset(cotek_msgs::jack_up_action *msg);

  void PalletStateProcess(uint8_t flag, AgvData *Get_info);

  void ActionNone(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void PalletNoMove(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void PalletUp(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void PalletDown(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void PalletRotation(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void PalletZero(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void MotorDisable(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void MotorEnable(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void ActionCharge(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  void MotorClearAlarm(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  // pause action
  void ActionWaiting(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  // Low_Power_Mode
  void LowPowerMode(cotek_msgs::jack_up_action *msg, AgvData *Get_info);

  // Init action list
  void ActionInit();

  void ExecuteAction(AgvData *Get_info) override;

  void PublishActionMsg() override;

 private:
  ros::Publisher jackup_action_pub_;
  ros::Time action_time_;
  bool doing_action_;
  cotek_msgs::jack_up_action msg_;
  boost::shared_ptr<tf::TransformListener> shelf_tf_;
  double shelf_delta_;
  std::map<int32_t,
           std::function<void(cotek_msgs::jack_up_action *, AgvData *)>>
      action_map_;
  bool timeout;
  uint32_t pallet_nomove_flag;
  double pallet_tar_theta_;
  bool CheckPallet(bool use, AgvData *Get_info);
  bool CheckTimeout(bool use, double limit_time, AgvData *Get_info);
};
#endif
}  // namespace cotek_action

#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_JACKUP_ACTION_CASE_H_
