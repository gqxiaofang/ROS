/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_CONFIG_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_CONFIG_H_
#include <cotek_common/json11.h>
#include <cotek_common/log_porting.h>
#include <ros/ros.h>
#include <map>
#include <fstream>
#include <sstream>
#include <string>
#include "cotek_action/type_enum.h"

namespace cotek_action {

class ActionConfig {
 public:
  ~ActionConfig() {}
  static ActionConfig& Instance() {
    static ActionConfig instance;
    return instance;
  }
  ActionConfig(const ActionConfig&) = delete;
  ActionConfig& operator=(const ActionConfig&) = delete;
  void SetAgvType(int type) { agv_type_ = type; }
  static std::string GetStringFromFile(const std::string& file_path) {
    std::ifstream ifs(file_path);
    if (!ifs.is_open()) {
      ifs.close();
      return std::string();
    }
    std::stringstream ss;
    ss << ifs.rdbuf();
    ifs.close();
    return ss.str();
  }
  void SetLogLevel();

  // 加载 json 文件获取配置
  bool LoadActionConfig(const std::string& json_str,
                        cotek_action::AgvActionOption* option);

  inline const AgvType GetAgvType() { return static_cast<AgvType>(agv_type_); }
  std::map<std::string, uint32_t> forklift_action;
  std::map<std::string, uint32_t> jack_action;

 private:
  ActionConfig() {}
  int agv_type_;
};
}  // namespace cotek_action

#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_CONFIG_H_
