/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_SERVER_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_SERVER_H_
#include <actionlib/server/simple_action_server.h>
#include <cotek_common/cotek_topic_name.h>
#include <cotek_common/log_porting.h>
#include <cstdio>
#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include "action_config.h"
#include "action_interface.h"
#include "cotek_action/data_center.h"
#include "cotek_action/forklift_action_case.h"
#include "cotek_action/jackup_action_case.h"
#include "cotek_action/transplant_action_case.h"
#include "cotek_action/type_enum.h"
#include "cotek_msgs/agv_actionAction.h"
#include "cotek_msgs/node_diagnostic.h"

namespace cotek_action {

class ActionServer {
 public:
  ActionServer() = delete;
  ActionServer(std::string name, const AgvActionOption& option)
      : server_(name, false), server_name_(name) {
    ros::NodeHandle nh;
    AgvData::get()->SetOption(&option);
    action_fault_pub_ = nh.advertise<cotek_msgs::node_diagnostic>(
        cotek_topic::kActionDiagnosticTopic, kTopicReciveCacheSize);
    server_.registerGoalCallback(boost::bind(&ActionServer::GoalCB, this));
    server_.registerPreemptCallback(
        boost::bind(&ActionServer::PreemptCB, this));
    server_.start();
  }
  ~ActionServer() {}
  // start action server
  void ServerStart();
  void Init();
  void GoalCB();
  void PreemptCB();
  void UpdateOption(const AgvActionOption& option);
 private:
  void Runner();

  actionlib::SimpleActionServer<cotek_msgs::agv_actionAction> server_;
  std::string server_name_;
  ros::Publisher action_fault_pub_;
  cotek_msgs::node_diagnostic fault_;
  cotek_msgs::agv_actionFeedback feedback_;
  cotek_msgs::agv_actionResult result_;

  std::shared_ptr<std::thread> run_executor_;
  std::shared_ptr<cotek_action::ActionInterface> action_interface_;
};

}  // namespace cotek_action
#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_SERVER_H_
