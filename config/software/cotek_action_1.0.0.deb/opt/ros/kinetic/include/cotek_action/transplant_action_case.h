/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_TRANSPLANT_ACTION_CASE_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_TRANSPLANT_ACTION_CASE_H_
#include <ros/ros.h>
#include "cotek_action/action_interface.h"
namespace cotek_action {

class TranspalntAction : public ActionInterface {
 public:
  TranspalntAction() {}
  virtual ~TranspalntAction() {}

  void UpdateData(AgvData* Get_info) override {
    ROS_INFO("Transplant AGV update...%d", Get_info->goal_.action_type);
    ActionInit();
  }
  uint32_t FeedBack() override { return 0; }

  bool IsFinished() override { return true; }

  void ExecuteAction(AgvData* Get_info) {}

  static void ActionNone();

  static void ActionTransRight();

  static void ActionTransLeft();

  static void ActionTransUp();

  static void ActionTransDown();

  static void ActionCharge();

  void ActionInit();

  void PublishActionMsg() {}

 private:
  // std::map<int32_t,action_exec> transact_map;

  // std::map<int32_t,std::function<void(cotek_msgs::forklift_action *,AgvData
  // *)>>  action_map;
};

}  // namespace cotek_action

#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_TRANSPLANT_ACTION_CASE_H_
