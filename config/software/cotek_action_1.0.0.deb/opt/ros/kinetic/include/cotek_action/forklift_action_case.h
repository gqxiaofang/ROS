/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_FORKLIFT_ACTION_CASE_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_FORKLIFT_ACTION_CASE_H_
#include <ros/ros.h>
#include <map>
#include "cotek_action/action_interface.h"
#include "cotek_msgs/forklift_action.h"

namespace cotek_action {

class ForkliftAction : public ActionInterface {
 public:
  ForkliftAction() : timeout(false), first_flag(false) {
    ros::NodeHandle nh;
    forklift_action_pub_ = nh.advertise<cotek_msgs::forklift_action>(
        cotek_topic::kForkLiftActionTopic, kTopicSendCacheSize);
    ActionInit();
  }

  virtual ~ForkliftAction() {}
  // to do .. update constrct data strct in this scope
  void UpdateData(AgvData *Get_info) override;
  // return action progress =()%
  uint32_t FeedBack() override;
  // return whethe action done
  bool IsFinished() override;
  // release goal..
  void DataReset();

  void Waiting(cotek_msgs::forklift_action *msg, AgvData *Get_info);

  void Rest(cotek_msgs::forklift_action *msg, AgvData *Get_info);

  void LowPowerMode(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // pallet up
  void PalletForkUp(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // pallet down
  void PalletForkDown(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // pallet heap move down and up..
  void HeapForkMove(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // 堆高车抬货
  void HeapLiftLoad(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // 堆高车卸货
  void HeapUnLoad(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // 前移式叉腿移动
  void ReachForkMove(cotek_msgs::forklift_action *msg, AgvData *Get_info);

  // motor break
  void Break(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // beeper lauding..
  void Beep(cotek_msgs::forklift_action *msg, AgvData *Get_info);
  // curtis controller reset
  void ForkliftBodyCotrollerReset(cotek_msgs::forklift_action *msg,
                                  AgvData *Get_info);
  // charge
  void Charge(cotek_msgs::forklift_action *msg, AgvData *Get_info);

  void ActionInit();

  void ExecuteAction(AgvData *Get_info) override;

  void PublishActionMsg() override;

 private:
  ros::Publisher forklift_action_pub_;

  cotek_msgs::forklift_action msg_;

  std::map<uint32_t,
           std::function<void(cotek_msgs::forklift_action *, AgvData *)> >
      action_map_;
  double cmd_height_base_;
  bool timeout;
  bool first_flag;

  ros::Time action_time_;
  bool doing_action_;
  bool CheckTimeout(bool use, double limit_time, AgvData *Get_info);
};

}  // namespace cotek_action
#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_FORKLIFT_ACTION_CASE_H_
