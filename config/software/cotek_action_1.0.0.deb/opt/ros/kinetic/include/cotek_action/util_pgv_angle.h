/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_UTIL_PGV_ANGLE_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_UTIL_PGV_ANGLE_H_
#include <cmath>

namespace cotek_action {

#define PI_MATH 3.14
#define PALLET_REDUCE_RATIO 80

enum class Direction {
  None = 0,
  XPositive = 0x1100,  // on X Axis positive direction
  XNegative = 0x1300,  // on X Axis negative direction
  YPositive = 0x1400,  // on Y Axis positive direction
  YNegative = 0x1200,  // on Y Axis negative direction
  XPosYPos = 0x1500,
  XPosYNeg = 0x1600,
  XNegYPos = 0x1700,
  XNegYNeg = 0x1800,
};

struct PID_Handle {
  float kp;
  float ki;
  float kd;
  float integrator;
  float previous_error;
  float debug_p_out;
  float debug_i_out;
  float debug_d_out;
};
// classic pid
template <typename T>
T PID_Process(PID_Handle* handle, T error) {
  T output = 0;
  static T err1 = 0.0;
  static T err2 = 0.0;
  handle->integrator = error + err1 + err2;
  handle->previous_error = err1;
  handle->debug_p_out = handle->kp * error;
  handle->debug_i_out = handle->ki * handle->integrator;
  handle->debug_d_out = handle->kd * (error - handle->previous_error);

  output = handle->debug_p_out + handle->debug_i_out + handle->debug_d_out;
  err2 = err1;
  err1 = error;
  return output;
}

struct IncreasingPIDHandle {
  float kp;
  float ki;
  float kd;
  float diff_last;
  float diff_prev;
  float incpid;
};
// Incremental pid
template <typename T>
float IncrementalPIDProcess(IncreasingPIDHandle* handle, T error) {
  T output = 0;

  handle->incpid =
      handle->kp * (error - handle->diff_last) + handle->ki * error +
      handle->kd * (error - 2 * handle->diff_last + handle->diff_prev);
  handle->diff_prev = handle->diff_last;
  handle->diff_last = error;

  output += handle->incpid;

  return output;
}

// wheel omega to motor rotate speed
template <typename T>
T rads2rmin(T rad_persec, int reduceRatio)
{
    return  60 * reduceRatio * rad_persec / (2 * PI_MATH);
}

template <typename T>
T Omega2PalletRotater(T omega) {
  return rads2rmin(omega, PALLET_REDUCE_RATIO);
}

// motor rotate speed to wheel omega
template <typename T>
T rmin2rads(T r_permin, T reduceRatio) {
  return r_permin * 2.0f * PI_MATH / 60.0f / reduceRatio;
}

// degree conver to rad
template <typename T>
T Degree2rad(T degree) {
  return degree * 2.0f * PI_MATH / 360.0f;
}

// rad conver to degree
template <typename T>
T rad2degree(T rad) {
  return rad * 360.0f / (2.0f * PI_MATH);
}

//
template <typename T>
T normalize_angle_positive(T angle) {
  return static_cast<T>(
      fmod(fmod(angle, 2.0f * PI_MATH) + 2.0f * PI_MATH, 2.0f * PI_MATH));
}

//
template <typename T>
T normalize_angle(T angle) {
  T a = normalize_angle_positive(angle);
  if (a > PI_MATH) a -= 2.0f * PI_MATH;
  return a;
}
//
template <typename T>
T AngleSubtract(T param1, T param2) {
  return normalize_angle(param1 - param2);
}
//
template <typename T>
T AngleAddition(T param1, T param2) {
  T angle = param1 + param2;
  if (angle > PI_MATH)
    return fmod(fmod(angle, 2 * PI_MATH) - 2 * PI_MATH, 2 * PI_MATH);
  else if (angle < -PI_MATH)
    return fmod(fmod(angle, 2 * PI_MATH) + 2 * PI_MATH, 2 * PI_MATH);
  else
    return angle;
}

template <typename T>
bool fNearby(T left, T right, T diff) {
  return fabs(left - right) <= diff ? true : false;
}

template <typename T>
Direction Angle2Direction(T current_angle) {
  if (fNearby(current_angle, static_cast<T>(0), static_cast<T>(PI_MATH / 4)))
    return Direction::XPositive;
  if (fNearby(current_angle, static_cast<T>(PI_MATH / 2),
              static_cast<T>(PI_MATH / 4)))
    return Direction::YPositive;
  if (fNearby(current_angle, static_cast<T>(-PI_MATH / 2),
              static_cast<T>(PI_MATH / 4)))
    return Direction::YNegative;
  return Direction::XNegative;
}

//
template <typename T>
float Direction2Angle(T direction) {
  switch (direction) {
    case Direction::XPositive:
      return 0.00f;
    case Direction::XNegative:
      return PI_MATH;
    case Direction::YPositive:
      return PI_MATH / 2;
    case Direction::YNegative:
      return -PI_MATH / 2;
    case Direction::XPosYPos:
      return PI_MATH / 4;
    case Direction::XPosYNeg:
      return -PI_MATH / 4;
    case Direction::XNegYPos:
      return PI_MATH * 3 / 4;
    case Direction::XNegYNeg:
      return -PI_MATH * 3 / 4;
    default:
      return -1;
  }
}
template <typename T>
float fbound(T raw, T rmin, T rmax) {
  return fmin(fmax(raw, rmin), rmax);
}

template <typename T>
T AccDecOptimalTime(T cur_speed, T tar_speed, T dist_to_target, T max_acc,
                       T max_dec, T max_speed_on_route, T t_control_sec) {
  const float Torlerance =
      0.01f;  // To judge whether an input value is in the neighborhood of 0.
  T next_speed = 0;
  if (dist_to_target > 0 && max_acc > 0 && max_dec > 0 &&
      t_control_sec > 0) {  // check whether the inputs are the correct ranges
    if (tar_speed >=
        0) {  // It is expected that AGV moves forward at destination
      if (cur_speed >= -Torlerance &&
          dist_to_target >= 0) {  // AGV currently moves forward
        T max_speed_for_optimal_control = sqrt(
            2 * max_acc * max_dec * (dist_to_target) / (max_acc + max_dec) +
            (max_dec * pow(cur_speed, 2) + max_acc * pow(tar_speed, 2)) /
                (max_acc + max_dec));
        if (max_speed_for_optimal_control <= cur_speed) {  // Slow down
          next_speed = sqrt(pow(tar_speed, 2) + 2 * max_dec * (dist_to_target));
        } else {  // speed up
          T next_speed_tmp = cur_speed + max_acc * t_control_sec;
          next_speed =
              fmin(fmin(fmax(fabs(max_speed_on_route), fabs(tar_speed)),
                        max_speed_for_optimal_control),
                   next_speed_tmp);
        }
      } else {
        next_speed = 0;
      }
    } else {  // AGV moves backward at destination
      if (cur_speed <= Torlerance &&
          dist_to_target >= 0) {  // AGV currently moves backward
        float max_speed_for_optimal_control = -sqrt(
            2 * max_acc * max_dec * (dist_to_target) / (max_acc + max_dec) +
            (max_dec * pow(cur_speed, 2) + max_acc * pow(tar_speed, 2)) /
                (max_acc + max_dec));
        if (max_speed_for_optimal_control >= cur_speed) {  // slow down
          next_speed =
              -sqrt(pow(tar_speed, 2) + 2 * max_dec * (dist_to_target));
        } else {  // speed up
          T next_speed_tmp = cur_speed - max_acc * t_control_sec;
          next_speed =
              fmax(fmax(-fmax(fabs(max_speed_on_route), fabs(tar_speed)),
                        max_speed_for_optimal_control),
                   next_speed_tmp);
        }
      } else {
        next_speed = 0;
      }
    }
  } else {
    next_speed = 0;
  }

  return next_speed;
}

//
template <typename T>
T AccDecStop(T cur_speed, T dist_to_target, T max_acc, T max_dec,
               T max_speed_on_route, T tor, T t_control_sec) {
  const T tar_speed = 0.0f;
  float next_speed = 0;

  if (dist_to_target > tor) {
    next_speed =
        AccDecOptimalTime(cur_speed, tar_speed, dist_to_target, max_acc,
                             max_dec, max_speed_on_route, t_control_sec);
  } else if (dist_to_target < -tor) {
    next_speed =
        -AccDecOptimalTime(-cur_speed, tar_speed, -dist_to_target, max_acc,
                              max_dec, max_speed_on_route, t_control_sec);
  } else {
    next_speed = 0.0f;  // 2 * dist_to_target;
  }
  return next_speed;
}

/**
 *  t:从开始已经走过的路程
    b:beginning position，起始位置
    c:change，要移动的距离，就是终点位置减去起始位置。
    d: duration ，缓和效果持续的时间。-持续缓动总距离
*/
// linear dec..
template <typename T>
T LinearEase(T t, T b, T c, T d) {
  return c * (1 - t / d) + b;
}
template <typename T>
T SineEaseInOut(T t, T b, T c, T d) {
  return -c / 2 * (cos(PI_MATH * (1 - t / d)) - 1) + b;
}
template <typename T>
T QuadEaseInOut(T t, T b, T c, T d) {
  if ((2 * t / d) < 1) {
    t /= d / 2;
    return c - c / 2 * t * t + b;
  }
  t = t - 1;
  return -c / 2 * (t * (2 - t) - 1) + b;
}
template <typename T>
T CubicEaseInOut(T t, T b, T c, T d) {
  if ((2 * t / d) < 1) {
    t /= d / 2;
    return c - c / 2 * t * t * t + b;
  }
  t = t - 2;
  return c - c / 2 * (t * t * t + 2) + b;
}
template <typename T>
T QuartEaseInOut(T t, T b, T c, T d) {
  if ((2 * t / d) < 1) {
    t /= d / 2;
    return c - c / 2 * t * t * t * t + b;
  }
  t = t - 2;
  return c + c / 2 * (t * t * t * t - 2) + b;
}
template <typename T>
T QuintEaseInOut(T t, T b, T c, T d) {
  if ((2 * t / d) < 1) {
    t /= d / 2;
    return c - c / 2 * t * t * t * t * t + b;
  }
  t = t - 2;
  return c - c / 2 * (t * t * t * t * t + 2) + b;
}
template <typename T>
T ExpoEaseInOut(T t, T b, T c, T d) {
  if (t == 0) return b;
  if (t == d) return b + c;
  if ((2 * t / d) < 1) {
    t /= d / 2;
    return c - c / 2 * pow(2, 10 * (t - 1)) + b;
  }
  t = t - 1;
  return c - c / 2 * (-pow(2, -10 * t) + 2) + b;
}
template <typename T>
T CircEaseInOut(T t, T b, T c, T d) {
  if ((2 * t / d) < 1) {
    t /= d / 2;
    return c + c / 2 * (sqrt(1 - t * t) - 1) + b;
  }
  t = t - 2;
  return c - c / 2 * (sqrt(1 - t * t) + 1) + b;
}

}  // namespace cotek_action

#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_UTIL_PGV_ANGLE_H_
