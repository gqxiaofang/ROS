/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_TYPE_ENUM_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_TYPE_ENUM_H_
#include <ros/ros.h>
#include <string>
#include <vector>

namespace cotek_action {
// public topic name and size
#define PI_MATH 3.14
enum class AgvType { UNKONW = 0, FORKLIFT = 1, JACK_UP = 2, TRANSPLANT = 3 };
enum class BatteryType { CurtisBattery = 1, BaoeBattery = 2, ZhiliBattery = 3 };
enum class ActionStatus {
  UNSTART = 0,
  DOING = 1,
  FINISH = 2,
  PAUSE = 3,
  DOING_FAULT = 4,
  CANCEL = 5,
  TIMEOUT = 6,
  EXCEPTION = 7
};
enum class Pallet_Zero_State { UNZEROED = 0, ZEROED = 1 };
enum class ForkStateType : uint32_t { DOWN = 0, MIDDLE = 1, UP = 2 };
enum class ActionFault : uint8_t {
  AGV_NO_ERROR = 0,
  ERROR_WRONG_AGV_TYPE = 1,
  ERROR_WRONG_ACTION_TYPE = 2,
  ERROR_BAD_PARAMETER = 3,
  ACTION_TIME_OUT = 4,
  ERROR_PALLET_DOWN = 5,
  ERROR_PALLET_ROTATE = 6,
  ERROR_CHARGE = 7,
  ERROR_CHARGE_TIMEOUT = 8,
  ERROR_ACTION_NODE_TIMEOUT = 9,
  ERROR_PALLET_ZERO = 10,
  ERROR_PALLET_MOVE = 11,
  EXCEPTION_NO_PALLET = 12,
  ERROR_BREAK = 13,
};
static std::string Fault[] = {"AGV_NO_ERROR",
                              "ERROR_WRONG_AGV_TYPE",
                              "ERROR_WRONG_ACTION_TYPE",
                              "ERROR_BAD_PARAMETER",
                              "ERROR_PALLET_UP",
                              "ERROR_PALLET_DOWN",
                              "ERROR_PALLET_ROTATE",
                              "ERROR_CHARGE",
                              "ERROR_CHARGE_TIMEOUT",
                              "ERROR_ACTION_NODE_TIMEOUT",
                              "ERROR_PALLET_ZERO",
                              "ERROR_PALLET_MOVE",
                              "EXCEPTION_NO_PALLET"};
enum class Forklift_Action_Type : uint32_t {
  WAITING = 0,
  REST = 1,
  PALLET_FORK_UP = 2,    // 托盘车抬货  (operation_value 默认填0)
  PALLET_FORK_DOWN = 3,  // 托盘车放货  (operation_value 默认填0)
  HEAP_FORK_MOVE = 4,  // 堆高车叉腿移动  (operation_value 填 控制高度)
  CHARGE = 5,          // 自动充电 (operation_value 填0(关), 1(开))
  BEEP = 6,            // 喇叭  (operation_value 填0(关), 1(开))
  CURTIS_RESET = 7,  // 柯蒂斯复位继电器打开  (operation_value 填0(关), 1(开))
  BRAKE = 8,  // 电机报闸  (operation_value 填0(关), 1(开))
  LOW_POWER_MODE = 9,
  REACH_FORK_MOVE = 10,     // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_FORWARD = 11,  // 前移车叉腿向前(operation_value 默认填0)
  REACH_FORK_BACKWARD = 12,  // 前移车叉腿后移(operation_value 默认填0)
  HEAP_LIFT_LOAD = 13,       // 堆高车库位抬货
  HEAP_UN_LOAD = 14,         // 堆高车库位卸货

};

struct Pgv100 {
  double x_deviation;
  double y_deviation;
  double angle;
  uint32_t tag_number;
  uint8_t color;
  uint8_t direction;
  uint16_t warningcode;
};

struct ActionGoal {
  uint32_t action_type;
  double action_value;
  uint8_t three_color_led_type;
  uint8_t audio_control_type;
  uint8_t audio_control_level;
};
struct ForkliftPallet {
  uint8_t fork_up_down_state;
  uint8_t fork_pallet_state;
  int32_t height;
  int32_t lateral;              // 水平测移
  uint16_t hight_error_code;    // 高度传感器错误码
  uint16_t lateral_error_code;  // 水平传感器错误码
};

struct HeapPallet {
  int32_t height;
  uint16_t error_code;
};

struct ReachPallet {
  int32_t height;
  int32_t lateral;  // 水平测移
  uint16_t error_code;
};

// Pallet state
struct JackupPallet {
  uint8_t up_down_state;
  uint8_t roate_state;
};
struct Pallet {
  double w;
  double v;
  bool pallet_nomove_flag;
  double pallet_nomove_tar_angle;
  double up_relative_down;
};

struct Battery {
  uint8_t battery_type;
  uint8_t capacity;
  int16_t current;
  uint16_t voltage;
};

// sensor dataset
struct SensorData {
  Battery battery_moniter;
  ForkliftPallet forklift_pallet_state;
  JackupPallet jackup_Pallet_state;
  Pgv100 up_pgv;
  Pallet pallet;
};

struct ActionState {
  uint16_t percent;
  bool is_finish;
  uint16_t action_status;
  uint16_t action_fault;
  double move_omega;
};

struct Charge {
  int charge_estimate;  // 0:默认 1: 电流检测 2:电压检测 3:电流电压均检测
  int charge_current_upper;  // 充电电流上限值
  int charge_current_lower;  // 充电电流下限值
  int charge_voltage_upper;  // 充电电压上限值
  int charge_voltage_lower;  // 充电电压下限值
};

// TODO(@ssh) 预留堆高车算法
struct HeapAlgorithm {
  int pallet_err_tolerant;
  int dec_mode;
  double low_speed;
  float margin;         // 安全高度cm
  double deceleration;  // 减速-加速度m/s2
  double reg_a;         // regression equation slope 回归斜率
  double reg_b;         // regression coefficient 回归系数
};

// TODO(@cxh) 预留顶升车
struct JackUpOption {
  double Jpallet_UP_overout_t;
  double Jpallet_DOWN_overout_t;
  double Jpallet_ROTATE_overout_t;
  double pallet_height;

  double pallet_up_v;
  double pallet_down_v;
  double pallet_w;

  double pose_delay_threshold;  //
  int clear_alarm_delaytime;

  double pallet_angle_deviation;

  double pallet_max_w;
  double pallet_w_kp;
  double pallet_w_min_acc;
  double pallet_w_max_acc;

  double pallet_lifting_ratio;  //顶升减速比
  double pallet_rotate_ratio;   //旋转减速比

  double fPallet_nomove_kp;
  double fPallet_nomove_ki;
  double fPallet_nomove_kd;
};

struct AgvActionOption {
  uint16_t agv_type;             // agv类型
  bool enable_local_debug;       // 使能日志
  bool enable_timeout;           // 使能动作超时报警故障
  bool check_pallet;             // 托盘检测
  double action_timeout_value;   // 动作超时时间
  double control_period;         // 控制循环时间
  int32_t heap_liftload_height;  // 堆高车抬货高度
  int32_t heap_unload_height;    // 堆高车卸货高度
  int32_t heap_height_margin;    // 堆高车高度阈值

  Charge charge_option;
  // HeapAlgorithm heap_algorithm;
  JackUpOption jack_up_option;
  AgvActionOption() {
    std::memset(&charge_option, 0, sizeof(Charge));
    std::memset(&jack_up_option, 0, sizeof(JackUpOption));
  }
};

}  // namespace cotek_action
#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_TYPE_ENUM_H_
