/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_DATA_CENTER_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_DATA_CENTER_H_
#include <memory.h>
#include <ros/ros.h>
#include <ctime>
#include <string>
#include "cotek_action/type_enum.h"
#include "cotek_msgs/audio_control.h"
#include "cotek_msgs/audio_feedback.h"
#include "cotek_msgs/battery.h"
#include "cotek_msgs/bmmsk34_encoder_feedback.h"
#include "cotek_msgs/jack_up_io_state.h"
#include "cotek_msgs/led_control.h"
#include "cotek_msgs/motor_syntro_feedback.h"
#include "cotek_msgs/move_cmd.h"
#include "cotek_msgs/pallet_fork_io_state.h"
#include "cotek_msgs/pgv100_feedback.h"

namespace cotek_action {

class AgvData {
 public:
  static AgvData* get() {
    static AgvData instance;
    return &instance;
  }

  std::string TimeInfo() {
    time_t timep;
    time(&timep);
    char tmp[64];
    strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S", localtime(&timep));
    std::string s(tmp + '\0');
    return s;
  }

  void SetState(const uint16_t& percent, const bool& finsh_flag,
                const ActionFault& fault, const ActionStatus& status) {
    state_.percent = percent;
    state_.is_finish = finsh_flag;
    state_.action_fault = static_cast<uint16_t>(fault);
    state_.action_status = static_cast<uint16_t>(status);
  }

  void SetStateSucceed() {
    state_.percent = 100;
    state_.is_finish = true;
    state_.action_fault = static_cast<uint16_t>(ActionFault::AGV_NO_ERROR);
    state_.action_status = static_cast<uint16_t>(ActionStatus::FINISH);
  }

  void UpdataData(ActionGoal* goal) { get()->goal_ = *goal; }

  void SetOption(const AgvActionOption* option) { get()->option_ = *option; }

  void AddJackUpIO(
      const cotek_msgs::jack_up_io_state::ConstPtr& jack_up_io_state) {
    get()->agvdata_.jackup_Pallet_state.up_down_state =
        jack_up_io_state->up_down_state;
    get()->agvdata_.jackup_Pallet_state.roate_state =
        jack_up_io_state->roate_state;
  }

  void AddForkPalletState(
      const cotek_msgs::pallet_fork_io_state::ConstPtr& pallet_fork_io_state) {
    get()->agvdata_.forklift_pallet_state.fork_pallet_state =
        pallet_fork_io_state->fork_pallet_state;
    get()->agvdata_.forklift_pallet_state.fork_up_down_state =
        pallet_fork_io_state->fork_up_down_state;
  }

  void AddAgvBatteryData(const cotek_msgs::battery::ConstPtr& battery) {
    get()->agvdata_.battery_moniter.battery_type = battery->battery_type;
    get()->agvdata_.battery_moniter.capacity = battery->capacity;
    get()->agvdata_.battery_moniter.current = battery->current;
    get()->agvdata_.battery_moniter.voltage = battery->voltage;
  }

  void AddPgv100Up(
      const cotek_msgs::pgv100_feedback::ConstPtr& pgv100_feedback) {
    get()->agvdata_.up_pgv.tag_number = pgv100_feedback->tag_number;
  }

  void AddPalletV(const cotek_msgs::motor_syntro_feedback::ConstPtr& pallet_v) {
    get()->agvdata_.pallet.v =
        pallet_v->speed / get()->option_.jack_up_option.pallet_lifting_ratio;
  }

  void AddPalletW(const cotek_msgs::motor_syntro_feedback::ConstPtr& pallet_w) {
    get()->agvdata_.pallet.w =
        pallet_w->speed * 2.0f * 3.1415f / 60.0f /
        get()->option_.jack_up_option.pallet_rotate_ratio;
  }

  void AddHightBmmsk34Encode(
      const cotek_msgs::bmmsk34_encoder_feedback::ConstPtr& bmmsk34) {
    get()->agvdata_.forklift_pallet_state.height = bmmsk34->length;
    get()->agvdata_.forklift_pallet_state.hight_error_code = bmmsk34->error_code;
  }

  void AddLateralBmmsk34Encode(
      const cotek_msgs::bmmsk34_encoder_feedback::ConstPtr& bmmsk34) {
    get()->agvdata_.forklift_pallet_state.lateral = bmmsk34->length;
    get()->agvdata_.forklift_pallet_state.lateral_error_code = bmmsk34->error_code;
  }

  void AddLed(const cotek_msgs::led_control::ConstPtr& led) {
    get()->goal_.three_color_led_type = led->three_color_led_type;
  }

  void AddAudio(const cotek_msgs::audio_control::ConstPtr& audio) {
    get()->goal_.audio_control_type = audio->audio_control_type;
    get()->goal_.audio_control_level = audio->audio_control_level;
  }
  void AddMovecmd(const cotek_msgs::move_cmd::ConstPtr& cmd) {
    get()->state_.move_omega = cmd->cmd_omega;
  }
  void Reset() {
    memset(&get()->agvdata_, 0, sizeof(SensorData));
    memset(&get()->goal_, 0, sizeof(ActionGoal));
    get()->state_.percent = 0;
  }

  SensorData agvdata_;
  ActionGoal goal_;
  ActionState state_;
  AgvActionOption option_;

 private:
  // config initial value
  AgvData() {
    memset(&agvdata_, 0, sizeof(SensorData));
    memset(&goal_, 0, sizeof(ActionGoal));
  }
};

}  // namespace cotek_action
#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_DATA_CENTER_H_
