/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_INTERFACE_H_
#define SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_INTERFACE_H_
#include <ros/ros.h>
#include "cotek_action/data_center.h"
#include "cotek_action/type_enum.h"
#include <cotek_common/log_porting.h>
#include <cotek_common/cotek_topic_name.h>

namespace cotek_action {

class ActionInterface {
 public:
  virtual void UpdateData(AgvData* Get_info) = 0;

  virtual uint32_t FeedBack() = 0;

  virtual bool IsFinished() = 0;

  virtual void ExecuteAction(AgvData* Get_info) = 0;

  virtual void PublishActionMsg() = 0;
};

}  // namespace cotek_action

#endif  // SRC_COTEK_ACTION_INCLUDE_COTEK_ACTION_ACTION_INTERFACE_H_
