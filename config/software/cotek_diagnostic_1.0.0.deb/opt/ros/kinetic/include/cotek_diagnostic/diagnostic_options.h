/**
 * Copyright (c) 2019 Cotek Inc. All rights reserved.
 */
#ifndef COTEK_DIAGNOSTIC_INCLUDE_COTEK_DIAGNOSTIC_DIAGNOSTIC_OPTIONS_H_
#define COTEK_DIAGNOSTIC_INCLUDE_COTEK_DIAGNOSTIC_DIAGNOSTIC_OPTIONS_H_
#include <string>

namespace cotek_diagnostic {
struct DiagnosticOption {
  bool enable_sensor_boot;
  double control_frequency;
  double fault_report_delay;
  std::string sensor_list_filename;
};

}  // namespace cotek_diagnostic

#endif  // COTEK_DIAGNOSTIC_INCLUDE_COTEK_DIAGNOSTIC_DIAGNOSTIC_OPTIONS_H_
