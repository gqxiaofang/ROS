/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_DIAGNOSTIC_INCLUDE_COTEK_DIAGNOSTIC_DEVICE_INTERFACE_H_
#define COTEK_DIAGNOSTIC_INCLUDE_COTEK_DIAGNOSTIC_DEVICE_INTERFACE_H_

#include <ros/ros.h>
#include <string>

namespace cotek_diagnostic {

struct FaultMsg {
  uint16_t level;
  uint16_t msg;
  // FaultMsg() : level(0), msg(0) {}
};

enum { OK = 0, WARN = 1, ERROR = 2, FATAL = 3 };

constexpr double kTimeOut = 3.;

class DeviceInterface {
 public:
  explicit DeviceInterface(const std::string& device_name)
      : device_name_(device_name) {
    /* fill in constructor */
  }

  ~DeviceInterface() {}
  virtual void Init() { /* fill in */
  }

  inline virtual void SetFaultMsg(cotek_diagnostic::FaultMsg msg) {
    fault_msg_ = msg;
  }

  inline virtual cotek_diagnostic::FaultMsg GetFaultMsg() { return fault_msg_; }
  // 通用处理函数
  template <typename T>
  void HandleNodeData(const T& data) {
    FaultMsg fault_temp;
    if (last_time_ == ros::Time(0.)) {
      ros::NodeHandle private_nh("~");
      timer_ = private_nh.createTimer(ros::Duration(0.5),
                                      &DeviceInterface::CheckTimeOut, this);
    } else {
      // OK: 0 ERROR: 1~19  WARN: 20~...
      if (data->status > 0 && data->status < 20)
        fault_temp.level = static_cast<uint16_t>(ERROR);
      else if ((data->status) >= 20)
        fault_temp.level = static_cast<uint16_t>(WARN);
      else
        fault_temp.level = static_cast<uint16_t>(OK);
      fault_temp.msg = data->status;
      SetFaultMsg(fault_temp);
    }
    last_time_ = ros::Time::now();
  }
  // 通用处理函数
  template <typename T>
  void HandleSensorData(const T& data) {
    FaultMsg fault_temp;
    if (data->error_code)
      fault_temp.level = static_cast<uint16_t>(ERROR);
    else
      fault_temp.level = static_cast<uint16_t>(OK);
    fault_temp.msg = data->error_code;
    SetFaultMsg(fault_temp);
  }

  // 超时报警故障码为9
  void CheckTimeOut(const ros::TimerEvent& e) {
    if (ros::Time::now().toSec() - last_time_.toSec() > kTimeOut) {
      FaultMsg fault_temp;
      fault_temp.level = static_cast<uint16_t>(ERROR);
      fault_temp.msg = 9;
      SetFaultMsg(fault_temp);
    }
  }

 private:
  ros::Time last_time_;
  ros::Timer timer_;
  std::string device_name_;
  FaultMsg fault_msg_;
};

}  // namespace cotek_diagnostic
#endif  // COTEK_DIAGNOSTIC_INCLUDE_COTEK_DIAGNOSTIC_DEVICE_INTERFACE_H_
