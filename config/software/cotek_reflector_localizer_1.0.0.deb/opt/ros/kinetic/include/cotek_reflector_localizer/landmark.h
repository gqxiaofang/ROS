/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_LANDMARK_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_LANDMARK_H_
#include <algorithm>
#include <utility>
#include <vector>
#include "cotek_reflector_localizer/geometry.h"
#include "cotek_reflector_localizer/reflector_map.h"

namespace reflector_localizer {

class Landmark {
 public:
  explicit Landmark(double alpha, double rho) : alpha_(alpha), rho_(rho) {}
  explicit Landmark(const Point &coord) { coordinate_ = coord; }
  inline void SetCoordinate(Point coord) { coordinate_ = coord; }
  inline const double Alpha() const { return alpha_; }
  inline const double Rho() const { return rho_; }
  inline Point Coordinate() const { return coordinate_; }
  inline double X() const { return coordinate_[0]; }
  inline double Y() const { return coordinate_[1]; }
  inline void SetAlpha(double alpha) { alpha_ = alpha; }
  inline void SetRho(double rho) { rho_ = rho; }

 private:
  double alpha_;
  double rho_;
  Point coordinate_;
};

class LandmarkList : public std::vector<Landmark> {
 public:
  void Merge() {
    if (this->empty() || 1 == this->size()) return;

    std::sort(
        this->begin(), this->end(),
        [](const Landmark &a, const Landmark &b) { return a.Rho() < b.Rho(); });

    for (auto &lm : *this) {
      double x = lm.Rho() * std::cos(lm.Alpha());
      double y = lm.Rho() * std::sin(lm.Alpha());
      lm.SetCoordinate(Point(x, y));
    }

    LandmarkList tmp_list;
    tmp_list.push_back(this->front());
    for (uint32_t i = 1; i < this->size(); i++) {
      double distance = std::hypot(this->at(i).X() - this->at(i - 1).X(),
                                   this->at(i).Y() - this->at(i - 1).Y());
      if (distance > 0.2) {
        tmp_list.push_back(this->at(i));
      }
    }
    *this = std::move(tmp_list);
  }

  PointSet ToPointSet() {
    PointSet landmarks;
    for (auto &landmark : *this) {
      double x = landmark.Rho() * std::cos(landmark.Alpha());
      double y = landmark.Rho() * std::sin(landmark.Alpha());
      landmarks.push_back(Point(x, y));
    }
    return landmarks;
  }
};

}  // namespace reflector_localizer

#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_LANDMARK_H_
