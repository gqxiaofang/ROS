/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_STATIC_GEOMETRY_MATCHER_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_STATIC_GEOMETRY_MATCHER_H_

#include <eigen3/Eigen/Dense>
#include <vector>
#include "cotek_reflector_localizer/geometry.h"

namespace reflector_localizer {
using PointSetList = std::vector<PointSet>;
using PoseList = std::vector<Pose>;
class StaticGeometryMatcher {
 public:
  // delete default constructor
  StaticGeometryMatcher() = delete;

  /**
   * \brief static geometry matcher constructor
   * \param threshold point match threshold
   */
  explicit StaticGeometryMatcher(double threshold) : threshold_(threshold) {}

  /**
   * \brief match by two point sets
   * \param m point set 1
   * \param n point set 2
   * \return potential pose list
   */
  PoseList MatchWithoutOutliers(PointSet &&m, PointSet &&n);

 private:
  /**
   * \brief [ match with no outliers ]
   */
  bool Match(PointSet &&m, PointSet &&n);
  /**
   * @brief [ get the pose ]
   */
  Pose CalcPose(const PointSet &f);
  /**
   * @brief  [choose a point from n, and update correspondences]
   */
  bool UpdateCandidates(const PointSet &n);
  /**
   * \brief  [correspondence are stored in z and f]
   */
  PointSet z_;
  PointSetList f_;
  double threshold_;
};
}  // namespace reflector_localizer
#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_STATIC_GEOMETRY_MATCHER_H_
