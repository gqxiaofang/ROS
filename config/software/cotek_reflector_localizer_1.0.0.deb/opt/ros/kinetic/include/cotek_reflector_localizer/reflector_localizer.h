/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_REFLECTOR_LOCALIZER_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_REFLECTOR_LOCALIZER_H_
#include <geometry_msgs/TransformStamped.h>
#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <cmath>
#include <deque>
#include <memory>
#include <string>
#include <vector>
#include "cotek_common/kalman/ExtendedKalmanFilter.hpp"
#include "cotek_msgs/switch_map.h"
#include "cotek_reflector_localizer/geometry.h"
#include "cotek_reflector_localizer/landmark.h"
#include "cotek_reflector_localizer/localizer_options.h"
#include "cotek_reflector_localizer/position_measurement_model.h"
#include "cotek_reflector_localizer/reflector_map.h"
#include "cotek_reflector_localizer/scan_data.h"
#include "cotek_reflector_localizer/static_geometry_matcher.h"
#include "cotek_reflector_localizer/strong_point_filter.h"
#include "cotek_reflector_localizer/system_model.h"

namespace reflector_localizer {
using EkfPose = State<double>;
using EkfTransform = State<double>;
using LaserInstallOffset = State<double>;

enum class LaserType : int { PPF = 0, SICK = 1, UAM = 2 };
enum class LaserBase : int { SHORT = 0, MIDDLE = 1, LONG = 2 };
enum class ErrorType : uint16_t {
  NONE = 0,
  // reserve
  LASER_MESSAGE_EMPTY = 5,
  STATIC_LOCALIZER_ERROR = 6,
  DYNAMIC_MATCH_ERROR = 7
};

/**
 * \class Localizer
 * \brief a localizer based on reflectors
 */
class ReflectorLocalizer final {
  enum class LocalizeMode { STATIC, DYNAMIC };

 public:
  /**
   * \brief delete default constructor, localizer cannot work properly without
   * options
   */
  ReflectorLocalizer() = delete;

  /**
   * \brief construct object with options
   * \param option all localizer related parameters
   */
  explicit ReflectorLocalizer(const LocalizerOption &option,
                              const ReflectorMap &reflector_map);

  /**
   * \brief option getter
   * \return LocalizerOption
   */
  inline LocalizerOption Option() const { return option_; }

  /**
   * \brief wheelbase could be dynamically changed according to different bases
   * \param wheelbase distance from front steer to center of back-end wheels
   */
  inline void SetWheelbase(double wheelbase) { wheelbase_ = wheelbase; }

  /**
   * \brief wheelbase getter
   * \return wheelbase
   */
  inline double Wheelbase() const { return wheelbase_; }

  /**
   * \brief LaserScan message callback
   * \details scan message fire a calculation cycle
   */
  void AddScanData(const ScanData &scan_data);

  void AddVelocityData(double driver_velociy, double steering_angle);

  void AddOdometryData();

  void UpdateLaserBaseTransform(uint32_t state);
  void UpdateLaserBaseTransform(double x, double y, double yaw);

  inline void SetError(const ErrorType &error) { error_ = error; }
  inline ErrorType Error() const { return error_; }
  inline void ClearError() { error_ = ErrorType::NONE; }

  Pose GetPose(const Pose &from_pose, double duration);

  bool InitReflectorMap(int current_map_id, int current_section_id);

 private:
  /**
   * \brief  decompose strong points into several parts, each part is a possible
   * landmark
   * \param
   */
  LandmarkList FilterLandmarks(StrongPointQueue &&sp_queue);

  /**
   * \brief  dynamic match
   * \param
   */
  LandmarkList DynamicMatching(const EkfPose &predictPose,
                               const LandmarkList &landmarks);

  /**
   * \brief dynamic location using sequential extend kalman filter
   * \param predictPose predicted pose
   * \return (updated-pose, error)
   */
  Pose SequentialEkfUpdate(EkfPose predictPose, const LandmarkList &landmarks);

  /**
   * \brief: to update mode.
   * \param mode - change currentmode to mode
   */
  inline void SetMode(LocalizeMode mode) { mode_ = mode; }

  /**
   * \brief: conversion laer pose to robot pose
   */
  Pose LaserPoseToRobotPose(const Pose &laser_pose) const;

  // 切换分区地图接口
  bool SwitchSectionAndPose(cotek_msgs::switch_map::Request &req,
                            cotek_msgs::switch_map::Response &res);

  double wheelbase_;
  std::deque<ScanData> scan_data_queue_;

  // Extended Kalman Filter
  Kalman::ExtendedKalmanFilter<EkfPose> ekf_;
  SystemModel<double> system_model_;
  PositionMeasurementModel<double> position_measurement_model_;
  LaserInstallOffset laser_install_offset_;
  Control<double> control_;
  LocalizerOption option_;

  LocalizeMode mode_;
  ReflectorMap reflector_map_;
  std::shared_ptr<StrongPointFilter> strong_point_filter_ptr_;
  ErrorType error_;
  // TODO(@wangjy)
  ros::ServiceServer swich_section_service_;
};
}  // namespace reflector_localizer
#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_REFLECTOR_LOCALIZER_H_
