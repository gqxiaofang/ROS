/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_POSITION_MEASUREMENT_MODEL_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_POSITION_MEASUREMENT_MODEL_H_

#include <cmath>
#include "cotek_common/kalman/LinearizedMeasurementModel.hpp"
#include "cotek_reflector_localizer/system_model.h"

namespace reflector_localizer {

/**
 * @brief Measurement vector measuring the robot position
 *
 * @param T Numeric scalar type
 */
template <typename T>
class PositionMeasurement : public Kalman::Vector<T, 2> {
 public:
  KALMAN_VECTOR(PositionMeasurement, T, 2)

  // landmark coordinate x
  static constexpr size_t kX = 0;
  // landmark coordinate y
  static constexpr size_t kY = 1;

  T X() const { return (*this)[kX]; }
  T Y() const { return (*this)[kY]; }

  T& X() { return (*this)[kX]; }
  T& Y() { return (*this)[kY]; }
};

template <typename T>
class LandmarkMeasurement : public Kalman::Vector<T, 4> {
 public:
  KALMAN_VECTOR(LandmarkMeasurement, T, 4);
  static constexpr size_t kX = 0;
  static constexpr size_t kY = 1;
  static constexpr size_t kAlpha = 2;
  static constexpr size_t kRho = 3;

  T X() const { return (*this)[kX]; }
  T Y() const { return (*this)[kY]; }
  T Alpha() const { return (*this)[kAlpha]; }
  T Rho() const { return (*this)[kRho]; }
};

/**
 * @brief Measurement model for measuring the position of the robot
 *        using two beacon-landmarks
 *
 * This is the measurement model for measuring the position of the robot.
 * The measurement is given by two landmarks in the space, whose positions are
 * known. The robot can measure the direct distance to both the landmarks, for
 * instance through visual localization techniques.
 *
 * @param T Numeric scalar type
 * @param CovarianceBase Class template to determine the covariance
 * representation (as covariance matrix (StandardBase) or as lower-triangular
 *                       coveriace square root (SquareRootBase))
 */
template <typename T,
          template <class> class CovarianceBase = Kalman::StandardBase>
class PositionMeasurementModel
    : public Kalman::LinearizedMeasurementModel<
          State<T>, PositionMeasurement<T>, CovarianceBase> {
 public:
  //! State type shortcut definition
  typedef State<T> S;

  //! Measurement type shortcut definition
  typedef PositionMeasurement<T> M;

  PositionMeasurementModel() {
    // initial landmark
    landmark_ << 0., 0., 0., 0.;
    // Setup noise jacobian. As this one is static, we can define it once
    // and do not need to update it dynamically
    this->V.setIdentity();
  }

  /**
   * @brief Constructor
   *
   * @param trMatrix laser sensor install data
   */
  explicit PositionMeasurementModel(Kalman::Vector<T, 3> transform)
      : transform_(transform) {
    // Setup noise jacobian. As this one is static, we can define it once
    // and do not need to update it dynamically
    landmark_ << 0., 0., 0., 0.;
    this->V.setIdentity();
  }

  inline void SetLandmark(const LandmarkMeasurement<T>& landmark) {
    landmark_ = landmark;
  }

  void SetNoise(T m_dev_x, T m_dev_y) {
    this->V(0, 0) = m_dev_x;
    this->V(1, 1) = m_dev_y;
  }

  void SetTransform(const State<T>& transform) { transform_ = transform; }

  /**
   * @brief Definition of (possibly non-linear) measurement function
   *
   * This function maps the system state to the measurement that is expected
   * to be received from the sensor assuming the system is currently in the
   * estimated state.
   *
   * @param [in] x The system state in current time-step
   * @returns The (predicted) sensor measurement for the system state
   */
  M h(const S& x) const {
    Kalman::Vector<T, 2> position;  // = x.template head<2>();
    position << x.x(), x.y();

    Kalman::Vector<T, 2> transPosition;  // = transform_.template head<2>();
    transPosition << transform_[0], transform_[1];

    Kalman::Vector<T, 2> lmPolar;
    Eigen::Rotation2D<T> rot1(x.theta());
    Eigen::Rotation2D<T> rot2(x.theta() + transform_[2]);

    lmPolar << landmark_.Rho() * cos(landmark_.Alpha()),
        landmark_.Rho() * sin(landmark_.Alpha());
    M measurement = position + rot1.toRotationMatrix() * transPosition +
                    rot2.toRotationMatrix() * lmPolar;

    return measurement;
  }

 protected:
  //! Position of landmark 1 given as (x,y)-measurement
  LandmarkMeasurement<T> landmark_;
  //! transform_ given as (lx, ly, ltheta)
  Kalman::Vector<T, 3> transform_;

 protected:
  /**
   * @brief Update jacobian matrices for the system state transition function
   * using current state
   *
   * This will re-compute the (state-dependent) elements of the jacobian
   * matrices to linearize the non-linear measurement function \f$h(x)\f$ around
   * the current state \f$x\f$.
   *
   * @note This is only needed when implementing a LinearizedSystemModel,
   *       for usage with an ExtendedKalmanFilter or
   * SquareRootExtendedKalmanFilter. When using a fully non-linear filter such
   * as the UnscentedKalmanFilter or its square-root form then this is not
   * needed.
   *
   * @param x The current system state around which to linearize
   * @param u The current system control input
   */
  void updateJacobians(const S& x) {
    // H = dh/dx (Jacobian of measurement function w.r.t. the state)
    this->H.setZero();

    this->H(M::kX, S::X) = 1;
    this->H(M::kX, S::Y) = 0;
    this->H(M::kX, S::THETA) = -transform_[0] * sin(x.theta()) -
                               transform_[1] * cos(x.theta()) -
                               landmark_.Rho() * cos(landmark_.Alpha()) *
                                   sin(x.theta() + transform_[2]) -
                               landmark_.Rho() * sin(landmark_.Alpha()) *
                                   cos(x.theta() + transform_[2]);

    this->H(M::kY, S::X) = 0;
    this->H(M::kY, S::Y) = 1;
    this->H(M::kY, S::THETA) = transform_[0] * cos(x.theta()) -
                               transform_[1] * sin(x.theta()) +
                               landmark_.Rho() * cos(landmark_.Alpha()) *
                                   cos(x.theta() + transform_[2]) -
                               landmark_.Rho() * sin(landmark_.Alpha()) *
                                   sin(x.theta() + transform_[2]);
  }
};
}  // namespace reflector_localizer
#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_POSITION_MEASUREMENT_MODEL_H_
