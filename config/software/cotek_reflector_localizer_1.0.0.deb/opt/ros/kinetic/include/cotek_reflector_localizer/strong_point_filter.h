/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_STRONG_POINT_FILTER_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_STRONG_POINT_FILTER_H_
#include <vector>
#include "cotek_reflector_localizer/scan_data.h"

namespace reflector_localizer {

class StrongPointFilter {
 public:
  virtual StrongPointQueue Filter(
      const ScanData &data,
      std::function<bool(const RawData &)> filter_method) {
    StrongPointQueue queue;
    std::copy_if(data.begin(), data.end(), std::back_inserter(queue),
                 filter_method);
    return queue;
  }

  virtual StrongPointQueue GetStrongPoints(const ScanData &data) = 0;
};

namespace uam {
constexpr double kUamIntensityThreshold = 10000.;
class StrongPointFilter final
    : public ::reflector_localizer::StrongPointFilter {
 public:
  StrongPointFilter() = delete;
  explicit StrongPointFilter(double range_max)
      : range_max_(range_max), intensity_threshold_(kUamIntensityThreshold) {}

  StrongPointQueue GetStrongPoints(const ScanData &data) override {
    return Filter(data, [&](const RawData &data) {
      return data.range < range_max_ &&
             data.intensity > intensity_threshold_ / std::sqrt(data.range);
    });
  }

 private:
  double range_max_;
  double intensity_threshold_;
};
}  // namespace uam

namespace sick {
constexpr double kSickIntensityThreshold = 2400.;
class StrongPointFilter final
    : public ::reflector_localizer::StrongPointFilter {
 public:
  StrongPointFilter() = delete;
  explicit StrongPointFilter(double range_max)
      : range_max_(range_max), intensity_threshold_(kSickIntensityThreshold) {}

  StrongPointQueue GetStrongPoints(const ScanData &data) override {
    return Filter(data, [&](const RawData &data) {
      return data.range < range_max_ &&
             data.intensity > intensity_threshold_ / std::sqrt(data.range);
    });
  }

 private:
  double range_max_;
  double intensity_threshold_;
};
}  // namespace sick

namespace ppf {
constexpr double kPpfIntensityThreshold = 2200.;
class StrongPointFilter final
    : public ::reflector_localizer::StrongPointFilter {
 public:
  StrongPointFilter() = delete;
  explicit StrongPointFilter(double range_max)
      : range_max_(range_max), intensity_threshold_(kPpfIntensityThreshold) {}

  StrongPointQueue GetStrongPoints(const ScanData &data) override {
    return Filter(data, [&](const RawData &data) {
      return data.range < range_max_ &&
             data.intensity > intensity_threshold_ / std::sqrt(data.range);
    });
  }

 private:
  double range_max_;
  double intensity_threshold_;
};
}  // namespace ppf
}  // namespace reflector_localizer
#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_STRONG_POINT_FILTER_H_
