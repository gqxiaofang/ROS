/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_LOCALIZER_OPTIONS_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_LOCALIZER_OPTIONS_H_
#include <string>

namespace reflector_localizer {

struct ServerOption {
  std::string ip;
  int port;
  std::string local_package;
  std::string local_filename;
};

struct LaserOption {
  int count;
  int type;
  std::string vendor;
  double angle_min;
  double angle_max;
  double range_min;
  double range_max;
};

struct ReflectorOption {
  double radius;
  double geometry_match_threshold;
  double continous_range_threshold;
  double dynamic_match_threshold;
};

struct EkfOption {
  double process_noise_x;
  double procsss_noise_y;
  double process_noise_theta;
  double measurement_noise_x;
  double measurement_noise_y;
};

struct LaserInstallationOption {
  double offset_x;
  double offset_y;
  double offset_yaw;
};

struct ReflectorMapOption {
  int current_map_id;
  int current_section_id;
  std::string reflector_map_api;
  std::string reflector_map_filename;
};

struct ModelOption {
  double wheelbase;
  double wheelbase_min;
  double wheelbase_max;
};

struct LocalizerOption {
  bool enable_local_debug;
  bool enable_calibration;
  ServerOption server;
  LaserOption laser;
  ReflectorOption reflector;
  ReflectorMapOption reflector_map;
  EkfOption ekf;
  LaserInstallationOption laser_install;
  ModelOption model;
};

}  // namespace reflector_localizer

#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_LOCALIZER_OPTIONS_H_
