/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_REFLECTOR_MAP_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_REFLECTOR_MAP_H_
#include <map>
#include <string>
#include <vector>
#include "cotek_common/json11.h"
#include "cotek_reflector_localizer/geometry.h"

namespace reflector_localizer {
class Reflector {
 public:
  Reflector() : x_(0.), y_(0.), count_(1), accumulateX_(0.), accumulateY_(0.) {}
  Reflector(double x, double y)
      : x_(x), y_(y), count_(1), accumulateX_(x), accumulateY_(y) {}

  void Update(double x, double y) {
    if (std::hypot(x - x_, y - y_) > 0.1) {
      return;
    }
    count_++;
    accumulateX_ += x;
    accumulateY_ += y;
    x_ = accumulateX_ / count_;
    y_ = accumulateY_ / count_;
  }

  inline double X() { return x_; }
  inline double Y() { return y_; }
  inline Point ToPoint() { return Point(x_, y_); }
  inline uint32_t Count() { return count_; }

 private:
  double x_;
  double y_;
  uint32_t count_;
  double accumulateX_;
  double accumulateY_;
};

typedef std::vector<Reflector> Section;

/**
 * ReflectorMap: to save map infomation from a file.
 */
class ReflectorMap {
 public:
  ReflectorMap() : current_map_idx_(0), current_section_idx_(0) {}
  /**
   * \brief update current section with current section_id
   * \return true update succeed; false if some error occurs
   */
  bool UpdateMap(int map_id, int section_id);
  bool UpdateSection(int id);

  inline int CurrentSectionId() { return current_section_idx_; }

  /**
   * \brief get reflectors of current section
   * \return current section's reflectors
   */
  inline Section Get() {
    if (sections_.count(current_section_idx_) > 0) {
      return sections_[current_section_idx_];
    }
    return Section();
  }

  inline void Add(double x, double y) {
    if (sections_.count(current_section_idx_) > 0) {
      sections_[current_section_idx_].emplace_back(x, y);
    }
  }

  inline void Add(int section_id, const Reflector &reflector) {
    if (sections_.count(section_id) > 0) {
      sections_[section_id].push_back(reflector);
    } else {
      Section sec{reflector};
      sections_[section_id] = sec;
    }
  }

  inline void Add(int section_id, double x, double y) {
    if (sections_.count(section_id) > 0) {
      sections_[section_id].emplace_back(x, y);
    } else {
      Section sec{Reflector(x, y)};
      sections_[section_id] = sec;
    }
  }

  PointSet ToPointSet() {
    PointSet ps;
    if (sections_.count(current_section_idx_) > 0) {
      ps.reserve(sections_[current_section_idx_].size());
      for (auto &reflector : sections_[current_section_idx_]) {
        ps.push_back(reflector.ToPoint());
      }
    }
    return ps;
  }

  inline void Add(int map_id, int section_id, double x, double y) {
    if (maps_.count(map_id) > 0 && maps_[map_id].count(section_id) > 0) {
      maps_[map_id][section_id].emplace_back(x, y);
    } else {
      Section sec{Reflector(x, y)};
      maps_[map_id][section_id] = sec;
    }
  }

#if 0
  inline Section Get() {
    if (maps_[current_map_idx_].count(current_section_idx_) > 0) {
      return maps_[current_map_idx_][current_section_idx_];
    }
    return Section();
  }

  inline void Add(double x, double y) {
    if (maps_[current_map_idx_].count(current_section_idx_) > 0) {
      maps_[current_map_idx_][current_section_idx_].emplace_back(x, y);
    }
  }

  inline void Add(int section_id, const Reflector &reflector) {
    if (maps_[current_map_idx_].count(section_id) > 0) {
      maps_[current_map_idx_][section_id].push_back(reflector);
    } else {
      Section sec{reflector};
      maps_[current_map_idx_][section_id] = sec;
    }
  }

  inline void Add(int map_id, int section_id, double x, double y) {
    if (maps_.count(map_id) > 0 && maps_[map_id].count(section_id) > 0) {
      maps_[map_id][section_id].emplace_back(x, y);
    } else {
      Section sec{Reflector(x, y)};
      maps_[map_id][section_id] = sec;
    }
  }

  PointSet ToPointSet() {
    PointSet ps;
    if (maps_[current_map_idx_].count(current_section_idx_) > 0) {
      ps.reserve(maps_[current_map_idx_][current_section_idx_].size());
      for (auto &reflector : maps_[current_map_idx_][current_section_idx_]) {
        ps.push_back(reflector.ToPoint());
      }
    }
    return ps;
  }
#endif

 private:
  std::map<int, Section> sections_;
  std::map<int, std::map<int, Section>> maps_;
  int current_map_idx_;
  int current_section_idx_;
};  // namespace reflector_localizer

class ReflectorMapService {
 public:
  static ReflectorMap ParseFromJsonString(const std::string &json_str);
  static ReflectorMap ParseFromJsonString2(const std::string &json_str);
};
}  // namespace reflector_localizer
#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_REFLECTOR_MAP_H_
