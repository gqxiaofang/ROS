/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_SCAN_DATA_H_
#define COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_SCAN_DATA_H_
#include <deque>
#include <string>
#include <vector>

namespace reflector_localizer {

typedef struct RawData_ {
  RawData_() : angle(0.0), range(0.0), intensity(0.0) {}
  RawData_(double a, double r, double i) : angle(a), range(r), intensity(i) {}

  double angle;
  double range;
  double intensity;
} RawData, StrongPoint;

class ScanData : public std::vector<RawData> {
 public:
  inline void SetFrame(const std::string &frame) { frame_ = frame; }
  inline std::string Frame() const { return frame_; }

 private:
  std::string frame_;
};

typedef std::deque<StrongPoint> StrongPointQueue;
}  // namespace reflector_localizer
#endif  // COTEK_REFLECTOR_LOCALIZER_INCLUDE_COTEK_REFLECTOR_LOCALIZER_SCAN_DATA_H_
