/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DATA_HOLDER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DATA_HOLDER_H_
#include <cotek_common/cotek_enum_type.h>

#include <cstring>

namespace cotek_embedded {
using AtomicActionType = action::AtomicActionType;

class PalletForkliftData {
 public:
  static PalletForkliftData* get() {
    static PalletForkliftData instance;
    return &instance;
  }

  struct CmdData {
    float driver_velocity;
    float steering_angle;
    uint8_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    uint8_t corning_led_type;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
    bool manual_mode;
    // TODO(@ssh) 收到来自navigation的move_cmd 有效性为true
    bool move_cmd_valid;
  };

  struct FeedBackData {
    float driver_velocity;
    float steering_angle;
    uint8_t battery_capacity;
    int16_t battery_current;   // 单位：0.1 A
    uint16_t battery_voltage;  // 单位：0.1 V
    uint8_t fork_up_down_state;
    uint8_t fork_pallet_state;
    uint8_t avoid_io_state;
    bool manual_mode;
    bool charge_do_state;       // 继电器do开闭状态
    int8_t power_supply_state;  // 电源状态
  };

  CmdData cmd_data_;
  FeedBackData feedback_data_;

 private:
  PalletForkliftData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
    feedback_data_.power_supply_state = 2;
  }
};

class HeapForkliftData {
 public:
  static HeapForkliftData* get() {
    static HeapForkliftData instance;
    return &instance;
  }

  struct CmdData {
    float driver_velocity;
    float steering_angle;
    uint8_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
    bool move_cmd_valid;
  };

  struct FeedBackData {
    float driver_velocity;
    float steering_angle;
    uint8_t battery;
    float height;
    uint8_t fork_pallet_state;
    uint8_t avoid_io_state;
    bool manual_mode;
    bool charge_do_state;       //继电器do开闭状态　
    int8_t power_supply_state;  // 电源状态
  };

  CmdData cmd_data_;
  FeedBackData feedback_data_;

 private:
  HeapForkliftData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
  }
};

// 二维码顶升
class JackUpData {
 public:
  static JackUpData* get() {
    static JackUpData instance;
    return &instance;
  }
  struct CmdData {
    float velocity;
    float omega;
    uint32_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    bool left_motor_enable;
    bool right_motor_enable;
    bool lift_motor_enable;
    bool rotate_motor_enable;
    float lift_v;
    float rotate_w;
    int32_t three_color_led_type;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
    bool move_cmd_valid;
  };

  struct FeedBackData {
    float velocity;
    float omega;
    double lift_velocity;
    double lift_height;
    bool height_init;
    int32_t lift_rpm;
    uint8_t battery_capacity;
    int16_t battery_current;   // 单位：0.1 A
    uint16_t battery_voltage;  // 单位：0.1 V
    uint8_t up_down_state;
    uint8_t roate_state;
    uint8_t avoid_io_state;
    uint32_t pallet_tag_id;
    bool manual_mode;
    bool charge_do_state;  // 继电器do开闭状态
  };

  CmdData cmd_data_;
  CmdData remote_cmd_data_;
  FeedBackData feedback_data_;

 private:
  JackUpData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
  }
};

// 前移车
class ReachForkliftData {
 public:
  static ReachForkliftData* get() {
    static ReachForkliftData instance;
    return &instance;
  }

  struct CmdData {
    float driver_velocity;
    float steering_angle;
    uint8_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
  };

  struct FeedBackData {
    float driver_velocity;
    float steering_angle;
    uint8_t battery_capacity;
    int16_t battery_current;   // 单位：0.1 A
    uint16_t battery_voltage;  // 单位：0.1 V
    float height;              // 叉腿高度值
    float lateral;             // 叉腿前移量
    uint8_t fork_pallet_state;
    uint8_t avoid_io_state;
    bool manual_mode;
    bool charge_do_state;  //继电器do开闭状态　
  };

  CmdData cmd_data_;
  FeedBackData feedback_data_;

 private:
  ReachForkliftData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
  }
};

// 牵引车
class TracrorCarData {
 public:
  static TracrorCarData* get() {
    static TracrorCarData instance;
    return &instance;
  }

  struct CmdData {
    float driver_velocity;
    float steering_angle;
    uint8_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
    bool manual_mode;
  };

  struct FeedBackData {
    float driver_velocity;
    float steering_angle;
    uint8_t battery_capacity;
    int16_t battery_current;   // 单位：0.1 A
    uint16_t battery_voltage;  // 单位：0.1 V
    uint8_t avoid_io_state;
    bool manual_mode;
    bool charge_do_state;  // 继电器do开闭状态　
  };

  CmdData cmd_data_;
  FeedBackData feedback_data_;

 private:
  TracrorCarData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
  }
};

// 磁条顶升
class MagneticJackUpData {
 public:
  static MagneticJackUpData* get() {
    static MagneticJackUpData instance;
    return &instance;
  }

  struct CmdData {
    float velocity;
    float omega;
    uint32_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    float lift_v;
    float rotate_w;
    int32_t three_color_led_type;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
  };

  struct FeedBackData {
    float velocity;
    float omega;
    double lift_velocity;
    double lift_height;
    bool height_init;
    int32_t lift_rpm;
    uint8_t battery_capacity;
    int16_t battery_current;   // 单位：0.1 A
    uint16_t battery_voltage;  // 单位：0.1 V
    uint8_t up_down_state;
    uint8_t avoid_io_state;
    uint32_t pallet_tag_id;
    bool forward_mag_found_lines;
    float forward_mag_line_offset;
    bool backward_mag_found_lines;
    float backward_mag_line_offset;
    bool manual_mode;
    bool charge_do_state;  // 继电器do开闭状态
  };

  CmdData cmd_data_;
  CmdData remote_cmd_data_;
  FeedBackData feedback_data_;

 private:
  MagneticJackUpData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&remote_cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
  }
};

//欣美夹抱
class XinMeiForkliftData {
 public:
  static XinMeiForkliftData* get() {
    static XinMeiForkliftData instance;
    return &instance;
  }

  struct CmdData {
    float driver_velocity;
    float steering_angle;
    uint8_t audio_control_type;
    uint8_t audio_control_level;
    AtomicActionType atomic_action_type;
    float atomic_action_value;
    float clamp_left_motor_value;
    float clamp_right_motor_value;
    uint8_t corning_led_type;
    int32_t avoid_map;
    int32_t ultrasonic_obstacle;  // 0:关闭超声波避障  1:打开超声波避障
    bool manual_mode;
    // TODO(@ssh) 收到来自navigation的move_cmd 有效性为true
    bool move_cmd_valid;
  };

  struct FeedBackData {
    float driver_velocity;
    float steering_angle;
    uint8_t battery_capacity;
    int16_t battery_current;   // 单位：0.1 A
    uint16_t battery_voltage;  // 单位：0.1 V
    uint8_t fork_up_down_state;
    uint8_t fork_pallet_state;
    uint8_t avoid_io_state;
    bool manual_mode;
    bool charge_do_state;       // 继电器do开闭状态
    int8_t power_supply_state;  // 电源状态

    uint8_t clamp_left_state;   //夹抱机构左侧信号
    uint8_t clamp_right_state;  //夹抱机构右侧信号
    uint8_t clamp_limit_left_state;   //夹抱机构左侧位限
    uint8_t clamp_limit_right_state;  //夹抱机构右侧位限
    uint8_t clamp_detect_state;       //货架检测
  };

  CmdData cmd_data_;
  FeedBackData feedback_data_;

 private:
  XinMeiForkliftData() {
    std::memset(&cmd_data_, 0, sizeof(CmdData));
    std::memset(&feedback_data_, 0, sizeof(FeedBackData));
    feedback_data_.power_supply_state = 2;
  }
};


}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DATA_HOLDER_H_
