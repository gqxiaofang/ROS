/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_REBOT_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_REBOT_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct BatteryRebotData {
  uint32_t time_stamp;
  uint8_t soc;
  uint16_t voltage;
  uint8_t charge_status;
};

class BatteryRebotDriver : public AbstractDriver {
 public:
  BatteryRebotDriver();
  ~BatteryRebotDriver();
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  bool IsReady();

  void SetCharge(bool charge);

 private:
  void BatteryBMSRebotSetMsg3(bool state);
  void BatteryBMSRebotSetMsg4(bool state);
  void RebotBatterySOCFeedback(const VCI_CAN_OBJ data);
  void RebotBatteryStatusFeedback(const VCI_CAN_OBJ data);

  bool is_charge_;

  int channel_;
  int battery_bms_rebot_soc_id_;
  int battery_bms_rebot_status_id_;
  int battery_bms_rebot_ctrl3_id_;
  int battery_bms_rebot_ctrl4_id_;

  BatteryRebotData data_;
  ros::Time time_;

  std::shared_ptr<MessagePublisher> battery_bms_rebot_ctrl3_pub_;
  std::shared_ptr<MessagePublisher> battery_bms_rebot_ctrl4_pub_;
};

}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_REBOT_DRIVER_H_
