/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_ZL_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_ZL_DRIVER_H_

#include <memory>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct BatteryZLData {
  uint32_t time_stamp;
  uint16_t voltage;
  int16_t current;
  uint8_t soc;
  uint8_t fault_code;  // bit0:1-充电状态 bit1:1-电池温度过低
                       // bit2:1-电池温度过高 bit3:1-电池短路 bit4:1-电池过流
                       // bit5:1-单体欠压 bit6:1-单体过压 bit7:1-BMS故障
  uint16_t max_core_voltage;                     
  uint16_t min_core_voltage;     
  uint16_t max_core_tmp;                     
  uint16_t min_core_tmp;     

};

class BatteryZLDriver : public AbstractDriver {
 public:
  BatteryZLDriver();
  ~BatteryZLDriver();
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  bool IsReady();

  void BatteryBMSRebotSetMsg3();
  void BatteryBMSRebotSetMsg4();

  inline void SetCharge(bool charge) { is_charge_ = charge; }

 private:
  void ZLBatteryFeedback(const VCI_CAN_OBJ data);
  void ZLBatteryCoreFeedback(const VCI_CAN_OBJ data);

  bool is_charge_;

  int channel_;
  int battery_bms_zl_id_;
  int battery_core_zl_id_;    //电芯信息帧

  BatteryZLData data_;
  ros::Time time_;
};

}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_ZL_DRIVER_H_
