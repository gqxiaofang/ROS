/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_HIKVS_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_HIKVS_DRIVER_H_

#include <memory>
#include <string>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace {
#define PI_MATH 3.141593f
#define degree2rad(degree) ((degree)*2 * PI_MATH / 360)

constexpr size_t kDataSize28 = 28;
constexpr size_t kPackSize7 = 7;

void InverUint16(uint16_t *dBuf, uint16_t *srcBuf) {
  int i;
  uint16_t tmp[4];
  tmp[0] = 0;
  for (i = 0; i < 16; i++) {
    if (srcBuf[0] & (1 << i)) tmp[0] |= 1 << (15 - i);
  }
  dBuf[0] = tmp[0];
}

void InvertUint8(unsigned char *dBuf, unsigned char *srcBuf) {
  int i;
  unsigned char tmp[4];
  tmp[0] = 0;
  for (i = 0; i < 8; i++) {
    if (srcBuf[0] & (1 << i)) tmp[0] |= 1 << (7 - i);
  }
  dBuf[0] = tmp[0];
}

uint16_t Crc16Modbus(const unsigned char *puchMsg, unsigned int usDataLen) {
  uint16_t wCRCin = 0xFFFF;
  uint16_t wCPoly = 0x8005;
  unsigned char wChar = 0;
  while (usDataLen--) {
    wChar = *(puchMsg++);
    InvertUint8(&wChar, &wChar);
    wCRCin ^= (wChar << 8);
    for (int i = 0; i < 8; i++) {
      if (wCRCin & 0x8000)
        wCRCin = (wCRCin << 1) ^ wCPoly;
      else
        wCRCin = wCRCin << 1;
    }
  }
  InverUint16(&wCRCin, &wCRCin);
  return (wCRCin);
}

struct Raw_data {
  float fx;
  float fy;
  float fangle;
};

float normalize_angle(float angle) {
  float a = fmod(fmod(angle, 2.0f * PI_MATH) + 2.0f * PI_MATH, 2.0f * PI_MATH);
  if (a > PI_MATH) a -= 2.0f * PI_MATH;
  return a;
}

float f360toN180(float angle) { return normalize_angle(0 - angle); }

Raw_data CoordinateTransfer(Raw_data raw_data, float rotate_angle) {
  Raw_data processed_data;
  processed_data.fx =
      raw_data.fx * cos(rotate_angle) + raw_data.fy * sin(rotate_angle);
  processed_data.fy =
      -raw_data.fx * sin(rotate_angle) + raw_data.fy * cos(rotate_angle);
  processed_data.fangle = normalize_angle(raw_data.fangle - rotate_angle);

  return processed_data;
}
}  // namespace

namespace cotek_embedded {

#define HIK_DLC 0x1c
#define HIK_CRC_DATA_LENGTH 0x1a

#define TAG_DATA_OFFSET 0x00
#define TAG_NUMY_OFFSET 0x08
#define X_DEVIATION_OFFSET 0x0E      // 0x10
#define Y_DEVIATION_OFFSET 0x12      // 0x14
#define ANGLE_DEVIATION_OFFSET 0x16  // 0x18

#define TAG_DATA_LENGTH 0x0E
#define TAG_NUM_LENGTH 0x06
#define DATA_CHECK_LENGTH 0x02
#define DATA_CHECK_OFFSET 0x1A

const uint32_t CHECK_BYTE = 0xE662;
  
// mm -> m
struct HikvsData {
  uint32_t time_stamp;
  float x_deviation;
  float y_deviation;
  float angle;
  uint64_t tag_number;
};

// 海康摄像机传感器驱动
class HikvsDriver : public AbstractDriver {
 public:
  HikvsDriver();
  ~HikvsDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

 private:
  // can 接收数据
  void DataFeedback(const VCI_CAN_OBJ data);

  std::shared_ptr<MessagePublisher> hikvs_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int hikvs_id_;
  int data_feedback_id_;

  // 用于包顺序的校验
  std::bitset<4> pack_sequence_;
  bool received_;

  std::mutex mutex_;
  HikvsData data_;
  unsigned char sensor_data_[kDataSize28];
  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_HIKVS_DRIVER_H_
