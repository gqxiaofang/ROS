/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_AUDIO_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_AUDIO_DRIVER_H_

#include <memory>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct AudioData {
  uint32_t time_stamp;
  uint8_t audio_type;
  uint8_t audio_level;
};

class AudioDriver : public AbstractDriver {
 public:
  AudioDriver();
  ~AudioDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override;
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  // 私有接口
  void SetControl(uint8_t audio_type, uint8_t audio_level);

 private:
  // 状态量的Getters
  void HandleAudioDataFeedback(const VCI_CAN_OBJ data);

  // 消息发送句柄，每个publisher拥有一个消息的设备ID
  std::shared_ptr<MessagePublisher> control_pub_;

  int channel_;
  int node_id_;
  int feedback_id_;
  int control_id_;

  ros::Time time_;

  AudioData data_;
  AudioData set_data_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_AUDIO_DRIVER_H_
