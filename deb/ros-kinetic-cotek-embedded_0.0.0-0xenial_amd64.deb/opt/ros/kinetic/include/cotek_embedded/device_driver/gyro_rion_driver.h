/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_GYRO_RION_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_GYRO_RION_DRIVER_H_

#include <memory>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

enum class GyroRionVerify {
  Rino_Data_Head0 = 0x68,
  Rino_Data_Head1 = 0x0d,
  Rino_Data_Head2 = 0x00,
  Rino_Data_Head3 = 0x84,
};

struct GyroRionOriginData {
  unsigned char Data_Head[4];
  unsigned char arrOmegaZ[3];
  unsigned char arrAccelerateX[3];
  unsigned char arrAngleZ[3];
  unsigned char crc;
};

struct GyroRionData {
  uint32_t time_stamp;
  float fOmegaZ;
  float fAccelerateX;
  float fAngleZ;
};

class GyroRionDriver : public AbstractDriver {
 public:
  GyroRionDriver();
  ~GyroRionDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  float degree2rad(float degree);

  void TestControl(bool state);
  void ClearOffSet();

 private:
  void HandleFeedback(const VCI_CAN_OBJ data);
  void ClearErrorCode();
  void SetBaudrate();
  void SetFeedbackFrequency(unsigned char ms);
  float GyroToFloatData(unsigned char *arrData);
  bool SumCheckout(const unsigned char *data);

  std::shared_ptr<MessagePublisher> gr_pub_;

  int num_of_pkg_;

  int channel_;
  int node_id_;
  int baudrate_;

  int gr_set_id_;
  int feedback_id_;

  bool is_clearoff_;

  GyroRionData rion_data_;
  GyroRionOriginData origin_gyro_data_;

  ros::Time time_;
};
}  // namespace cotek_embedded

#endif