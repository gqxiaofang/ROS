/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_IO_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_IO_DRIVER_H_

#include <boost/regex.hpp>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {
struct IoDriverData {
  uint32_t time_stamp;
  // 直接由设备名取状态
  // 输入映射 键：设备名， 值： 设备状态
  std::map<unsigned char, bool> din;
  std::map<unsigned char, bool> dout;
};

// IO设备板的驱动
class IoDriver : public AbstractDriver {
 public:
  explicit IoDriver(std::map<std::string, unsigned char> io_map);
  ~IoDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void* data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  // 设置端口
  void SetDo(unsigned char port, bool state);
  // 统一输出can消息控制
  void SetControl();

 private:
  void SetMapping(const std::map<std::string, unsigned char>& io_map);
  void HandleInputMsg(const VCI_CAN_OBJ data);
  // 清除错误码 放在reset接口中
  void ClearErrorCode();
  void SetBaudrate();
  void SetFeedbackFrequency(unsigned char ms);

  void ClearState();
  inline bool CheckBit(unsigned char const& data, unsigned char offset) {
    return (data >> offset) & 0x01 ? true : false;
  }
  inline unsigned char GetBit(bool state) {
    return true == state ? 0x01 : 0x00;
  }

  int channel_;
  int node_id_;
  int baudrate_;

  int input_id_;
  int output_id_;
  std::shared_ptr<MessagePublisher> output_pub_;

  // 反馈索引
  // 输入映射 键：端口号， 值： 设备名“forcheck”
  //   std::map<unsigned char, unsigned char> di_map_;
  // 输出映射 键：端口号， 值： 设备名“laserlevel”
  //   std::map<unsigned char, unsigned char> do_map_;

  // 输出索引
  // 输出映射 键：设备名“继电器”， 值： 键.端口号1,2,3 值.状态
  //   std::map<unsigned char, std::pair<unsigned char, bool> > do_set_map_;

  std::map<std::string, unsigned char> io_map_;
  // 设备状态表  键：设备编号， 值：相应设备状态
  //   std::map<unsigned char, bool> di_state_table_;
  //   std::map<unsigned char, bool> do_state_table_;

  ros::Time time_;
  IoDriverData data_;
};

}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_IO_DRIVER_H_
