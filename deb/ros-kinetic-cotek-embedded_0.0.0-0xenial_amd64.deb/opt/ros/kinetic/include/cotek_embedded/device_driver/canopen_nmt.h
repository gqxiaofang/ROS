/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CANOPEN_NMT_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CANOPEN_NMT_H_

#include <ros/ros.h>
#include <map>
#include <memory>
#include <string>
#include "cotek_common/common.h"
#include "cotek_common/log_porting.h"
#include "cotek_embedded/can_message_center.h"
#include "cotek_embedded/message_publisher.h"

namespace cotek_embedded {

class CanopenNMT {
 public:
  static constexpr int kNMTId = 0x00;
  // CanOpen消息长度
  static constexpr int kNmtSize = 2;
  CanopenNMT() : node_id_(0) {}
  ~CanopenNMT() {}

  // NmtDriver
  void NMTInit(int channel, int node_id) {
    auto &mc = CanMessageCenter::Instance();
    nmt_pub_ = mc.Advertise(channel, kNMTId);
    node_id_ = node_id;
  }
  void NMTStart() {
    unsigned char buffer[kNmtSize] = {0};
    buffer[0] = 0x01;
    buffer[1] = node_id_;
    // 发送消息
    nmt_pub_->publish(buffer, kNmtSize);
  }
  void NMTStop() {
    unsigned char buffer[kNmtSize] = {0};
    buffer[0] = 0x02;
    buffer[1] = node_id_;
    // 发送消息
    nmt_pub_->publish(buffer, kNmtSize);
  }

  void NMTPreOperation() {
    unsigned char buffer[kNmtSize] = {0};
    buffer[0] = 0x80;
    buffer[1] = node_id_;
    // 发送消息
    nmt_pub_->publish(buffer, kNmtSize);
  }

  void NMTResetNode() {
    unsigned char buffer[kNmtSize] = {0};
    buffer[0] = 0x81;
    buffer[1] = node_id_;
    // 发送消息
    nmt_pub_->publish(buffer, kNmtSize);
  }

  void NMTResetCommunication() {
    unsigned char buffer[kNmtSize] = {0};
    buffer[0] = 0x82;
    buffer[1] = node_id_;
    // 发送消息
    nmt_pub_->publish(buffer, kNmtSize);
  }

 private:
  std::shared_ptr<MessagePublisher> nmt_pub_;
  int node_id_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CANOPEN_NMT_H_
