/**
 * Copyright (c) 2018 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ROS_VIRTUAL_DRIVER_IMU_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ROS_VIRTUAL_DRIVER_IMU_H_

#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <tf/tf.h>
#include "cotek_common/log_porting.h"

namespace cotek_embedded {
class Imu {
 public:
  Imu() : omega_z_(0.0), acc_x_(0.0), sequence_(0) {}

  inline double omega_z() const { return omega_z_; }

  void Update(const ros::Time &stamp, double angle_z, double omega_z,
              double accelerate_x);

  sensor_msgs::Imu ToRosImuMsg();

 private:
  ros::Time stamp_;
  double angle_z_;
  double omega_z_;
  double acc_x_;
  uint32_t sequence_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ROS_VIRTUAL_DRIVER_IMU_H_
