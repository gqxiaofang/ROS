/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_HINSON_MLS_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_HINSON_MLS_DRIVER_H_

#include <memory>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

namespace hinson_mls {
// direction options
enum class SelectDirection : uint8_t {
  NONE = 0x00,
  LEFT = 0x01,
  RIGHT = 0x02,
  // CURVE_LEFT = 0x13,
  // CUREVE_RIGHT = 0x14
};

enum class LinesInfo : uint16_t {
  NO_LINE = 0,
  ONE_LINE_LEFT = 1,
  ONE_LINE_CENTER = 2,
  ONE_LINE_RIGHT = 4,
  TWO_LINE_CENTER_LEFT = 3,
  TWO_LINE_CENTER_RIGHT = 6,
  THREE_LINE = 7
};

enum class Mode : uint16_t { NONE = 0, DIGITAL_MODE = 1, POSE_MODE = 2 };

}  // namespace hinson_mls

// Hinson MLS process data objects
struct HinsonMlsData {
  uint32_t time_stamp;
  hinson_mls::LinesInfo lines_info;
  float line_offset;  // -155 ~ +155mm, left > 0, right < 0, center = 0;
  // 不为 canopen
  // int16_t strength;
  // int16_t interaction_count;
};

// 兴颂磁条传感器驱动
class HinsonMlsDriver : public AbstractDriver {
 public:
  HinsonMlsDriver();
  ~HinsonMlsDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

  // 调用接口
  void SetDirection(hinson_mls::SelectDirection dir);

 private:
  // can 接收数据
  void HandleFeedbackData(const VCI_CAN_OBJ data);

  std::shared_ptr<MessagePublisher> select_mls_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int select_mls_id_;
  int data_feedback_id_;

  HinsonMlsData data_;

  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_UHINSON_MLS_DRIVER_H_
