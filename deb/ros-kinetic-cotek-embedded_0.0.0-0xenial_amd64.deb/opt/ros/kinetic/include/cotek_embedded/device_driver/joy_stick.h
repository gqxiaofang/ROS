#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_JOY_STICK_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_JOY_STICK_H_

#include <ros/console.h>

#include <fstream>
#include <memory>
#include <string>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

#define XBOX_TYPE_BUTTON 0x01
#define XBOX_TYPE_AXIS 0x02

#define XBOX_BUTTON_A 0x00
#define XBOX_BUTTON_B 0x01
#define XBOX_BUTTON_X 0x02
#define XBOX_BUTTON_Y 0x03
#define XBOX_BUTTON_LB 0x04
#define XBOX_BUTTON_RB 0x05
#define XBOX_BUTTON_START 0x06
#define XBOX_BUTTON_BACK 0x07
#define XBOX_BUTTON_HOME 0x08
#define XBOX_BUTTON_LO 0x09 /* 左摇杆按键 */
#define XBOX_BUTTON_RO 0x0a /* 右摇杆按键 */

#define XBOX_BUTTON_ON 0x01
#define XBOX_BUTTON_OFF 0x00

#define XBOX_AXIS_LX 0x00 /* 左摇杆X轴 */
#define XBOX_AXIS_LY 0x01 /* 左摇杆Y轴 */
#define XBOX_AXIS_RX 0x03 /* 右摇杆X轴 */
#define XBOX_AXIS_RY 0x04 /* 右摇杆Y轴 */
#define XBOX_AXIS_LT 0x02
#define XBOX_AXIS_RT 0x05
#define XBOX_AXIS_XX 0x06 /* 方向键X轴 */
#define XBOX_AXIS_YY 0x07 /* 方向键Y轴 */

#define XBOX_AXIS_VAL_UP -32767
#define XBOX_AXIS_VAL_DOWN 32767
#define XBOX_AXIS_VAL_LEFT -32767
#define XBOX_AXIS_VAL_RIGHT 32767

#define XBOX_AXIS_VAL_MIN -32767
#define XBOX_AXIS_VAL_MAX 32767
#define XBOX_AXIS_VAL_MID 0x00

#define JS_EVENT_BUTTON 0x01 /* button pressed/released */
#define JS_EVENT_AXIS 0x02   /* joystick moved */
#define JS_EVENT_INIT 0x80   /* initial state of device */

enum class xbox_map {
  UP,
  DOWN,
  LEFT,
  RIGHT,
  X,
  Y,
  A,
  B,
  RESET,
  START,
  OFF,
  NONE
};
// joy_stick driver
struct xbox_map_real {
  int lx;
  int ly;
  int rx;
  int ry;
};

struct js_event {
  unsigned int time;
  signed short value;
  unsigned char type;
  unsigned char number;
};

class JoyDriver : public AbstractDriver {
 public:
  JoyDriver();
  ~JoyDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void* data) override;
  // int GetData();
  void Reset() override;
  // void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  void WriteAndFlush() override {}
  void HandleFeedbackData();

  // 调用接口

 private:
  void judge_rocker(const js_event& js);
  void judge_xmap_real();
  void judge_key(const js_event& js);
  struct js_event js;
  std::ifstream fin;
  const char* file;
  std::shared_ptr<std::thread> run_executor_;
  xbox_map data_;
  xbox_map_real rocker;
};

}  // namespace cotek_embedded

#endif
