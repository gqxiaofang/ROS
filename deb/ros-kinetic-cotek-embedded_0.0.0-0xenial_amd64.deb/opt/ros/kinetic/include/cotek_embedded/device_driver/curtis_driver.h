/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CURTIS_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CURTIS_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

namespace curtis_param {
// curtis控制器参数
constexpr uint16_t kSteeringLimit = 1000;
constexpr uint16_t kAcceleration = 2000;  // ms
constexpr uint16_t kDeceleration = 600;  // ms
}  // namespace curtis_param

struct CurtisData {
  uint32_t time_stamp;
  // 驱动轮速度
  float actual_driver_velocity;
  // 舵轮偏转角
  float actual_steering_angle;
  // Curtis手自动模式
  uint8_t driver_mode;
  // 叉车电池电量
  uint8_t battery;

  uint8_t reset_state;
};

struct CurtisControlParam {
  unsigned char fork_down;
  unsigned char fork_up;
  unsigned char brake;
  unsigned char forward;
  unsigned char backward;
  unsigned char beep;
};

// 柯蒂斯的驱动
class CurtisDriver : public AbstractDriver {
 public:
  CurtisDriver();
  ~CurtisDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

  // 调用接口
  void SetHeartBeat();
  void SetConfig(uint16_t accel, uint16_t decel, uint16_t steering_limit);
  void SetControl(float driver_velocity, float steering_angle,
                  AtomicActionType action_type);
  void SetReset(bool set);

 private:
  // can 接收数据
  void HandleFeedbackMsg(const VCI_CAN_OBJ data);
  void HandleResetStateMsg(const VCI_CAN_OBJ data);

  // 消息发送句柄，每个publisher拥有一个消息的设备ID
  std::shared_ptr<MessagePublisher> control_pub_;
  std::shared_ptr<MessagePublisher> reset_pub_;
  std::shared_ptr<MessagePublisher> paramset_pub_;
  std::shared_ptr<MessagePublisher> heartbeat_pub_;

  int channel_;
  int feedback_id_;
  int param_set_id_;
  int control_id_;
  int heartbeat_id_;
  int reset_control_id_;
  int reset_state_id_;

  CurtisControlParam curtis_control_param_;

  CurtisData data_;
  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CURTIS_DRIVER_H_
