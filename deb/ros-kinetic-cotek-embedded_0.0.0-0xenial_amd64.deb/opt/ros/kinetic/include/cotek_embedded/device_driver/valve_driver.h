/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_VALVE_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_VALVE_DRIVER_H_

#include <bitset>
#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

namespace valve_param {
constexpr int16_t kUp = -1000;
constexpr int16_t kForward = 500;
constexpr int16_t kBackward = -500;
constexpr int kMaxDownSpeed = 1000;
}  // namespace valve_param

struct ValveData {
  uint32_t time_stamp;
  bool channel_0;  // 8路通道输出
  bool channel_1;
  bool channel_2;
  bool channel_3;
  bool channel_4;
  bool channel_5;
  bool channel_6;
  bool channel_7;
};

// 比例阀传感器驱动
class ValveDriver : public AbstractDriver {
 public:
  ValveDriver();
  ~ValveDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void* data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  // 私有接口
  void SetControl(const int16_t& height_ctrl, const int16_t& lateral_ctrl);

 private:
  // can 接收数据
  void DataFeedback(const VCI_CAN_OBJ data);

  std::shared_ptr<MessagePublisher> valve_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int control_id_;
  int data_feedback_id_;

  ValveData data_;

  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_VALVE_DRIVER_H_
