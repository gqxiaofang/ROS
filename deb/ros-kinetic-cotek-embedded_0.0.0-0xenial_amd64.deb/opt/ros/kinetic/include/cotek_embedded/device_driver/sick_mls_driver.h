/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_SICK_MLS_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_SICK_MLS_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {
struct MLSData {
  double offset;
  bool found_line;
};

// #LPC byte bit0-bit2 line information
enum class LineInfo : int {
  MLS_NO_LINE = 0,
  MLS_ONE_LINE = 2,
  MLS_TWO_LINE_RIGHTD = 3,
  MLS_TWO_LINE_LEFTD = 6,
  MLS_THREE_LINE = 7
};

// direction options
enum class MLSDirection : int {
  MLS_Direction_None = 0,
  MLS_Direction_Left = 2,
  MLS_Direction_Right = 3,
  MLS_Direction_Curve_Left = 130,
  MLS_Direction_Curve_Right = 131
};

// 磁条传感器驱动
class SickMLSDriver : public AbstractDriver {
 public:
  SickMLSDriver(/* args */);
  ~SickMLSDriver();
  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

  void SetControl(MLSDirection dir) { dir_ = dir; }

 private:
  double SickSensorMLSGetOffset(MLSDirection dir);
  void SickMLSDataFeedback(const VCI_CAN_OBJ data);

  // temp var
  int16_t lcp1_;
  int16_t lcp2_;
  int16_t lcp3_;
  LineInfo lines_info_;
  uint8_t status_marker_;
  bool found_lines_;
  uint8_t field_strength_;
  bool polarity_;

  int channel_;
  int sick_mls_id_;

  ros::Time time_;
  MLSDirection dir_;
  MLSData data_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_SICK_MLS_DRIVER_H_
