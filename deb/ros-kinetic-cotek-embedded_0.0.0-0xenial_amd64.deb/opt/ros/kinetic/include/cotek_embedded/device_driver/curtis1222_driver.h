/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CURTIS1222_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CURTIS1222_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

namespace curtis1222_param {
// curtis1222控制器参数
constexpr int kMaxUpSpeed = 8000;
}  // namespace curtis1222_param

struct Curtis1222Data {
  uint32_t time_stamp;
  // 驱动轮速度
  float actual_driver_velocity;
  // 舵轮偏转角
  float actual_steering_angle;
  // Curtis手自动模式
  uint8_t driver_mode;
  // 托盘升降速度
  // uint16_t up_rpm;
  // 叉车电池电量
  uint8_t battery;
};

struct Curtis1222ControlParam {
  unsigned char is_fork_up;
  unsigned char brake;
  unsigned char forward;
  unsigned char backward;
};

// 柯蒂斯的驱动
class Curtis1222Driver : public AbstractDriver {
 public:
  Curtis1222Driver();
  ~Curtis1222Driver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

  // 调用接口
  void SetControl(float driver_velocity, float steering_angle, uint16_t up_rpm,
                  AtomicActionType action_type);
  // void SetReset(bool set);

 private:
  // can 接收数据
  void HandleFeedbackMsg(const VCI_CAN_OBJ data);

  // 消息发送句柄，每个publisher拥有一个消息的设备ID
  std::shared_ptr<MessagePublisher> control_pub_;
  std::shared_ptr<MessagePublisher> heartbeat_pub_;
  int channel_;
  int feedback_id_;
  int control_id_;

  Curtis1222ControlParam curtis_control_param_;

  Curtis1222Data data_;
  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_CURTIS1222_DRIVER_H_
