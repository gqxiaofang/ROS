/**
 * Copyright (c) 2020 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_WEIGHING_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_WEIGHING_DRIVER_H_

#include <memory>

#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct WeighData {
  uint32_t time_stamp;
  int32_t weigh;
  uint32_t weigh_status;
  uint32_t weigh_errcode;
  WeighData() { memset(this, 0, sizeof(WeighData)); }
};

class WeighingDriver : public AbstractDriver {
 public:
  WeighingDriver();
  ~WeighingDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  void SetUpSIGN(bool en);

 private:
  void HandleFeedback(const VCI_CAN_OBJ data);
  void ClearErrorCode();
  void SetBaudrate();
  void SetFeedbackFrequency(unsigned char ms);
  void ClearAlarm(bool en);

  std::shared_ptr<MessagePublisher> pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int send_id_;
  int feedback_id_;

  bool is_clearoff_;

  WeighData data_;

  int32_t weight;

  ros::Time time_;
};
}  // namespace cotek_embedded

#endif
