/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ABSTRACT_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ABSTRACT_DRIVER_H_
#include <ros/ros.h>

#include <map>
#include <memory>
#include <string>

#include "cotek_common/common.h"
#include "cotek_common/cotek_enum_type.h"
#include "cotek_common/device_table_loader.h"
#include "cotek_common/log_porting.h"
#include "cotek_embedded/can_message_center.h"
#include "cotek_embedded/data_holder.h"
#include "cotek_embedded/device_driver/canopen_nmt.h"
#include "cotek_embedded/message_publisher.h"

namespace cotek_embedded {

// 驱动状态
enum class DriverState {
  // 未初始化，设备启动时的默认状态
  UNINITIALIZED,
  // 正在初始化，调用Init()接口后切换为该状态
  INITIALIZING,
  // 就绪态，处于该状态下的驱动可以正常使用
  READY,
  // 故障态，处于该状态的驱动无法正常使用，需要重置或重启
  ERROR
};

// 设备驱动公共错误码
enum class ErrorCodeType : uint16_t {
  NONE = 0,              // 正常
  SENDFAILED = 0xFFFC,   // 发送错误
  INITFAILED = 0xFFFD,   // 初始化错误
  ILLEGAL = 0xFFFE,      // 非法数据
  DISCONNECTED = 0xFFFF  // 掉线
};

#define SWITCH_STATE_READY()                                       \
  do {                                                             \
    if (DriverState::INITIALIZING == AbstractDriver::GetState()) { \
      AbstractDriver::SetState(DriverState::READY);                \
      SetErrorCode(static_cast<uint16_t>(ErrorCodeType::NONE));    \
    }                                                              \
  } while (0)

#define SET_ERROR(type)                                                 \
  do {                                                                  \
    if (GetErrorCode() == static_cast<uint16_t>(ErrorCodeType::NONE)) { \
      SetErrorCode(static_cast<uint16_t>(type));                        \
      SetState(DriverState::ERROR);                                     \
    }                                                                   \
  } while (0)

#define CLEAR_ERROR(type)                                       \
  do {                                                          \
    if (GetErrorCode() == static_cast<uint16_t>(type)) {        \
      SetErrorCode(static_cast<uint16_t>(ErrorCodeType::NONE)); \
      SetState(DriverState::READY);                             \
    }                                                           \
  } while (0)

class AbstractDriver {
 public:
  // 驱动通过ID来标识
  explicit AbstractDriver(std::string name)
      : name_(name),
        state_(DriverState::UNINITIALIZED),
        errorcode_(static_cast<int>(ErrorCodeType::INITFAILED)) {
    canopen_nmt_ptr_ = std::make_shared<CanopenNMT>();
  }

  virtual ~AbstractDriver() {}

  std::string CanMessageToString(const VCI_CAN_OBJ data) {
    char str[300] = {0};
    std::string can_message;
    try {
      sprintf(str,
              " \r\n ID = [%x]\r\n TimeStamp = [%d]\r\n Data[0] = "
              "[%x]\r\n Data[1] = [%x]\r\n Data[2] = [%x]\r\n Data[3] = [%x] "
              "\r\n Data[4] = [%x]\r\n Data[5] = [%x]\r\n Data[6] = [%x]\r\n "
              "Data[7] = [%x]\r\n",
              data.ID, data.TimeStamp, data.Data[0], data.Data[1], data.Data[2],
              data.Data[3], data.Data[4], data.Data[5], data.Data[6],
              data.Data[7]);
    } catch (const std::exception) {
      LOG_ERROR("CanMessageToString is failed");
    }
    can_message = static_cast<std::string>(str);
    return can_message;
  }

  // 设备用设备名称来标识
  // 之所以不用设备ID的原因是因为当个设备可能包含多个设备ID，如curtis驱动器
  inline std::string GetName() const { return name_; }

  // 获取驱动当前状态
  // 框架在调用某些接口时需要确认驱动状态正常
  inline DriverState GetState() const { return state_; }

  inline void SetState(DriverState state) { state_ = state; }

  // 驱动是否就绪
  inline bool IsInitializing() {
    return GetState() == DriverState::INITIALIZING;
  }

  // 驱动是否就绪
  inline bool IsReady() { return GetState() == DriverState::READY; }

  // 获取NMT驱动
  inline std::shared_ptr<CanopenNMT> GetNMTDriver() { return canopen_nmt_ptr_; }

  // 获取驱动错误码
  inline uint16_t GetErrorCode() const { return errorcode_; }

  inline void SetErrorCode(uint16_t errorcode) { errorcode_ = errorcode; }

  // 获取驱动数据
  virtual void GetData(void *data) = 0;

  // 驱动初始化接口
  // 调用该接口后驱动开始初始化，状态切换为初始化中
  virtual void Init(ChildDeviceParam device_param) = 0;

  // 驱动重置接口
  virtual void Reset() = 0;

  // // 驱动消息发送接口
  // // 上层业务负责设值即可，框架会调用发送接口统一发送数据
  virtual void WriteAndFlush() = 0;

 private:
  std::string name_;
  // 驱动状态
  DriverState state_;
  // 驱动错误码
  uint16_t errorcode_;

  std::shared_ptr<CanopenNMT> canopen_nmt_ptr_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ABSTRACT_DRIVER_H_
