/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_PGV100_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_PGV100_DRIVER_H_

#include <memory>

#include "cotek_embedded/device_driver/abstract_driver.h"
#include "cotek_embedded/message_publisher.h"

namespace cotek_embedded {
struct PGV100Data {
  int time_stamp;
  double x_deviation;
  double y_deviation;
  double angle;
  uint32_t tag_number;
  uint8_t color;
  uint8_t direction;
  uint16_t warningcode;
};

enum class ModeType : uint8_t { NONE, TAG, LINE, POSITION };

enum class DirectionType : uint8_t {
  PGV_ERROR = 0x00,
  PGV_LEFT = 0xE4,
  PGV_RIGHT = 0xE8,
  PGV_BEST = 0xEC
};

enum class ColorType : uint8_t {
  PGV_BLUE = 0xC4,
  PGV_GREEN = 0x88,
  PGV_RED = 0x90
};

class PGV100Driver : public AbstractDriver {
 public:
  PGV100Driver();
  ~PGV100Driver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  void SetControl();
  void SelectDirection(DirectionType direction, uint8_t address);
  void SelectColor(ColorType color, uint8_t address);
  // 重载接口
  bool IsReady();

 private:
  // can 接收数据
  void HandleFeedback(const VCI_CAN_OBJ data);
  //清除错误码 放在reset接口中
  void ClearErrorCode();
  void SetBaudrate();
  void SetFeedbackFrequency(unsigned char ms);
  float f360toN180(float angle);
  ModeType CheckStatus(uint8_t statusL, uint8_t statusH);

  std::shared_ptr<MessagePublisher> pgv100_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int pgv100_set_id_;
  int feedback_id_;

  DirectionType direction_;
  ColorType color_;

  ros::Time time_;
  PGV100Data data_;
  uint8_t origin_data_[21];

  ModeType mode_;
  uint8_t address_;
  int packsum_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_PGV100_DRIVER_H_
