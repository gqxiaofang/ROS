/**
 * Copyright (c) 2018 CoTEK Inc. All rights reserved.
 */

#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_MOTOR_SYNTRON_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_MOTOR_SYNTRON_DRIVER_H_

#include "boost/algorithm/clamp.hpp"
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct MotorData {
  uint32_t time_stamp;
  int current;
  int speed;
  MotorData() : time_stamp(0), current(0), speed(0) {}
};

// 和利时电机驱动
class MotorSyntronDriver : public AbstractDriver {
 public:
  MotorSyntronDriver();
  ~MotorSyntronDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override;
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  // 私有接口 speed(rpm)
  void SetControl(double dspeed);

  void SetAlarmControl(bool use);

  // time1:加速时间  time2:减速时间
  void SetAccelAndDecelControl(double time1, double time2);

  void SetMotorDisableControl(bool enable);

  void SetCurrentLimitControl(double value);

 private:
  // 状态量的Getters
  void HandleMotorDataFeedback(const VCI_CAN_OBJ data);

  // 消息发送句柄，每个publisher拥有一个消息的设备ID
  std::shared_ptr<MessagePublisher> control_pub_;

  int channel_;
  int feedback_id_;
  int control_id_;

  ros::Time time_;

  MotorData data_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_MOTOR_SYNTRON_DRIVER_H_
