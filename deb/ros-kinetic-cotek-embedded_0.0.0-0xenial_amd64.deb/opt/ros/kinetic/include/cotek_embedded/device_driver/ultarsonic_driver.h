/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ULTARSONIC_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ULTARSONIC_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

// mm -> m
struct Ultarsonic_Data {
  double length1;
  double length2;
  double length3;
};

// 超声波传感器驱动
class UltarsonicDriver : public AbstractDriver {
 public:
  UltarsonicDriver();
  ~UltarsonicDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

 private:
  // can 接收数据
  void DataFeedback(const VCI_CAN_OBJ data);
  std::shared_ptr<MessagePublisher> ultarsonic_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int ultarsonic_id_;
  int data_feedback_id_;

  Ultarsonic_Data data_;

  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_ULTARSONIC_DRIVER_H_
