/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_LINDE_KOB_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_LINDE_KOB_DRIVER_H_

#include <bitset>
#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

struct LindeData {
  uint32_t time_stamp;
  // 驱动轮速度
  float actual_driver_velocity;
  // 舵轮偏转角
  float actual_steering_angle;
  // 反馈驱动轮设定速度
  float actual_set_driver_velocity;
  // 反馈舵轮设定偏转角
  float actual_set_steering_angle;
  // 上下位置
  uint8_t up_down;  // 0:down; 1:middle; 2:up
  // 手自动模式
  uint8_t driver_mode;
  // 叉车电池电量
  uint8_t battery;
};

enum class LinDeDriverMode : uint8_t {
  AGV_EXIT = 0,
  AGV_MODE = 1,
  AGV_ENTER = 2,
  MANUAL_MODE = 3
};

enum class TracCtrlCmd : uint8_t { STOP = 0, FORWARD = 1, BACKWARD = 2 };
enum class LiftCtrlCmd : uint8_t { STOP = 0, UP = 1, DOWN = 2 };
enum class SterrCtrlCmd : uint8_t { STOP = 0, LEFT = 1, RIGHT = 2 };

enum class LegState : uint8_t { DOWN = 0, MIDDLE = 1, UP = 2 };

struct LindeCtrl {
  uint8_t driver_mode;  // ModeSelect
  uint8_t trac_cmd;
  uint8_t sterr_cmd;
  uint8_t lift_cmd;
  float trac_speed;
  float sterr_angle;
  uint16_t lift_spd_set;
};

// 林德KOB2.1的驱动
class LindeKobDriver : public AbstractDriver {
 public:
  LindeKobDriver();
  ~LindeKobDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void* data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

  // 调用接口
  void SetDriverMode(LinDeDriverMode mode);

  void SetControl(float driver_velocity, float steering_angle,
                  AtomicActionType action_type);
  inline void SetAvoidLevel(const uint8_t& avoid_level) {
    avoid_level_ = avoid_level;
  }

 private:
  // can 接收数据
  void HandleTractSpeedFeedbackMsg(const VCI_CAN_OBJ data);
  void HandleActionFeedbackMsg(const VCI_CAN_OBJ data);
  void HandleSteerFeedbackMsg(const VCI_CAN_OBJ data);

  void HandleKobErrorCodeMsg(const VCI_CAN_OBJ data);

  void SendTractSpeed_1();
  void SendAction_1(AtomicActionType action_type);
  void SendSteer_1();

  void SendTractSpeed_2();
  void SendAction_2(AtomicActionType action_type);
  void SendSteer_2();

  void ChangeMode();

  inline void EnterAudoMode() {
    linde_ctrl_.driver_mode = static_cast<uint8_t>(LinDeDriverMode::AGV_MODE);
  }
  inline void EnterManualMode() {
    linde_ctrl_.driver_mode =
        static_cast<uint8_t>(LinDeDriverMode::MANUAL_MODE);
  }

  // 消息发送句柄，每个publisher拥有一个消息的设备ID
  std::shared_ptr<MessagePublisher> tract_control_pub_1_;
  std::shared_ptr<MessagePublisher> action_control_pub_1_;
  std::shared_ptr<MessagePublisher> sterr_control_pub_1_;

  std::shared_ptr<MessagePublisher> tract_control_pub_2_;
  std::shared_ptr<MessagePublisher> action_control_pub_2_;
  std::shared_ptr<MessagePublisher> sterr_control_pub_2_;

  int channel_;
  int tract_feedback_id_;
  int action_feedback_id_;
  int steer_feedback_id_;
  int error_code_id_;

  uint8_t avoid_level_;
  int tract_control_id_1_;
  int action_control_id_1_;
  int sterr_control_id_1_;

  int tract_control_id_2_;
  int action_control_id_2_;
  int sterr_control_id_2_;

  bool state_switch_protect_;

  LindeData data_;
  LindeCtrl linde_ctrl_;
  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_LINDE_KOB_DRIVER_H_
