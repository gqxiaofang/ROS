/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_BAOE_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_BAOE_DRIVER_H_

#include <memory>
#include <queue>

#include "cotek_embedded/device_driver/abstract_driver.h"

#define BATTERY_DEBUG 1
namespace cotek_embedded {

struct BatteryBaoeData {
  uint32_t time_stamp;
  uint32_t voltage;
  int32_t current;
  uint8_t soc;
};

class BatteryBaoeDriver : public AbstractDriver {
 public:
  BatteryBaoeDriver(/* args */);
  ~BatteryBaoeDriver();
  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();

 private:
  void VoltageCurrentFeedback(const VCI_CAN_OBJ data);
  void BatteryPercentageFeedback(const VCI_CAN_OBJ data);

  int channel_;
  int voltage_current_id_;
  int battery_percentage_error_id_;
  uint8_t err_filter_cnt_;
  std::queue<uint32_t> filter_current_;
  BatteryBaoeData data_;
  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_BATTERY_BAOE_DRIVER_H_
