/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_LOW_POWER_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_LOW_POWER_DRIVER_H_

#include <memory>
#include "cotek_embedded/device_driver/abstract_driver.h"

namespace cotek_embedded {

enum class SwitchState { UNKNOWN = -1,
                         OFF = 0,
                         ON = 1 };

// 柯蒂斯的驱动
class LowPowerDriver : public AbstractDriver {
 public:
  LowPowerDriver();
  ~LowPowerDriver();
  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override{};
  void Reset() override;
  void WriteAndFlush() override;
  // 重载接口
  bool IsReady();

  inline void SetMotorPower(SwitchState state) { motor_power_state_.w = state; }
  inline SwitchState GetMotorPower() const { return motor_power_state_.r; }

 private:
  // 读写状态分离
  // 因为写状态是异步发生的，所以需要先记录要写的值，然后再发送
  // 读的状态是由底层消息更新的
  struct RwState {
    SwitchState r;
    SwitchState w;
  };
  // 这里只是个demo，实际需根据业务对象来重命名回调函数，确保代码可读性
  void MotorPowerSwitchCallback(const VCI_CAN_OBJ data);
  // 电机开关驱动句柄
  std::shared_ptr<MessagePublisher> motor_power_pub_;
  // 电机开关的读写状态
  RwState motor_power_state_;
  int channel_;
  int motor_power_receive_id_;
  int motor_power_transmit_id_;

  ros::Time time_;
};
}  // namespace cotek_embedded
#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_LOW_POWER_DRIVER_H_
