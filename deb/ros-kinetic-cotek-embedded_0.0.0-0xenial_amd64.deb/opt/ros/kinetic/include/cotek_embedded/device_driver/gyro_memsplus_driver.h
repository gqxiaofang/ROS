/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_GYRO_MEMSPLUS_DRIVER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_DEVICE_DRIVER_GYRO_MEMSPLUS_DRIVER_H_

#include "cotek_embedded/device_driver/abstract_driver.h"
#include <memory>

namespace cotek_embedded {

enum class GyroMemsplusVerify {
  Rino_Data_Head0 = 0x68,
  Rino_Data_Head1 = 0x0d,
  Rino_Data_Head2 = 0x00,
  Rino_Data_Head3 = 0x84,
};

struct GyroMemsplusOriginData {
  unsigned char arrOmegaZ[2];
  unsigned char arrAngleZ[2];
};

struct GyroMemsplusData {
  float fOmegaZ;
  float fAccelerateX;
  float fAngleZ;
};

class GyroMemsplusDriver : public AbstractDriver {
public:
  GyroMemsplusDriver();
  ~GyroMemsplusDriver();

  // 实现AbstractDriver的接口
  void Init(ChildDeviceParam device_param) override;
  void GetData(void *data) override;
  void Reset() override {}
  void WriteAndFlush() override {}
  // 重载接口
  bool IsReady();
  float degree2rad(float degree);

  void ClearOffSet();

private:
  void HandleFeedback(const VCI_CAN_OBJ data);
  float GyroToFloatData(unsigned char *arrData);


  std::shared_ptr<MessagePublisher> gr_pub_;

  int channel_;
  int node_id_;
  int baudrate_;

  int gr_set_id_;
  int feedback_id_;

  bool is_clearoff_;

  GyroMemsplusData memsplus_data_;
  GyroMemsplusOriginData origin_gyro_data_;

  ros::Time time_;
};
} // namespace cotek_embedded

#endif