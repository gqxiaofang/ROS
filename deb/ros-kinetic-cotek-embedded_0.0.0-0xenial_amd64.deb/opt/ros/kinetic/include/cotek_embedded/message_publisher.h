/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MESSAGE_PUBLISHER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MESSAGE_PUBLISHER_H_
#include <functional>

namespace cotek_embedded {

class MessagePublisher {
 public:
  explicit MessagePublisher(
      int channel, int id,
      std::function<bool(int, int, const unsigned char*, unsigned char length)>
          writer)
      : channel_(channel), id_(id), write_handler_(writer) {}

  bool publish(const unsigned char* data, unsigned char length) {
    return write_handler_(channel_, id_, data, length);
  }

 private:
  int channel_;
  int id_;
  std::function<bool(int, int, const unsigned char*, unsigned char length)>
      write_handler_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MESSAGE_PUBLISHER_H_
