/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MESSAGE_CENTER_INTERFACE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MESSAGE_CENTER_INTERFACE_H_
#include <functional>
#include <memory>

#include "cotek_common/device_table_loader.h"
#include "cotek_embedded/message_publisher.h"

namespace cotek_embedded {

enum class MessageCenterState { UNINITIALIZED, ACTIVE, STOPPED };

// 消息中心接口
// 通过实现该接口来实现消息代理中心，从而实现消息统一接收与分发的功能
class MessageCenterInterface {
 public:
  virtual bool Init(ChannelBaudrateParam channel_baudrate) = 0;
  // 开始监听消息
  virtual void Start() = 0;
  // 停止监听消息
  virtual void Stop() = 0;
  // 消息订阅接口
  virtual void Subscribe(
      int channel /* 消息通道 */, int can_id /* 消息ID */,
      std::function<void(const VCI_CAN_OBJ)> data_callback) = 0;
  // 获取消息发送句柄
  virtual std::shared_ptr<MessagePublisher> Advertise(int channel,
                                                      int can_id) = 0;

 protected:
  // 消息发送接口
  virtual bool WriteAndFlush(int channel, int can_id, const unsigned char* data,
                             unsigned char date_length) = 0;
  // 消息接收回调
  virtual void MessageCallback(int channel, int can_id,
                               const VCI_CAN_OBJ data) = 0;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MESSAGE_CENTER_INTERFACE_H_
