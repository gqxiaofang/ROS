/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_H_
#include <ros/ros.h>
#include <unistd.h>

#include <map>
#include <memory>
#include <string>
#include <thread>

#include "cotek_common/cotek_topic_name.h"
#include "cotek_common/device_table_loader.h"
#include "cotek_common/node_diagnostic_info.h"
#include "cotek_embedded/can_message_center.h"
#include "cotek_embedded/embedded_controller_options.h"
#include "cotek_embedded/model_entity/agv_hardware_factory.h"
#include "cotek_msgs/node_diagnostic.h"

#define USE_ZLG_CAN 1

namespace cotek_embedded {

using EmbeddedNodeStatus = cotek_diagnostic::EmbeddedNodeStatus;

class EmbeddedController {
 public:
  /**
   * \brief delete default constructor, embedded controller cannot work properly
   * without options
   */
  EmbeddedController() = delete;

  /**
   * \brief construct object with options
   * \param option all embedded controller related parameters
   */
  explicit EmbeddedController(const EmbeddedControllerOption& option);

  ~EmbeddedController();

  bool Init();

  // 输入 v,w
  inline void AddMoveCmdMsg(const cotek_msgs::move_cmd::ConstPtr& move_cmd) {
    hardware_builder_->InputMoveCmdMsg(move_cmd);
  }
  // 输入 safety_setting
  inline void AddSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr& safety_setting) {
    hardware_builder_->InputSafetySettingMsg(safety_setting);
  }

  // 不同车型的动作抽象数据不一样
  // 输入叉车动作
  void AddForkLiftActionMsg(
      const cotek_msgs::forklift_action::ConstPtr& forklift_action) {
    hardware_builder_->InputActionMsg(forklift_action);
  }

  // 输入顶升动作
  void AddJackUpActionMsg(
      const cotek_msgs::jack_up_action::ConstPtr& jack_up_action) {
    hardware_builder_->InputActionMsg(jack_up_action);
  }

  void Run();

  inline bool UpdateOption(const EmbeddedControllerOption& option) {
    option_ = option;
    // TODO 校验完 return true
    return true;
  }

 private:
  void Runner();

  inline void CheckCanTimeout() {
    if (CanMessageCenter::Instance().CheckDataTimeout()) {
      LOG_ERROR("Can receive data timeout");
      SetNodeStatus(EmbeddedNodeStatus::CAN_RECEIVE_TIME_OUT);
      CanMessageCenter::Instance().SetState(MessageCenterState::STOPPED);
      ReStartCan();
    } else {
      CanMessageCenter::Instance().SetState(MessageCenterState::ACTIVE);
    }
  }

  inline void ReStartCan() {
#if USE_ZLG_CAN
    CanMessageCenter::Instance().Stop();
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
#endif
    // can卡重启
    if (!CanMessageCenter::Instance().ReStart(
            DeviceTableLoader::Instance().ChannelBaudrate())) {
      LOG_ERROR("can init failed !");
      SetNodeStatus(EmbeddedNodeStatus::CAN_INIT_ERROR);
      return;
    }
    LOG_INFO("Can Restart succeeded !!!");
  }

  inline void SendCanMsg() {
    if (!CanMessageCenter::Instance().SendCan0MsgBuffer()) {
      LOG_ERROR("can0 send msg failed!");
      SetNodeStatus(EmbeddedNodeStatus::CAN_0_SEND_ERROR);
    }

    if (!CanMessageCenter::Instance().SendCan1MsgBuffer()) {
      LOG_ERROR("can1 send msg failed!");
      SetNodeStatus(EmbeddedNodeStatus::CAN_1_SEND_ERROR);
    }
  }

  EmbeddedControllerOption option_;
  EmbeddedNodeStatus status_;
  ros::Timer timer_;
  ros::Publisher node_diagnostic_pub_;
  std::shared_ptr<HardwareInterface> hardware_builder_;

  std::shared_ptr<std::thread> run_executor_;
  bool clear_control_data_flag_;

  void NodeDiagnostic(const ros::TimerEvent& e);
  inline void SetNodeStatus(const EmbeddedNodeStatus& status) {
    status_ = status;
  }
};  // namespace cotek_embedded

}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_H_
