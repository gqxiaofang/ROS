/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_OPTIONS_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_OPTIONS_H_
#include <string>

#include "cotek_common/agv_basic_option.h"
#include "cotek_common/cotek_enum_type.h"

namespace cotek_embedded {
// 移动模型参数
struct MoveModelOption {
  BicycleModelOption bicycle_model_option;
  UnicycleModelOption unicycle_model_option;
  MoveModelControl movemode_control_option;
};

struct EmbeddedControllerOption {
  AgvType agv_type;
  double can_send_frequency;
  double clear_cycle_number;
  MoveModelOption move_model_option;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_EMBEDDED_CONTROLLER_OPTIONS_H_
