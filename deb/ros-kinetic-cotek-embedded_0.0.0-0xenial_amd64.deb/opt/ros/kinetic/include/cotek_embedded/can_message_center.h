/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_CAN_MESSAGE_CENTER_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_CAN_MESSAGE_CENTER_H_
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <map>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

#include "cotek_common/log_porting.h"
#include "cotek_common/util/singleton.h"
#include "cotek_embedded/hardware_driver/controlcan.h"
#include "cotek_embedded/message_center_interface.h"
#include "cotek_embedded/thread_pool.h"

namespace cotek_embedded {
// 线程池线程数量
constexpr size_t kThreadSize = 1;

const constexpr unsigned kCanDevType = 4;  // usbcan-ii
const constexpr unsigned kCanDevIdx = 0;   // card 0
const constexpr unsigned kCanTxType = 0;   // normal mode
const constexpr unsigned kCanTxFrames = 1;
const constexpr unsigned kCanChannel0 = 0;
const constexpr unsigned kCanChannel1 = 1;
const constexpr unsigned kCanMaxChannels = 2;
const constexpr unsigned kCanBaudrate50 = 0x1c09;    // 50 kbps
const constexpr unsigned kCanBaudrate125 = 0x1c03;   // 125 kbps
const constexpr unsigned kCanBaudrate250 = 0x1c01;   // 250 kbps
const constexpr unsigned kCanBaudrate500 = 0x1c00;   // 500 kbps
const constexpr unsigned kCanBaudrate1000 = 0x1400;  // 1M kbps
const constexpr uint32_t kCanCheckPoints = 200;
const constexpr uint32_t kCanRxWaitTime = -1;
const constexpr uint32_t kCanRxBuffSize = 1000;
const constexpr uint32_t kCanTxBuffSize = 500;
const constexpr double kCanRxTimeout = 5.0;

// 实现Can的消息代理
class CanMessageCenter : public MessageCenterInterface {
 public:
  ~CanMessageCenter() {
    Stop();
    VCI_CloseDevice(kCanDevType, kCanDevIdx);
    LOG_WARN("Close Can device ");
    if (can0_executor_) {
      can0_executor_->join();
      can0_executor_ = nullptr;
    }
    if (can1_executor_) {
      can1_executor_->join();
      can1_executor_ = nullptr;
    }
  }
  // 启动Can驱动
  bool Init(ChannelBaudrateParam channel_baudrate) override;
  // 开始监听数据
  void Start() override;
  // 停止监听数据
  void Stop() override;
  // 消息订阅接口
  void Subscribe(int channel /* 消息通道 */, int device_id /* 消息ID */,
                 std::function<void(const VCI_CAN_OBJ)> data_callback) override;
  // 获取消息发送句柄
  std::shared_ptr<MessagePublisher> Advertise(int channel,
                                              int device_id) override;

  // 重启can驱动
  bool ReStart(ChannelBaudrateParam channel_baudrate);

  inline void SetState(MessageCenterState state) { state_ = state; }

  // 查询can数据接收是否超时
  inline bool CheckDataTimeout() {
    if (ros::Time::now() - can0_last_rx_time_ > ros::Duration(kCanRxTimeout)) {
      can0_data_timeout_ = true;
    } else {
      can0_data_timeout_ = false;
    }

    if (ros::Time::now() - can1_last_rx_time_ > ros::Duration(kCanRxTimeout)) {
      can1_data_timeout_ = true;
    } else {
      can1_data_timeout_ = false;
    }

    return can0_data_timeout_ && can1_data_timeout_;
  }

  inline bool SendCan0MsgBuffer() {
    if (0 == can0_send_buf_.size()) {
      // LOG_WARN("can0 send buffer is empty!");
      return true;
    }
    // 异常状态 不发送can数据
    if (state_ != MessageCenterState::ACTIVE) return true;

    if (can0_send_buf_.size() >= kCanTxBuffSize) {
      LOG_WARN("can0 send buffer size: %zu", can0_send_buf_.size());
      can0_send_buf_.clear();
      return false;
    }
#if 0
    LOG_WARN_STREAM("can0 send buffer size: " << can0_send_buf_.size());
#endif
    if (!SendCanMsg(kCanChannel0, can0_send_buf_.data(),
                    can0_send_buf_.size())) {
      LOG_ERROR("send can0 msg failed");
      return false;
    }
    can0_send_buf_.clear();
    return true;
  }

  inline bool SendCan1MsgBuffer() {
    if (0 == can1_send_buf_.size()) {
      // LOG_WARN("can1 send buffer is empty!");
      return true;
    }
    // 异常状态 不发送can数据
    if (state_ != MessageCenterState::ACTIVE) return true;

    if (can1_send_buf_.size() >= kCanTxBuffSize) {
      LOG_WARN("can1 send buffer size: %zu", can1_send_buf_.size());
      can1_send_buf_.clear();
      return false;
    }
#if 0
    LOG_WARN_STREAM("can1 send buffer size: " << can1_send_buf_.size());
#endif
    if (!SendCanMsg(kCanChannel1, can1_send_buf_.data(),
                    can1_send_buf_.size())) {
      LOG_ERROR("send can1 msg failed");
      return false;
    }
    can1_send_buf_.clear();
    return true;
  }

 private:
  // 向can发送缓存中填充数据
  bool WriteAndFlush(int channel, int can_id, const unsigned char *data,
                     unsigned char data_length) override;

  // 发送can帧数据接口
  inline bool SendCanMsg(unsigned channel, VCI_CAN_OBJ *can_msg,
                         unsigned int cnt) {
    if (cnt != VCI_Transmit(kCanDevType, kCanDevIdx, channel, can_msg, cnt)) {
      return false;
    }
    return true;
  }

  void Can0ReceiveThread();
  void Can1ReceiveThread();

  unsigned int GetChannelBaudrateFromMap(int baud_config);

  // Can的消息回调处理接口
  // 该接口根据收到的设备ID找对应的处理回调，如果不存在则直接丢掉
  // 但是应该在Can驱动层主动过滤掉不需要的数据
  void MessageCallback(int channel, int device_id,
                       const VCI_CAN_OBJ data) override;
  // 单例实现
  DECLARE_SINGLETON(CanMessageCenter);
  // 单例模式私有化掉构造
  CanMessageCenter()
      : state_(MessageCenterState::UNINITIALIZED),
        thread_pool_(kThreadSize),
        can0_data_timeout_(false),
        can1_data_timeout_(false) {
    channel_baudrate_map_.emplace(50, kCanBaudrate50);
    channel_baudrate_map_.emplace(125, kCanBaudrate125);
    channel_baudrate_map_.emplace(250, kCanBaudrate250);
    channel_baudrate_map_.emplace(500, kCanBaudrate500);
    channel_baudrate_map_.emplace(1000, kCanBaudrate1000);
  }
  // 设备消息通道0订阅列表
  std::map<int /* 设备ID */,
           std::function<void(const VCI_CAN_OBJ)> /* 消息处理回调 */>
      subscriber_map_channel0_;

  // 设备消息通道1订阅列表
  std::map<int /* 设备ID */,
           std::function<void(const VCI_CAN_OBJ)> /* 消息处理回调 */>
      subscriber_map_channel1_;

  // 状态
  MessageCenterState state_;
  // 使用线程池处理Can的回调消息
  ThreadPool thread_pool_;
  // 发送缓存
  std::vector<VCI_CAN_OBJ> can0_send_buf_;
  std::vector<VCI_CAN_OBJ> can1_send_buf_;

  std::shared_ptr<std::thread> can0_executor_;
  std::shared_ptr<std::thread> can1_executor_;
  std::map<int, unsigned int> channel_baudrate_map_;
  bool can0_data_timeout_;
  ros::Time can0_last_rx_time_;
  bool can1_data_timeout_;
  ros::Time can1_last_rx_time_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_CAN_MESSAGE_CENTER_H_
