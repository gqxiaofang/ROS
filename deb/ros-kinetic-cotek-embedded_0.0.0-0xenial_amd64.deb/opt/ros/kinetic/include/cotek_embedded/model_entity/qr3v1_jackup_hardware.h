/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_QR3V1_JACK_UP_HARDWARE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_QR3V1_JACK_UP_HARDWARE_H_
#include "cotek_embedded/model_entity/jack_up_hardware.h"
namespace cotek_embedded {

// 继承顶升车类
class Qr3v1JackUpHardware : public JackUpHardware {
 public:
  Qr3v1JackUpHardware();

  virtual ~Qr3v1JackUpHardware() {}

  /**
   * 输出给其他节点
   */
  // void PublishSafetyIoStateMsg() {}
  // void PublishHalMsg();
  JackUpDownState GetJackUpDownState(bool up1, bool up2, bool down1,
                                     bool down2);
  void SetControl();
  void UpdateFeedbackData();
  void UpdateBumperIOInfo();
  void SetAvoidDo(bool ChannelI, bool ChannelII, bool ChannelIII,
                  bool ChannelIV, bool ChannelV);
  void SetAvoidMap();
  void InputSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr &safety_setting);
  void UpdateAvoidLevel();

 private:
  ros::Time lift_stamp_;
  bool first_init_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_QR3V1_JACK_UP_HARDWARE_H_
