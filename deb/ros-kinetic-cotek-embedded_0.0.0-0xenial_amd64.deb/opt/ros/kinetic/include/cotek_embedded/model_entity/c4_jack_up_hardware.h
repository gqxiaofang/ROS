/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_C4_JACK_UP_HARDWARE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_C4_JACK_UP_HARDWARE_H_
#include "cotek_embedded/model_entity/jack_up_hardware.h"
namespace cotek_embedded {

// 继承顶升车类
class C4JackUpHardware : public JackUpHardware {
 public:
  C4JackUpHardware();

  virtual ~C4JackUpHardware() {}

  /**
   * 输出给其他节点
   */
  // void PublishIoStateMsg();
  // void PublishSafetyIoStateMsg() {}
  // void PublishHalMsg();
  void UpdatePalletIOInfo();
  JackUpDownState GetJackUpDownState(bool up1, bool up2, bool down1,
                                     bool down2);
  void UpdatePalletActInfo();
  void SetControl();
  void UpdateFeedbackData();
  void UpdateBumperIOInfo();
  void SetRemoteManualControl(cotek_embedded::xbox_map key_type);
  void ClearRemoteManualData();

 private:
  ros::Time lift_stamp_;
  bool first_init_;
  xbox_map last_data;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_JACK_UP_HARDWARE_H_
