/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_LINDE_FORKLIFT_HARDWARE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_LINDE_FORKLIFT_HARDWARE_H_
#include <angles/angles.h>

#include "cotek_embedded/model_entity/model/hardware_interface.h"
#include "cotek_msgs/charge_do_state.h"
#include "cotek_msgs/linde_mode_debug.h"
#include "cotek_msgs/pallet_fork_io_state.h"

namespace cotek_embedded {

// 自行车模型的车体硬件抽象模型实现类
class LinDeForkliftHardware : public HardwareInterface {
 public:
  LinDeForkliftHardware();

  virtual ~LinDeForkliftHardware() {}

  /**
   * 其他节点输入
   */
  // 输入导航控制数据,调用运动模型接口解算成相应电机速度, 发送给相应设备
  void InputMoveCmdMsg(const cotek_msgs::move_cmd::ConstPtr& move_cmd) override;

  void InputSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr& safety_setting) override;

  void InputActionMsg(
      const cotek_msgs::jack_up_action::ConstPtr& jack_up_action) override {
    LOG_WARN_STREAM("this forklift hardware can't do jack up action.");
  }

  void InputActionMsg(
      const cotek_msgs::forklift_action::ConstPtr& forklift_action);

  void InputDriverModeDebug(const cotek_msgs::linde_mode_debug::ConstPtr& mode);

  /**
   * 输出给其他节点
   */
  void PublishMoveFeedbackMsg() override;
  void PublishIoStateMsg() override;
  void PublishSafetyIoStateMsg() override;
  void PublishOdmetryMsg() override;
  void PublishImuMsg() override;
  void PublishHalMsg() override;

  void SetControl() override;
  void UpdateFeedbackData() override;

  void ClearControlData() override;

 private:
  // 北洋避障
  void SetAvoidMap();
  AvoidLevel GetAvoidLevel(bool level_I, bool level_II, bool level_III);

  // IO相关
  ForkStateType GetForkUpDownState(uint8_t up_down);
  ForkPalletState GetForkPalletState(bool);
  ForkPalletState GetForkPalletState(bool middle, bool left, bool right);
  ForkLegCheckType GetForkLegCheck(bool left, bool right);

  // ROS 标准虚拟设备
  Imu ros_imu_driver_;
  Odom ros_odom_driver_;
  tf::TransformBroadcaster tf_odom_broadcaster_;
  ros::Publisher ros_odom_pub_;
  ros::Publisher ros_imu_pub_;

  ros::Time last_move_cmd_time_;
  ros::Time last_action_cmd_time_;

  ros::Publisher move_feedback_pub_;
  ros::Publisher pallet_fork_io_state_pub_;
  ros::Publisher safety_io_state_pub_;
  ros::Publisher charge_do_state_pub_;

  ros::Publisher battery_pub_;
  ros::Publisher manual_pub_;
  ros::Publisher load_state_pub_;

  ros::Subscriber linde_mode_debug_sub_;
};

}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_LINDE_FORKLIFT_HARDWARE_H_
