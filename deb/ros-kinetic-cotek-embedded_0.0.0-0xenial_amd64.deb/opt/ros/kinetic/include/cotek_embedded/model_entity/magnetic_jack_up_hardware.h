/**
 * Copyright (c) 2019 CoTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MAGNETIC_JACK_UP_HARDWARE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MAGNETIC_JACK_UP_HARDWARE_H_
#include "cotek_embedded/model_entity/model/hardware_interface.h"
#include "cotek_msgs/charge_do_state.h"
#include "cotek_msgs/jack_up_io_state.h"
#include "cotek_msgs/mls_navigation.h"

namespace cotek_embedded {
enum class MoveDirect : uint8_t { NONE = 0, FORWARD = 1, BACKWARD = 2 };

class MagneticJackUpHardware : public HardwareInterface {
 public:
  MagneticJackUpHardware();

  virtual ~MagneticJackUpHardware() {}

  /**
   * 其他节点输入
   */
  // 输入导航控制数据,调用运动模型接口解算成相应电机速度, 发送给相应设备
  void InputMoveCmdMsg(const cotek_msgs::move_cmd::ConstPtr& move_cmd) override;

  void InputSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr& safety_setting) override;

  void InputActionMsg(
      const cotek_msgs::jack_up_action::ConstPtr& jack_up_action) override;
  void InputActionMsg(
      const cotek_msgs::forklift_action::ConstPtr& forklift_action) override {
    // nothing to do
  }

  /**
   * 输出给其他节点
   */
  void PublishMoveFeedbackMsg() override;
  void PublishIoStateMsg() override;
  void PublishSafetyIoStateMsg() override;
  void PublishOdmetryMsg() override;
  void PublishImuMsg() override;
  void PublishHalMsg() override;

  void SetControl() override;
  void UpdateFeedbackData() override;

  void ClearControlData() override;
  inline void SetMoveDirect(MoveDirect dir) { move_direct_ = dir; }
  inline MoveDirect GetMoveDirect() { return move_direct_; }

 private:
  // vitural avoid map
  void SetAvoidMap();
  AvoidLevel GetAvoidLevel(bool level_I, bool level_II, bool level_III);
  void SetRemoteManualControl(bool forward, bool backward, bool left,
                              bool right, bool up, bool down);
  MoveDirect move_direct_;
  // about IO state
  JackUpDownState GetJackUpDownState(bool up1, bool up2, bool down1,
                                     bool down2);
  JackUpZeroType GetJackupZeroType(bool z1, bool z2);
  cotek_msgs::move_feedback GetFeedbackMsg();
  // about pallet lifting heigth
  float GetLiftHeigth();
  float liftheigth_;

  void LedProcess(uint8_t type);
  void SetAvoidDo(bool ChannelI, bool ChannelII, bool ChannelIII,
                  bool ChannelIV, bool ChannelV);

  // ROS standard virtual device
  Imu ros_imu_driver_;
  Odom ros_odom_driver_;

  tf::TransformBroadcaster tf_odom_broadcaster_;
  ros::Publisher ros_odom_pub_;
  ros::Publisher ros_imu_pub_;

  ros::Time last_move_cmd_time_;
  ros::Time last_action_cmd_time_;

  ros::Publisher move_feedback_pub_;
  ros::Publisher jack_up_io_state_pub_;
  ros::Publisher safety_io_state_pub_;

  ros::Publisher battery_pub_;
  ros::Publisher manual_pub_;
  ros::Publisher load_state_pub_;
  ros::Publisher forward_mls_navigation_pub_;
  ros::Publisher backward_mls_navigation_pub_;
  ros::Publisher charge_do_state_pub_;
  ros::Publisher pallet_act_info_pub_;

  ros::Time lift_stamp_;
  bool first_init_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MAGNETIC_JACK_UP_HARDWARE_H_
