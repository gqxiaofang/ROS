/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MODEL_HARDWARE_INTERFACE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MODEL_HARDWARE_INTERFACE_H_
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <tf/tf.h>
#include <tf/transform_broadcaster.h>

#include <map>
#include <memory>
#include <string>

#include "cotek_common/common.h"
#include "cotek_common/cotek_config_helper.h"
#include "cotek_common/cotek_enum_type.h"
#include "cotek_common/cotek_topic_name.h"
#include "cotek_common/device_table_loader.h"
#include "cotek_common/dongle/io_dongle.h"
#include "cotek_common/dongle/universal_dongle.h"
#include "cotek_common/io_index.h"
#include "cotek_common/math.h"
#include "cotek_embedded/data_holder.h"
#include "cotek_embedded/device_driver/abstract_driver.h"
#include "cotek_embedded/device_driver/audio_driver.h"
#include "cotek_embedded/device_driver/battery_baoe_driver.h"
#include "cotek_embedded/device_driver/battery_rebot_driver.h"
#include "cotek_embedded/device_driver/battery_zl_driver.h"
#include "cotek_embedded/device_driver/bmmsk34_encoder_driver.h"
#include "cotek_embedded/device_driver/curtis1222_driver.h"
#include "cotek_embedded/device_driver/curtis_driver.h"
#include "cotek_embedded/device_driver/dongle_driver.h"
#include "cotek_embedded/device_driver/gyro_memsplus_driver.h"
#include "cotek_embedded/device_driver/gyro_rion_driver.h"
#include "cotek_embedded/device_driver/hikvs_driver.h"
#include "cotek_embedded/device_driver/hinson_mls_driver.h"
#include "cotek_embedded/device_driver/io_driver.h"
#include "cotek_embedded/device_driver/joy_stick.h"
#include "cotek_embedded/device_driver/ks103_driver.h"
#include "cotek_embedded/device_driver/linde_kob_driver.h"
#include "cotek_embedded/device_driver/low_power_driver.h"
#include "cotek_embedded/device_driver/motor_motec_driver.h"
#include "cotek_embedded/device_driver/motor_syntron_driver.h"
#include "cotek_embedded/device_driver/pgv100_driver.h"
#include "cotek_embedded/device_driver/pgv_r2100_driver.h"
#include "cotek_embedded/device_driver/rfid_driver.h"
#include "cotek_embedded/device_driver/ros_virtual_driver/imu.h"
#include "cotek_embedded/device_driver/ros_virtual_driver/odom.h"
#include "cotek_embedded/device_driver/sick_mls_driver.h"
#include "cotek_embedded/device_driver/single_line_laser_driver.h"
#include "cotek_embedded/device_driver/ultarsonic_driver.h"
#include "cotek_embedded/device_driver/valve_driver.h"
#include "cotek_embedded/device_driver/weighing_driver.h"
#include "cotek_embedded/model_entity/model/move_model_interface.h"
#include "cotek_msgs/audio_feedback.h"
#include "cotek_msgs/battery.h"
#include "cotek_msgs/battery_baoe_feedback.h"
#include "cotek_msgs/battery_rebot_feedback.h"
#include "cotek_msgs/battery_zl_feedback.h"
#include "cotek_msgs/bmmsk34_encoder_feedback.h"
#include "cotek_msgs/charge_do_state.h"
#include "cotek_msgs/curtis_feedback.h"
#include "cotek_msgs/dongle_feedback.h"
#include "cotek_msgs/forklift_action.h"
#include "cotek_msgs/gyro_rion_feedback.h"
#include "cotek_msgs/hikvs_feedback.h"
#include "cotek_msgs/hinson_mls_feedback.h"
#include "cotek_msgs/io_feedback.h"
#include "cotek_msgs/jack_up_action.h"
#include "cotek_msgs/jack_up_io_state.h"
#include "cotek_msgs/ks103_feedback.h"
#include "cotek_msgs/linde_kob_feedback.h"
#include "cotek_msgs/load_state.h"
#include "cotek_msgs/manual.h"
#include "cotek_msgs/motor_syntro_feedback.h"
#include "cotek_msgs/pallet_act_info.h"
#include "cotek_msgs/pallet_detect_state.h"
#include "cotek_msgs/pgv100_feedback.h"
#include "cotek_msgs/pgv_r2100_feedback.h"
#include "cotek_msgs/power_supply.h"
#include "cotek_msgs/rfid_feedback.h"
#include "cotek_msgs/safety_io_state.h"
#include "cotek_msgs/safety_setting.h"
#include "cotek_msgs/safety_state.h"
#include "cotek_msgs/single_line_laser_feedback.h"
#include "cotek_msgs/ultarsonic_feedback.h"
#include "cotek_msgs/valve_feedback.h"
#include "cotek_msgs/weighing_feedback.h"

namespace cotek_embedded {

// 硬件抽象层接口接口，将业务数据转化为驱动数据并发送给执行机构执行
// 通过该接口封装底层数据逻辑，对外可以走ROS消息总线，也可以直接集成至主程序(Navigation)
// 接口都按照异步方式实现，请组合状态查询接口使用
// 当前可知的对底层硬件的控制接口如下，这些接口的业务实现可能会驱动多个底层设备组合实现
// 如有未考虑到的控制接口请及时更新本接口
class HardwareInterface {
 public:
  // 初始化底层驱动，该接口的实现类需要实现设备驱动的维护列表
  // 实现时务必确保异步实现
  bool InitDrivers();

  // 查询驱动是否就绪
  // 配合InitDirvers()接口实现
  bool IsDriversReady();

  // 通过驱动设备名称检查驱动是否就绪
  bool CheckDriverReadyByName(const std::string& name);

  // 通过驱动设备名称重置驱动
  // 这个重置过程可能是由另外个驱动设备来完成的，需要注意驱动重置后的状态重置和就绪检测
  // 如重置CURTIS驱动器，如果由继电器驱动重置则得检查CURTIS驱动的状态
  void ResetDriverByName(const std::string& name);

  inline const std::map<std::string, std::shared_ptr<AbstractDriver>>&
  DriverMap() {
    return driver_map_;
  }

  // 设置运动模型 (bicycle, unicycle) --> 用来解算导航数据
  inline void SetMoveModel(MoevModelType model_type,
                           const MoveModelOption& option) {
    switch (model_type) {
      case MoevModelType::BICYCLE: {
        move_model_ =
            std::make_shared<MoveBicycleModel>(option.bicycle_model_option);
        break;
      }
      case MoevModelType::UNICYCLE: {
        move_model_ =
            std::make_shared<MoveUnicycleModel>(option.unicycle_model_option);
        break;
      }
      case MoevModelType::UNKONW: {
        break;
      }
    }
    move_control_option_ = option.movemode_control_option;
    move_model_->SetControlOption(move_control_option_);
  }

  inline const std::shared_ptr<MoveModelInterface> MoveModel() {
    return move_model_;
  }

  /**
   * 其他节点输入: move_cmd 和 safety_setting 所有车型统一
   */
  // 输入导航控制数据,调用运动模型接口解算成相应电机速度, 发送给相应设备
  virtual void InputMoveCmdMsg(
      const cotek_msgs::move_cmd::ConstPtr& move_cmd) = 0;

  virtual void InputSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr& safety_setting) = 0;
  // 不同车型动作重载接口
  virtual void InputActionMsg(
      const cotek_msgs::forklift_action::ConstPtr& forklift_action) = 0;
  virtual void InputActionMsg(
      const cotek_msgs::jack_up_action::ConstPtr& jack_up_action) = 0;

  /**
   * 输出给其他节点: move_feedback 所有车型统一
   */
  void PublishSensorFeedbackMsg();
  virtual void PublishMoveFeedbackMsg() = 0;
  virtual void PublishIoStateMsg() = 0;
  virtual void PublishSafetyIoStateMsg() = 0;
  virtual void PublishOdmetryMsg() = 0;
  virtual void PublishImuMsg() = 0;
  virtual void PublishHalMsg() = 0;

  // 各车型根据 自身 data_holder 里的数据控制底层硬件
  virtual void SetControl() = 0;
  // 将各底层硬件数据 存放到 data_holder
  virtual void UpdateFeedbackData() = 0;

  // 清除控制数据, 以防止没有话题后,车子根据之前的控制命令继续执行
  virtual void ClearControlData() = 0;

  // 控制选项
  MoveModelControl GetControlOption() { return move_control_option_; }

 private:
  // 设备驱动表
  std::map<std::string /* 设备名称 */,
           std::shared_ptr<AbstractDriver> /* 设备驱动 */>
      driver_map_;

  std::shared_ptr<MoveModelInterface> move_model_;

  std::map<std::string, ros::Publisher> sensor_feedback_pub_;

  MoveModelControl move_control_option_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_MODEL_HARDWARE_INTERFACE_H_
