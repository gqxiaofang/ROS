/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_TRANSPLANT_HARDWARE_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_TRANSPLANT_HARDWARE_H_
#include "cotek_embedded/model_entity/model/hardware_interface.h"

namespace cotek_embedded {

// 独轮车模型的车体硬件抽象模型实现类
class TransplantHardware : public HardwareInterface {
 public:
  TransplantHardware();

  virtual ~TransplantHardware() {}

  /**
   * 其他节点输入
   */
  // 输入导航控制数据,调用运动模型接口解算成相应电机速度, 发送给相应设备
  void InputMoveCmdMsg(
      const cotek_msgs::move_cmd::ConstPtr& move_cmd) override {}

  void InputSafetySettingMsg(
      const cotek_msgs::safety_setting::ConstPtr& safety_setting) override {}

  void InputActionMsg(
      const cotek_msgs::jack_up_action::ConstPtr& jack_up_action) override {
    // nothing to do
  }
  void InputActionMsg(
      const cotek_msgs::forklift_action::ConstPtr& forklift_action) override {
    // nothing to do
  }

  /**
   * 输出给其他节点
   */
  void PublishMoveFeedbackMsg() override {}
  void PublishIoStateMsg() override {}
  void PublishSafetyIoStateMsg() override {}
  void PublishOdmetryMsg() override {}
  void PublishImuMsg() override {}
  void PublishHalMsg() override {}

  void SetControl() override {}
  void UpdateFeedbackData() override {}

  void ClearControlData() override {}

 private:
  AgvType agv_type_;
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_TRANSPLANT_HARDWARE_H_
