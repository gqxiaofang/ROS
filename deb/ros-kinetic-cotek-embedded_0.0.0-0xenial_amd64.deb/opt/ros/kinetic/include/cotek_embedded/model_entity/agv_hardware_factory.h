/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_AGV_HARDWARE_FACTORY_H_
#define COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_AGV_HARDWARE_FACTORY_H_

#include "cotek_common/cotek_enum_type.h"
#include "cotek_common/util/factory.h"
#include "cotek_common/util/singleton.h"
#include "cotek_embedded/model_entity/c4_jack_up_hardware.h"
#include "cotek_embedded/model_entity/forklift_hardware.h"
#include "cotek_embedded/model_entity/heap_forklift_hardware.h"
#include "cotek_embedded/model_entity/jack_up_hardware.h"
#include "cotek_embedded/model_entity/linde_forklift_hardware.h"
#include "cotek_embedded/model_entity/magnetic_jack_up_hardware.h"
#include "cotek_embedded/model_entity/model/hardware_interface.h"
#include "cotek_embedded/model_entity/nuo_li_pallet_forklift_hardware.h"
#include "cotek_embedded/model_entity/qr3v1_jackup_hardware.h"
#include "cotek_embedded/model_entity/reach_forklift_hardware.h"
#include "cotek_embedded/model_entity/tractor_car_hardware.h"
#include "cotek_embedded/model_entity/transplant_hardware.h"
#include "cotek_embedded/model_entity/xp1_forklift_hardware.h"
#include "cotek_embedded/model_entity/zhongli_jack_up_hardware.h"
#include "cotek_embedded/model_entity/xinmei_forklift_hardware.h"

namespace cotek_embedded {
class AgvHardwareFactory : public util::Factory<AgvType, HardwareInterface> {
 public:
  void RegisterAgvHardwares();

  std::unique_ptr<HardwareInterface> CreateAgvHardware(
      const AgvType& agv_type, const MoveModelOption& move_model_option);

 private:
  DECLARE_SINGLETON(AgvHardwareFactory)
  AgvHardwareFactory() {}
};
}  // namespace cotek_embedded

#endif  // COTEK_EMBEDDED_INCLUDE_COTEK_EMBEDDED_MODEL_ENTITY_AGV_HARDWARE_FACTORY_H_