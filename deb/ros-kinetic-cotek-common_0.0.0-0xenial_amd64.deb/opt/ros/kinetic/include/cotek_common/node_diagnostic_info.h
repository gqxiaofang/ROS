/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_NODE_DIAGNOSTIC_INFO_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_NODE_DIAGNOSTIC_INFO_H_
#include <cotek_msgs/node_diagnostic.h>

namespace cotek_diagnostic {

// 节点监控枚举
enum class CommunicateNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  TIMEOUT = 2,
  // 警告(自行增加)
  MSG_TYPE_ABNORMAL = 21
};

enum class DecisionMakerNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  TASK_SEQUENCE_NUMBER_ERROR = 2,
  TASK_ORDER_ID_ERROR = 3,
  TASK_SEQUENCE_ID_ERROR = 4,
  TASK_TYPE_ERROR = 5,
  DONGLE_DIED = 6
  // 警告(自行增加)
};

enum class EmbeddedNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  CAN_INIT_ERROR = 2,
  AGV_HARDWARE_INIT_ERROR = 3,
  CAN_0_SEND_ERROR = 4,
  CAN_1_SEND_ERROR = 5,
  CAN_RECEIVE_TIME_OUT = 6,
  // 警告(自行增加)
  CAN_CYCLE_TIME_OUT = 21
};

enum class LocalizerNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  GET_LANDMARK_MAP_ERROR = 2,
  INIT_FAILED = 3,
  LASER_MESSAGE_EMPTY = 10,
  STATIC_LOCALIZER_ERROR = 11,
  GET_POSE_ERROR = 12,
  LOCALIZER_INIT_POSE_ERROR = 19,
  // 警告(自行增加)
  REFLECTOR_MATCH_WARING = 21,  // 反光板匹配 < 3个
  MISS_REFLETOR = 22  // 反光板丢失 error_info 为丢失反光板id
};

enum class ReflectorNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  GET_REFLECTOR_MAP_ERROR = 2,
  LASER_MESSAGE_EMPTY = 10,
  STATIC_LOCALIZER_ERROR = 11,
  GET_POSE_ERROR = 12,
  // 警告(自行增加)
  REFLECTOR_MATCH_WARING = 21  // 反光板匹配 < 3个
};

enum class CalibrationNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  GET_REFLECTOR_MAP_ERROR = 2,
  LASER_MESSAGE_EMPTY = 11,
  GET_POSE_ERROR = 12,
  // 警告(自行增加)
  REFLECTOR_MATCH_WARING = 21  // 反光板匹配 < 3个
};

enum class NavigationNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  OUT_OF_THE_ROUTE = 2,
  // 警告(自行增加)
  POWERON_INIT_TIME_OUT = 3
};

enum class AvoidNodeStatus : uint16_t {
  NORMAL = 0,
  // 错误(自行增加)
  CONFIG_ERROR = 1,
  BUMP_ERROR = 2,
  AVOID_MAP_ERROR = 3,
  // 警告(自行增加)
  AVOID_TIME_OUT = 21,
  FORK_LEG_AVOID = 22,
  LASER_SENSOR_PROTECT = 23,
  ULTRASOUND_AVOID = 24,
  UP_FORWARD_AVOID = 25  // 顶上前向激光避障
};

enum class ActionNodeStatus : uint16_t {
  NORMAL = 0,
  AGV_TYPE_ERR = 1,
  ACTION_TYPE_ERR = 2,
  BAD_PARAMETER_ERR = 3,
  ACTION_TIME_OUT = 4,
  PALLET_DOWN_ERR = 5,
  PALLET_ROTATE_ERR = 6,
  CHARGE_ERR = 7,
  CHARGE_TIMEOUT_ERR = 8,
  ACTION_NODE_TIMEOUT_ERR = 9,
  PALLET_ZERO_ERR = 10,
  PALLET_MOVE_ERR = 11,
  EXCEPTION_NO_PALLET_ERR = 12,
  PALLET_DETECT_ERROR = 13,
};

struct diagnostic {
  uint32_t time_stamp;
  uint16_t status;
};

}  // namespace cotek_diagnostic

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_NODE_DIAGNOSTIC_INFO_H_
