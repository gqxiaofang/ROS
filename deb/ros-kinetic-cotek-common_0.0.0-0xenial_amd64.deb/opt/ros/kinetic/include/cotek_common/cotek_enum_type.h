/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_ENUM_TYPE_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_ENUM_TYPE_H_
#include <iostream>

#include "cotek_common/log_porting.h"

#define BIT_0 0
#define BIT_1 1
#define NO_LANDMARK 0

enum class AgvType : uint32_t {
  UNKONW = 0,
  FORKLIFT = 1,
  JACK_UP = 2,
  TRANSPLANT = 3,
  HEAP_FORKLIFT = 4,
  LINDE_FROKLIFT = 5,
  NUOLI_FROKLIFT = 6,
  TRACTOR_CAR = 7,
  REACH_FORKLIFT = 8,
  MAGNETC_JACK_UP = 9,
  ZHONGLI_2T_JACK_UP = 10,
  C4_JACK_UP = 11,
  QR3V1_JACKUP = 12,
  XP1_FROKLIFT = 13,
  XINMEI_FORKLIFT = 14
};

// 交互中的数据标准单位：m, m/s, A,V; 设备_feedback.msg除外 --》
// 通过业务转化为标准单位

// 调度任务相关业务枚举
namespace dispacth {
// 导航类型 1:激光导航 2:二维码导航 3:磁条导航
enum class NaviType : int32_t { NONE = 0, FREE = 1, QR_CODE = 2, MAGNETIC = 3 };

// 移动类型 1:严格跟踪路径, 2:移动至目标姿态，不关心中间过程, 3:自由移动
enum class MoveType : int32_t { NONE = 0, TRACKPATH = 1 };

// Step类型，用于区分移动还是操作，并统一这两者数据结构。1:移动至目标点, 2:操作,
// 3:边移动边操作, 4:终止点, 5:起始点
enum class StepType : int32_t {
  NONE = 0,
  MOVE = 1,
  OPERATION = 2,
  MOVE_OPERATION = 3,
  END_POINT = 4,
  START_POINT = 5
};

// 路径类型 1:点, 2:直线, 3:曲线, 4:圆弧, 5:旋转
enum class PathType : int32_t {
  NONE = 0,
  POINT = 1,
  STRAIGHT_LINE = 2,
  B_SPLINE_CURVES = 3,
  ARC = 4,
  ROTATE = 5
};

// 避障策略码
enum class AvoidMapType : int {
  INIT = 0,
  AVOID_DIY_MAP_23 = 23,
  AVOID_DIY_MAP_24 = 24,
  AVOID_DIY_MAP_25 = 25,  // 避障减弱
  NONE = 26,              // 无避障
  BACK_LEFT = 27,         // 后退右转
  BACK_RIGHT = 28,        // 后退左转
  FORWARD_LEFT = 29,      // 前进左转
  FORWARD_RIGHT = 30,     // 前进右转
  FORWARD = 31            // 直行避障
};

// agv任务动作类型
enum class AgvTaskOperationType : uint32_t {
  NONE = 0,
  REST = 1,
  UP = 2,    // 抬货  (value=0:直接抬, value=1:需要抬货检测)
  DOWN = 3,  // 放货  (value=0:直接放, value=1:需要放货检测)
  HEIGHT_FORK_MOVE = 4,  // 叉腿高度移动  (operation_value 填 控制高度)
  CHARGE = 5,            // 自动充电 (operation_value: 0=关, 1=开)
  SELECT_DIR = 6,  // 选择磁条方向 (operation_value: 0=正前 1=左 2=右)
  PALLET_ROTATE = 7,  // 托盘旋转　（operation_value：-180~180 旋转角度）
  LOW_POWER_MODE = 9,  // 进入低功耗模式 (operation_value 填 0(关), 1(开))
  LATERAL_FORK_MOVE = 10,  // 前移叉腿移动(operation_value 填 前移量)
  PALLET_DETECT_BEFORE_UP =
      11,  // 抬货前托盘检测 (operation_value 填 检测地图类型)
  PALLET_DETECT_BEFORE_DOWN =
      12,  // 抬货前托盘检测 (operation_value 填 检测地图类型)
  DELAY = 13,                // 延时动作(operation_value 填延迟时间/s)
  PALLET_CORRECT = 14,  // 托盘整定后进行纠正
  AUDIO_LEVEL_CONTROL = 22,  // 音频音量调节(operation_value 填 音量值0~30)
  AUDIO_TYPE_CONTROL = 23,  // 音频类型调节(operation_value 填 值0~12)

  FORK_DELAY = 24,  // 延时

  /* -------decision maker 复合动作解析后的子任务
  ex: 顶升的抬货包含UP与PALLET_NOMOVE等多个动作 ---------*/

  CHECK_UP_WEIGHT = 51,  // 抬货重量检测(operation_value 填 值货物重量)
  CHECK_DOWN_WEIGHT = 52,  // 卸货重量检测(operation_value 填 值货物重量)

  CLAMP_COMPRESS = 53,  // 夹抱装置夹紧(operation_value 填)
  CLAMP_RELEASE = 54,   //  夹抱装置释放(operation_value 填)

  INIT = 99,

  /* -------顶升车子任务(100~199) ---------*/
  PALLET_NOMOVE =
      100,  // 托盘动态调整姿态保持对地静止(value:0=无，1=直行,2=旋转)
  PALLET_ZERO = 101,  // 托盘归零
  /* 电机失能(value: 1=左，2=右，４=顶升，8=旋转　多电机累加)*/
  MOTOR_DISABLE = 102,
  /* 电机使能(value: 1=左，2=右，４=顶升，8=旋转　多电机累加) */
  MOTOR_ENABLE = 103,
  MOTOR_CLEARALARM = 104,  // 消除电机报警
  WAIT = 105,  // 动作等待(value:1=进入等待，0=退出恢复原来动作,其他:等待时间）
};
}  // namespace dispacth

// 导航相关业务枚举
namespace navigation {
// 导航移动类型
enum class MotionType : uint32_t {
  NONE = 0,
  START_POINT = 1,
  LINE = 2,
  BCURVE = 3,
  ARC = 4,
  FORKVAN = 5,
  ROTATE = 10,
  CHARGE = 11,
  UPSTABILIZE = 12,
  DOWNSTABILIZE = 13,
  FIND_2_RFID = 14,
  CAR_BACK = 15,
  SWITCH_MAP = 20,
  POWERON_SHAKING = 21  //
};
}  // namespace navigation

// 动作相关业务枚举
namespace action {
// 原子动作 cotek_action_node -> cotek_embedded_node
enum class AtomicActionType : uint32_t {
  /* -------通用原子动作 (0-99) ---------*/
  REST = 0,
  NONE = 1,
  UP = 2,      // 抬升(高度)  (operation_value 填 速度值)
  DOWN = 3,    // 下降(高度)  (operation_value 填 速度值)
  CHARGE = 4,  // 充电 (operation_value 填0(关), 1(开))
  BEEP = 5,
  WAIT = 10,  // 状态暂存，动作暂停等待（operation_value 填0(关), 1(开)）

  LOW_POWER_MODE = 99,  // 低功耗 (operation_value 填0(关), 1(开))
  /* -------叉车类动作 (100 -199) ---------*/
  LATERAL_FORK_FORWARD = 101,  // 水平叉腿前移(operation_value 填 速度值)
  LATERAL_FORK_BACKWARD = 102,  // 水平叉腿后移(operation_value 填 速度值)
  LATERAL_FORK_LEFT = 103,  // 水平叉腿左移(operation_value 填 速度值)
  LATERAL_FORK_RIGHT = 104,  // 水平叉腿右移(operation_value 填 速度值)

  PALLET_DETECT = 105,  // 库位托盘检测 (operation_value 填 1)

  STEERING_RESET = 111,  // 舵轮电机继电器打开  (operation_value 填0(关), 1(开))
  STEERING_BRAKE = 112,  // 舵轮电机电机报闸  (operation_value 填0(关), 1(开))
  // 测试类动作
  TEST_STEERING_ANGLE = 151,  //
  TEST_CONTROL = 152,

  /* -------顶升类动作 (200 -299) ---------*/
  PALLET_ROTATION = 201,
  PALLET_ZERO = 202,
  /* bit占位 value= 1/2/4/8：left/right/lift/rotate 电机，多个电机时叠加*/
  MOTOR_DISABLE = 203,
  MOTOR_ENABLE = 204,
  MOTOR_CLEARALARM = 205,
  PALLET_NOMOVE = 206,
  MAGNETIC_CHARGE = 207,

  LIFT_MOTOR_BREAK_CONTROL = 208,
  ROTATE_MOTOR_BREAK_CONTROL = 209,
  MOVE_MOTOR_BREAK_CONTROL = 210,

  MAGNETIC_SWITCH_DIR = 211,  // 磁条顶升切换方向

  //夹抱机构电机（clamp_right_motor_value为左电机速度，clamp_right_motor_value为右电机速度）
  CLAMP_MOTOR_CONTROL = 220
};

}  // namespace action

namespace location {

enum class LocalizerType : int32_t {
  NONE = 0,
  REFLECTOR = 1,
  QR_CODE = 2,
  RFID = 3,
  CARTO = 4,
};

}  // namespace location

// 状态机状态
enum class AgvStateType : int32_t {
  NONE = 0,
  WAITING = 1,
  DOING = 2,
  LOWPOWERMODE = 4,
  PAUSE = 5,
  MANUAL = 6, 
  FINISHING = 7,
  CHARGING = 8,
  FAULT = 9,
  EMERGENCY_PAUSE = 10,
  POWERON_SHAKING = 21
};

enum class BatteryType : uint8_t {
  NONE = 0,
  CURTIS = 1,
  BAO_E = 2,
  ZHONG_LI = 3,
  LIN_DE = 4,
  ZHI_LI = 5,
  REBOT = 6
};

// 移动模型类型
enum class MoevModelType : uint32_t { UNKONW = 0, UNICYCLE = 1, BICYCLE = 2 };
enum class ForkStateType : uint8_t { DOWN = 0, MIDDLE = 1, UP = 2 };

// 叉腿防撞检测
enum class ForkLegCheckType : uint8_t {
  NONE = 0,         // 左右都无检测
  LEFT_CHECK = 1,   // 左边检测到
  RIGHT_CHECK = 2,  // 右边检测到
  BOTH = 3          // 左右都检测到
};

// 货架检测
enum class ForkPalletState : uint8_t {
  NONE = 0,         // 左右都无检测
  LEFT_CHECK = 1,   // 左边检测到
  RIGHT_CHECK = 2,  // 右边检测到
  BOTH = 3          // 左右都检测到
};

// 载货状态
enum class LoadStateType : int32_t { UNKONW = 0, ON_LOAD = 1, NO_LOAD = 2 };

enum class AvoidMapType : int {
  INIT = 0,

  // 避障激光检测托盘 3~5m
  RIGHT_PALLET_DETECT_3M_MAP = 16,
  RIGHT_PALLET_DETECT_4M_MAP = 17,
  RIGHT_PALLET_DETECT_5M_MAP = 18,
  LEFT_PALLET_DETECT_3M_MAP = 19,
  LEFT_PALLET_DETECT_4M_MAP = 20,
  LEFT_PALLET_DETECT_5M_MAP = 21,

  AVOID_DIY_MAP_23 = 23,
  AVOID_DIY_MAP_24 = 24,
  AVOID_DIY_MAP_25 = 25,  // 避障减弱
  NONE = 26,              // 无避障
  BACK_LEFT = 27,         // 后退右转
  BACK_RIGHT = 28,        // 后退左转
  FORWARD_LEFT = 29,      // 前进左转
  FORWARD_RIGHT = 30,     // 前进右转
  FORWARD = 31            // 直行避障
};

enum class AvoidLevel : uint8_t {
  NONE = 0,                       // 无避障
  LEVEL_I = 1,                    // 避障区域 避障等级1 - slowlevel1
  LEVEL_II = 2,                   // 避障区域 避障等级2 - slowlevel2
  LEVEL_III = 3,                  // 避障区域 避障等级3 - stop
  BUMP = 4,                       // 防撞条
  FORK_LEFT_LEG = 5,              // 叉车左叉腿防撞
  FORK_RIGHT_LEG = 6,             // 叉车右叉腿防撞
  FORK_LEG_BOTH = 7,              // 叉车左右叉腿都检测到
  FORWARD_ULTRASONIC = 8,         // 前向超声波检测
  LEFT_ULTRASONIC = 9,            // 左向超声波检测
  RIGHT_ULTRASONIC = 10,          // 右向超声波检测
  UP_FORWARD_LASER_OBSTACLE = 11  // 顶上前向避障雷达检测
};

enum class AvoidSpeedLevel : uint32_t {
  FREE = 0,
  SLOWLEVEL1 = 1,
  SLOWLEVEL2 = 2,
  STOP = 3
};

enum class StateType : int {
  MANUAL = 1,     // 手动
  AUTO = 2,       // 自动
  BUMP_ERROR = 3  // 防撞触发
};

// 功耗模式
// SLEEPING: 低功耗模式
// ACTIVE: 正常功耗模式
enum class PowerMode { UNKNOWN, SLEEPING, ACTIVE };

// 顶升车托盘状态
enum class JackUpDownState {
  UP_NONE = 0,
  UP_1 = 1,
  UP_2 = 2,
  UP_BOTH = 3,
  DOWN_NONE = 4,
  DOWN_1 = 5,
  DOWN_2 = 6,
  DOWN_BOTH = 7,
};
// 顶升车托盘找零状态
enum class JackUpZeroType : uint8_t {
  ROATE_NONE = 0,
  ROATE_1 = 1,
  ROATE_2 = 2,
  ROATE_BOTH = 3,
};

enum class LoadState : uint32_t {
  UNKOWN = 0,
  HAVE_LOAD = 1,
  NO_LOAD = 2,
};

// 转向灯控制类型
enum class CorningLedType : uint8_t {
  LIGHT_OFF = 0,  //
  LIGHT_ALL_CONSTAN_ON = 1,
  LIGHT_ALL_BLINK = 2,
  LEFT_BLINK = 3,
  RIGHT_BLINK = 4
};

// 三色灯控制类型
enum class ThreeColorLedType : uint8_t {
  RED_ON = 1,     // 00000001
  YELLOW_ON = 2,  // 00000010
  GREEN_ON = 4,   // 00000100

  YELLOW_GREEN_ON = 6,  // 00000110
  RED_YELLOW_ON = 3,    // 00000011
  RED_GREEN_ON = 5,     // 00000101

  LIGHT_ALL_ON = 7,  // 00000111
  LIGHT_OFF = 0      // 00000000
};

// 先使用以下的
enum class AudioType : uint8_t {
  NONE = 0,
  BUMP_FAULT = 1,
  FORWARD = 2,
  BACKWARD = 3,
  OBSTACLE_WARN = 4,
  OBSTACLE_STOP = 5,
  LOW_BATTERY = 6,
  FORK_LEG_SAFETY = 7,
  NETWORK_TIMEOUT = 8,
  TASK_PAUSE = 9,
  LOCALIZER_ERROR = 10,
  OFF_THE_TRACK = 11,
  PALLET_DETECT_ERROR = 12,
  PICK_UP_CALL = 23,
  WARING_OCCUPATION = 31,    // 驶入授权占点区域 请驶离
  WARING_FAR_AWAY_PATH = 32  // 远离agv行驶路径
};

enum class LaserType : int { PPF = 0, SICK = 1, UAM = 2 };

enum class SwitchMapType : int {
  SWITCH_WITH_RELOCATION = 1,
  SWITCH_WITH_TARGET_POINT = 2
};

enum class ClampLimitType : uint8_t {
  NONE = 0,
  IN_LIMIT = 1,
  OUT_LIMIT_I = 2,
  OUT_LIMIT_II = 3
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_COTEK_ENUM_TYPE_H_
