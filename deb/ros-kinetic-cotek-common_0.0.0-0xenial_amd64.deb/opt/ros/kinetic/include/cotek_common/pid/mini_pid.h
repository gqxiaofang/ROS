/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_PID_MINI_PID_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_PID_MINI_PID_H_
#include <sstream>
#include <string>

#include "cotek_common/log_porting.h"

class MiniPID {
 public:
  MiniPID(double, double, double);
  MiniPID(double, double, double, double);
  void setP(double);
  void setI(double);
  void setD(double);
  void setF(double);
  void setPID(double, double, double);
  void setPID(double, double, double, double);
  void setMaxIOutput(double);
  void setOutputLimits(double);
  void setOutputLimits(double, double);
  void setDirection(bool);
  void setSetpoint(double);
  void reset();
  void setOutputRampRate(double);
  void setSetpointRange(double);
  void setOutputFilter(double);
  double getOutput();
  double getOutput(double);
  double getOutput(double, double);

  std::string toString() {
    std::stringstream ss;
    ss << "P: " << P_ << ", I: " << I_ << ", D: " << D_;
    return ss.str();
  }

 private:
  bool bounded(double, double, double);
  double clamp(double, double, double);
  void checkSigns();
  void init();
  double P_;
  double I_;
  double D_;
  double F_;

  double maxIOutput_;
  double maxError_;
  double errorSum_;

  double maxOutput_;
  double minOutput_;

  double setpoint_;

  double lastActual_;

  bool firstRun_;
  bool reversed_;

  double outputRampRate_;
  double lastOutput_;

  double outputFilter_;

  double setpointRange_;
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_PID_MINI_PID_H_
