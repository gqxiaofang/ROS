/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_NODE_DIAGNOSTIC_MANAGER_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_NODE_DIAGNOSTIC_MANAGER_H_
#include <mutex>
#include <utility>
#include <vector>

#include "cotek_common/node_diagnostic_info.h"
#include "cotek_msgs/error_info.h"

namespace cotek_diagnostic {
template <typename T>
class NodeStatusManager {
 public:
  NodeStatusManager() { error_status_.first = T::NORMAL; }

  // 故障错误按优先级排序  1>2
  void SetNodeStatus(const T& status, const std::vector<double>& error_info) {
    std::unique_lock<std::mutex> lock(mutex_);
    bool is_changed = false;
    if (error_status_.first == T::NORMAL) {
      error_status_.first = status;
      is_changed = true;
    } else {
      error_status_.first = static_cast<uint16_t>(error_status_.first) <=
                                    static_cast<uint16_t>(status)
                                ? error_status_.first
                                : status;
      is_changed = error_status_.first == status ? true : false;
    }
    if (is_changed) error_status_.second = error_info;
  }

  void SetNodeStatus(const T& status) {
    std::unique_lock<std::mutex> lock(mutex_);
    if (error_status_.first == T::NORMAL) {
      error_status_.first = status;
    } else {
      error_status_.first = static_cast<uint16_t>(error_status_.first) <=
                                    static_cast<uint16_t>(status)
                                ? error_status_.first
                                : status;
    }
    error_status_.second.clear();
  }

  inline void ClearNodeStatus() {
    std::unique_lock<std::mutex> lock(mutex_);
    error_status_.first = T::NORMAL;
    error_status_.second.clear();
  }

  inline const std::pair<T, std::vector<double>> GetNodeStatus() {
    std::unique_lock<std::mutex> lock(mutex_);
    return error_status_;
  }

 private:
  std::mutex mutex_;
  std::pair<T, std::vector<double>> error_status_;
};

}  // namespace cotek_diagnostic

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_NODE_DIAGNOSTIC_MANAGER_H_
