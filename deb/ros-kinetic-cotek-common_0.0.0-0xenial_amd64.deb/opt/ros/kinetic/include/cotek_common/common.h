/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_COMMON_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_COMMON_H_
#include <cmath>

// TODO(@someone) 做成通用运动函数库
namespace common {

// 1 (m/s) = 60/(d * pi) (rpm)
// 轮子速度---> rpm
template <typename T>
T WheelVelocityToRPM(T velocity, T diameter, T radio) {
  return velocity / M_PI / diameter * 60.0 * radio;
}

template <typename T>
T RPMToWheelVelocity(T rpm, T diameter, T radio) {
  return rpm * M_PI * diameter / 60.0 / radio;
}

// 1 (rad/s) = 60 / (2 * pi) (rpm)
// 旋转电机角速度 --> rpm
template <typename T>
T RadPSToRPM(T radps, T radio) {
  return 60.0 * radio * radps / (2 * M_PI);
}

template <typename T>
T RPMToRadPS(T radps, T radio) {
  return 60.0 * radio * radps / (2 * M_PI);
}

// 模型速度 --> 左右轮子速度 according to the formula:
// Vl = V - W * L / 2
// Vr = V + W * L / 2
template <typename T>
T CalcLeftVelocity(T v, T w, T wheel_track) {
  return v - w * wheel_track / 2.;
}

template <typename T>
T CalcRightVelocity(T v, T w, T wheel_track) {
  return v + w * wheel_track / 2.;
}

// 左右轮子速度 --> 模型线速度速度和角速度
template <typename T>
T WheelVelToVelocity(T left_vel, T right_vel) {
  return (left_vel + right_vel) / 2.;
}

template <typename T>
T WheelVelToOmega(T left_vel, T right_vel, T wheel_track) {
  return (right_vel - left_vel) / wheel_track;
}

// 大小端转化
template <typename T>
T GetHtons(const uint8_t *byArr) {
  return ((static_cast<T>(byArr[0]) << 8) & 0xFF00) | byArr[1];
}
}  // namespace common

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_COMMON_H_
