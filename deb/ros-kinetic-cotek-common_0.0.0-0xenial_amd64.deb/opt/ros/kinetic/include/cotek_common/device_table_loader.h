/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_DEVICE_TABLE_LOADER_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_DEVICE_TABLE_LOADER_H_
#include <ros/package.h>

#include <map>
#include <string>
#include <vector>

#include "cotek_common/cotek_enum_type.h"
#include "cotek_common/log_porting.h"
#include "cotek_common/util/json11.h"
#include "cotek_common/util/singleton.h"

struct ChildDeviceParam {
  int node_id;
  int channel;
};

struct ChannelBaudrateParam {
  int can0;
  int can1;
};

// <child name, device param>
using DeviceConfig = std::map<std::string, ChildDeviceParam>;

// 读取 设备表 文件 加载设备配置
class DeviceTableLoader {
 public:
  ~DeviceTableLoader() {}

  // 加载 json 文件获取配置
  bool LoadConfig(const std::string& json_str);

  inline const ChannelBaudrateParam ChannelBaudrate() {
    return channel_baudrate_;
  }

  inline const DeviceConfig& GetConfig(std::string device_name) {
    return device_config_map_.at(device_name);
  }

  inline const std::map<std::string, DeviceConfig>& GetDeviceList() {
    return device_config_map_;
  }

  inline const std::vector<std::string>& GetDiagnosticDeviceList() {
    return device_diagnostic_list_;
  }

  inline const std::map<std::string, unsigned char> GetIoMapping(
      std::string io_board) {
    std::map<std::string, unsigned char> io_map;
    try {
      io_map = io_config_.at(io_board);
    } catch (std::out_of_range& err) {
      LOG_ERROR("invalid io port");
      LOG_ERROR_STREAM(err.what()
                       << " file: " << __FILE__ << " line: " << __LINE__);
      return {};
    }
    return io_map;
  }

 private:
  // 单例实现
  DECLARE_SINGLETON(DeviceTableLoader);
  DeviceTableLoader() {}

  // <parent name, install device>
  std::map<std::string, DeviceConfig> device_config_map_;
  std::vector<std::string> device_diagnostic_list_;
  std::map<std::string, std::map<std::string, unsigned char>> io_config_;
  ChannelBaudrateParam channel_baudrate_;
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_DEVICE_TABLE_LOADER_H_
