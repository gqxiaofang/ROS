/**
 * Copyright (c) 2020 COTEK Inc. All rights reserved.
 */
#ifndef COTEK_COMMON_INCLUDE_COTEK_COMMON_AGV_BASIC_OPTION_H_
#define COTEK_COMMON_INCLUDE_COTEK_COMMON_AGV_BASIC_OPTION_H_

#include <string>

struct UnicycleModelOption {
  float wheel_track;                // 轮间距 m
  float wheel_diameter;             // 轮子直径 m
  float move_motor_reduce_ratio;    // 移动电机减速比 系数
  float lift_motor_reduce_ratio;    // 顶升电机减速比
  float lift_max_height;            // 顶升电机最大顶升高度
  float rotate_motor_reduce_ratio;  // 旋转电机减速比
};

struct BicycleModelOption {
  float wheel_base;  // 轴距 m
  float max_wheel_base;
  float min_wheel_base;
};

struct MoveModelControl {
  // 惯性补偿相关参数
  bool use_inertia_compensation;
  double velocity_coefficient;
  double omega_coefficient;
  // 手动控制相关参数
  float pallet_up_speed;
  float pallet_down_speed;
  float pallet_rotate_speed;
  float forward_speed;
  float backward_speed;
  float rotate_left_speed;
  float rotate_right_speed;
  uint8_t led_type;
  uint8_t audio_type;
  bool enter_low_power;
  bool enable_charge;
};

struct LaserSensorInstallOption {
  double laser_offset_x;
  double laser_offset_y;
  double laser_offset_theta;
};

struct SensorInstallOption {
  LaserSensorInstallOption laser_sensor_install_option;
};

struct MechanicalOption {
  int model_type;
  UnicycleModelOption unicycle_model_option;
  BicycleModelOption bicycle_modle_option;
  SensorInstallOption sensor_install_option;
};

struct LandmarkMapOption {
  std::string http_get_landmark_map_url;
  std::string http_update_landmark_map_url;
  int http_landmark_map_port;
  int current_reflector_map_id;
  int current_reflector_section_id;
  int current_qr_map_id;
  int current_qr_section_id;
  int current_rfid_map_id;
  int current_rfid_section_id;
};

#endif  // COTEK_COMMON_INCLUDE_COTEK_COMMON_AGV_BASIC_OPTION_H_
