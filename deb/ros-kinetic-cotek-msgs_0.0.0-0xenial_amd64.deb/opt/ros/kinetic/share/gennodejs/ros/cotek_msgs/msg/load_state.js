// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class load_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.load_state = null;
    }
    else {
      if (initObj.hasOwnProperty('load_state')) {
        this.load_state = initObj.load_state
      }
      else {
        this.load_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type load_state
    // Serialize message field [load_state]
    bufferOffset = _serializer.uint32(obj.load_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type load_state
    let len;
    let data = new load_state(null);
    // Deserialize message field [load_state]
    data.load_state = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/load_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '93c17b24e4fd40a0324fc4c9260f7c51';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 load_state
    
    # 0: 未知, 1: 载货状态,  2: 没有载货  
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new load_state(null);
    if (msg.load_state !== undefined) {
      resolved.load_state = msg.load_state;
    }
    else {
      resolved.load_state = 0
    }

    return resolved;
    }
};

module.exports = load_state;
