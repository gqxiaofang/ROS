// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class jack_up_io_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.up_down_state = null;
      this.roate_state = null;
    }
    else {
      if (initObj.hasOwnProperty('up_down_state')) {
        this.up_down_state = initObj.up_down_state
      }
      else {
        this.up_down_state = 0;
      }
      if (initObj.hasOwnProperty('roate_state')) {
        this.roate_state = initObj.roate_state
      }
      else {
        this.roate_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type jack_up_io_state
    // Serialize message field [up_down_state]
    bufferOffset = _serializer.uint8(obj.up_down_state, buffer, bufferOffset);
    // Serialize message field [roate_state]
    bufferOffset = _serializer.uint8(obj.roate_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type jack_up_io_state
    let len;
    let data = new jack_up_io_state(null);
    // Deserialize message field [up_down_state]
    data.up_down_state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [roate_state]
    data.roate_state = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/jack_up_io_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5903dd67e11f08235d941123eca23ba3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 up_down_state
    uint8 roate_state
    
    # enum class UpDownState : uint8_t {
    #   UP_NONE = 0,
    #   UP_1 = 1,
    #   UP_2 = 2,
    #   UP_BOTH = 3,
    #   DOWN_NONE = 4,
    #   DOWN_1 = 5,
    #   DOWN_2 = 6,
    #   DOWN_BOTH = 7,
    # }
    
    # enum class RoateType : uint8_t {
    #   Roate_NONE = 0,
    #   Roate_1 = 1,
    #   Roate_2 = 2,
    #   Roate_BOTH = 3,
    # }
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new jack_up_io_state(null);
    if (msg.up_down_state !== undefined) {
      resolved.up_down_state = msg.up_down_state;
    }
    else {
      resolved.up_down_state = 0
    }

    if (msg.roate_state !== undefined) {
      resolved.roate_state = msg.roate_state;
    }
    else {
      resolved.roate_state = 0
    }

    return resolved;
    }
};

module.exports = jack_up_io_state;
