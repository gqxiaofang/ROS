// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class task_control_request {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.control_type = null;
    }
    else {
      if (initObj.hasOwnProperty('control_type')) {
        this.control_type = initObj.control_type
      }
      else {
        this.control_type = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type task_control_request
    // Serialize message field [control_type]
    bufferOffset = _serializer.int32(obj.control_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type task_control_request
    let len;
    let data = new task_control_request(null);
    // Deserialize message field [control_type]
    data.control_type = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/task_control_request';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '661786d610997eeec3e36f7e9f57cdb9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 control_type
    
    # 1 ~ 10停车相关  11 ~ 20对任务列表非正常更新操作
    # enum class TaskControlType : int32_t {
    #   NONE = 0,
    #   STOP_RECOVER = 1,  // 恢复
    #   PAUSE = 2,         // 暂停
    #   EMERGENCY_CUT_OFF = 3,  // 紧急停车 
    #   
    #   TASK_CANCEL = 11,  // 取消任务
    #   (reserve)
    # } 
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new task_control_request(null);
    if (msg.control_type !== undefined) {
      resolved.control_type = msg.control_type;
    }
    else {
      resolved.control_type = 0
    }

    return resolved;
    }
};

module.exports = task_control_request;
