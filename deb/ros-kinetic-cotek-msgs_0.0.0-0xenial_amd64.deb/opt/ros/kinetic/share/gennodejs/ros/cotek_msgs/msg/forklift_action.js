// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class forklift_action {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.audio_control_type = null;
      this.audio_control_level = null;
      this.corning_led_type = null;
      this.three_color_led_type = null;
      this.atomic_action_type = null;
      this.atomic_action_value = null;
      this.clamp_left_motor_value = null;
      this.clamp_right_motor_value = null;
    }
    else {
      if (initObj.hasOwnProperty('audio_control_type')) {
        this.audio_control_type = initObj.audio_control_type
      }
      else {
        this.audio_control_type = 0;
      }
      if (initObj.hasOwnProperty('audio_control_level')) {
        this.audio_control_level = initObj.audio_control_level
      }
      else {
        this.audio_control_level = 0;
      }
      if (initObj.hasOwnProperty('corning_led_type')) {
        this.corning_led_type = initObj.corning_led_type
      }
      else {
        this.corning_led_type = 0;
      }
      if (initObj.hasOwnProperty('three_color_led_type')) {
        this.three_color_led_type = initObj.three_color_led_type
      }
      else {
        this.three_color_led_type = 0;
      }
      if (initObj.hasOwnProperty('atomic_action_type')) {
        this.atomic_action_type = initObj.atomic_action_type
      }
      else {
        this.atomic_action_type = 0;
      }
      if (initObj.hasOwnProperty('atomic_action_value')) {
        this.atomic_action_value = initObj.atomic_action_value
      }
      else {
        this.atomic_action_value = 0.0;
      }
      if (initObj.hasOwnProperty('clamp_left_motor_value')) {
        this.clamp_left_motor_value = initObj.clamp_left_motor_value
      }
      else {
        this.clamp_left_motor_value = 0.0;
      }
      if (initObj.hasOwnProperty('clamp_right_motor_value')) {
        this.clamp_right_motor_value = initObj.clamp_right_motor_value
      }
      else {
        this.clamp_right_motor_value = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type forklift_action
    // Serialize message field [audio_control_type]
    bufferOffset = _serializer.uint8(obj.audio_control_type, buffer, bufferOffset);
    // Serialize message field [audio_control_level]
    bufferOffset = _serializer.uint8(obj.audio_control_level, buffer, bufferOffset);
    // Serialize message field [corning_led_type]
    bufferOffset = _serializer.uint8(obj.corning_led_type, buffer, bufferOffset);
    // Serialize message field [three_color_led_type]
    bufferOffset = _serializer.uint8(obj.three_color_led_type, buffer, bufferOffset);
    // Serialize message field [atomic_action_type]
    bufferOffset = _serializer.int32(obj.atomic_action_type, buffer, bufferOffset);
    // Serialize message field [atomic_action_value]
    bufferOffset = _serializer.float32(obj.atomic_action_value, buffer, bufferOffset);
    // Serialize message field [clamp_left_motor_value]
    bufferOffset = _serializer.float32(obj.clamp_left_motor_value, buffer, bufferOffset);
    // Serialize message field [clamp_right_motor_value]
    bufferOffset = _serializer.float32(obj.clamp_right_motor_value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type forklift_action
    let len;
    let data = new forklift_action(null);
    // Deserialize message field [audio_control_type]
    data.audio_control_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [audio_control_level]
    data.audio_control_level = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [corning_led_type]
    data.corning_led_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [three_color_led_type]
    data.three_color_led_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [atomic_action_type]
    data.atomic_action_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [atomic_action_value]
    data.atomic_action_value = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [clamp_left_motor_value]
    data.clamp_left_motor_value = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [clamp_right_motor_value]
    data.clamp_right_motor_value = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/forklift_action';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dd8edfc7ae6c082d546d356892205ff8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 audio_control_type
    uint8 audio_control_level
    uint8 corning_led_type
    uint8 three_color_led_type
    int32 atomic_action_type
    float32 atomic_action_value
    float32 clamp_left_motor_value
    float32 clamp_right_motor_value
    
    # enum class AudioControlType : uint32_t {
    #   NONE = 0,
    #   BUMP_FAULT = 1,
    #   FORWARD = 2,
    #   BACKWARD = 3,
    #   OBSTACLE_WARN = 4,
    #   OBSTACLE_STOP = 5,
    #   LOW_BATTERY = 6
    # } 
    
    # audio_control_level  0 ~ 30 
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new forklift_action(null);
    if (msg.audio_control_type !== undefined) {
      resolved.audio_control_type = msg.audio_control_type;
    }
    else {
      resolved.audio_control_type = 0
    }

    if (msg.audio_control_level !== undefined) {
      resolved.audio_control_level = msg.audio_control_level;
    }
    else {
      resolved.audio_control_level = 0
    }

    if (msg.corning_led_type !== undefined) {
      resolved.corning_led_type = msg.corning_led_type;
    }
    else {
      resolved.corning_led_type = 0
    }

    if (msg.three_color_led_type !== undefined) {
      resolved.three_color_led_type = msg.three_color_led_type;
    }
    else {
      resolved.three_color_led_type = 0
    }

    if (msg.atomic_action_type !== undefined) {
      resolved.atomic_action_type = msg.atomic_action_type;
    }
    else {
      resolved.atomic_action_type = 0
    }

    if (msg.atomic_action_value !== undefined) {
      resolved.atomic_action_value = msg.atomic_action_value;
    }
    else {
      resolved.atomic_action_value = 0.0
    }

    if (msg.clamp_left_motor_value !== undefined) {
      resolved.clamp_left_motor_value = msg.clamp_left_motor_value;
    }
    else {
      resolved.clamp_left_motor_value = 0.0
    }

    if (msg.clamp_right_motor_value !== undefined) {
      resolved.clamp_right_motor_value = msg.clamp_right_motor_value;
    }
    else {
      resolved.clamp_right_motor_value = 0.0
    }

    return resolved;
    }
};

module.exports = forklift_action;
