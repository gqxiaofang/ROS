// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class weighing_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.weigh = null;
      this.weigh_status = null;
      this.weigh_errcode = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('weigh')) {
        this.weigh = initObj.weigh
      }
      else {
        this.weigh = 0;
      }
      if (initObj.hasOwnProperty('weigh_status')) {
        this.weigh_status = initObj.weigh_status
      }
      else {
        this.weigh_status = 0;
      }
      if (initObj.hasOwnProperty('weigh_errcode')) {
        this.weigh_errcode = initObj.weigh_errcode
      }
      else {
        this.weigh_errcode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type weighing_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [weigh]
    bufferOffset = _serializer.int32(obj.weigh, buffer, bufferOffset);
    // Serialize message field [weigh_status]
    bufferOffset = _serializer.uint32(obj.weigh_status, buffer, bufferOffset);
    // Serialize message field [weigh_errcode]
    bufferOffset = _serializer.uint32(obj.weigh_errcode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type weighing_feedback
    let len;
    let data = new weighing_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [weigh]
    data.weigh = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [weigh_status]
    data.weigh_status = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [weigh_errcode]
    data.weigh_errcode = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/weighing_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ef105f43958e7c22087e643ad35a2c03';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 time_stamp
    int32 weigh
    uint32 weigh_status
    uint32 weigh_errcode
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new weighing_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.weigh !== undefined) {
      resolved.weigh = msg.weigh;
    }
    else {
      resolved.weigh = 0
    }

    if (msg.weigh_status !== undefined) {
      resolved.weigh_status = msg.weigh_status;
    }
    else {
      resolved.weigh_status = 0
    }

    if (msg.weigh_errcode !== undefined) {
      resolved.weigh_errcode = msg.weigh_errcode;
    }
    else {
      resolved.weigh_errcode = 0
    }

    return resolved;
    }
};

module.exports = weighing_feedback;
