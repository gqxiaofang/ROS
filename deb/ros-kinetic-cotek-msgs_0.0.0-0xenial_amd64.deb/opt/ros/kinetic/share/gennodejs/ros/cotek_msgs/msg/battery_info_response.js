// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class battery_info_response {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.battery_type = null;
      this.voltage = null;
      this.current = null;
      this.soc = null;
      this.max_voltage = null;
      this.min_voltage = null;
      this.temperature = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('battery_type')) {
        this.battery_type = initObj.battery_type
      }
      else {
        this.battery_type = 0;
      }
      if (initObj.hasOwnProperty('voltage')) {
        this.voltage = initObj.voltage
      }
      else {
        this.voltage = 0.0;
      }
      if (initObj.hasOwnProperty('current')) {
        this.current = initObj.current
      }
      else {
        this.current = 0.0;
      }
      if (initObj.hasOwnProperty('soc')) {
        this.soc = initObj.soc
      }
      else {
        this.soc = 0;
      }
      if (initObj.hasOwnProperty('max_voltage')) {
        this.max_voltage = initObj.max_voltage
      }
      else {
        this.max_voltage = 0.0;
      }
      if (initObj.hasOwnProperty('min_voltage')) {
        this.min_voltage = initObj.min_voltage
      }
      else {
        this.min_voltage = 0.0;
      }
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = 0.0;
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type battery_info_response
    // Serialize message field [battery_type]
    bufferOffset = _serializer.int32(obj.battery_type, buffer, bufferOffset);
    // Serialize message field [voltage]
    bufferOffset = _serializer.float64(obj.voltage, buffer, bufferOffset);
    // Serialize message field [current]
    bufferOffset = _serializer.float64(obj.current, buffer, bufferOffset);
    // Serialize message field [soc]
    bufferOffset = _serializer.int32(obj.soc, buffer, bufferOffset);
    // Serialize message field [max_voltage]
    bufferOffset = _serializer.float64(obj.max_voltage, buffer, bufferOffset);
    // Serialize message field [min_voltage]
    bufferOffset = _serializer.float64(obj.min_voltage, buffer, bufferOffset);
    // Serialize message field [temperature]
    bufferOffset = _serializer.float64(obj.temperature, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.int32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type battery_info_response
    let len;
    let data = new battery_info_response(null);
    // Deserialize message field [battery_type]
    data.battery_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [voltage]
    data.voltage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current]
    data.current = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [soc]
    data.soc = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [max_voltage]
    data.max_voltage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [min_voltage]
    data.min_voltage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [temperature]
    data.temperature = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 52;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/battery_info_response';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '94248fd1591023dae0c2d9dc95bd7689';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 车载向调度回复电池信息包 batteryInfoResponse
    int32 battery_type
    float64 voltage # V
    float64 current # A
    int32 soc # 0~100%
    float64 max_voltage
    float64 min_voltage
    float64 temperature # 度
    int32 status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new battery_info_response(null);
    if (msg.battery_type !== undefined) {
      resolved.battery_type = msg.battery_type;
    }
    else {
      resolved.battery_type = 0
    }

    if (msg.voltage !== undefined) {
      resolved.voltage = msg.voltage;
    }
    else {
      resolved.voltage = 0.0
    }

    if (msg.current !== undefined) {
      resolved.current = msg.current;
    }
    else {
      resolved.current = 0.0
    }

    if (msg.soc !== undefined) {
      resolved.soc = msg.soc;
    }
    else {
      resolved.soc = 0
    }

    if (msg.max_voltage !== undefined) {
      resolved.max_voltage = msg.max_voltage;
    }
    else {
      resolved.max_voltage = 0.0
    }

    if (msg.min_voltage !== undefined) {
      resolved.min_voltage = msg.min_voltage;
    }
    else {
      resolved.min_voltage = 0.0
    }

    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = 0.0
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

module.exports = battery_info_response;
