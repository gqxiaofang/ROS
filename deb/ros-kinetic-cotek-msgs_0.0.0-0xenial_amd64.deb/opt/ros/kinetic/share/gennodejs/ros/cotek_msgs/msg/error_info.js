// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class error_info {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_info = null;
    }
    else {
      if (initObj.hasOwnProperty('error_info')) {
        this.error_info = initObj.error_info
      }
      else {
        this.error_info = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type error_info
    // Serialize message field [error_info]
    bufferOffset = _serializer.float64(obj.error_info, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type error_info
    let len;
    let data = new error_info(null);
    // Deserialize message field [error_info]
    data.error_info = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/error_info';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e826969485f4d5e80e2fec23fc2f0c16';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 error_info
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new error_info(null);
    if (msg.error_info !== undefined) {
      resolved.error_info = msg.error_info;
    }
    else {
      resolved.error_info = 0.0
    }

    return resolved;
    }
};

module.exports = error_info;
