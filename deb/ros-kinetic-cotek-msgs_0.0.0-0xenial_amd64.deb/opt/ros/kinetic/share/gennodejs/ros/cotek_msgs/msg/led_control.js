// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class led_control {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.three_color_led_type = null;
      this.corning_led_type = null;
    }
    else {
      if (initObj.hasOwnProperty('three_color_led_type')) {
        this.three_color_led_type = initObj.three_color_led_type
      }
      else {
        this.three_color_led_type = 0;
      }
      if (initObj.hasOwnProperty('corning_led_type')) {
        this.corning_led_type = initObj.corning_led_type
      }
      else {
        this.corning_led_type = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type led_control
    // Serialize message field [three_color_led_type]
    bufferOffset = _serializer.uint8(obj.three_color_led_type, buffer, bufferOffset);
    // Serialize message field [corning_led_type]
    bufferOffset = _serializer.uint8(obj.corning_led_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type led_control
    let len;
    let data = new led_control(null);
    // Deserialize message field [three_color_led_type]
    data.three_color_led_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [corning_led_type]
    data.corning_led_type = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/led_control';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7f3962ba738f1f289518f25de6d7e6a9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 three_color_led_type
    uint8 corning_led_type
    
    # 三色灯控制类型
    # enum class ThreeColorLedType : uint32_t {
    #     GREEN_ON                 = 0x00000100,
    #     YELLOW_ON                = 0x00000010,
    #     RED_ON                   = 0x00000001,
        
    #     YELLOW_GREEN_ON          = 0x00000110,
    #     RED_YELLOW_ON            = 0x00000011,
    #     RED_GREEN_ON             = 0x00000101,
    #     RED_YELLOW_GREEN_ON      = 0x00000111,
        
    #     RED_TWINKLE              = 0x10000001,
    #     YELLOW_TWINKLE           = 0x10000010,
    #     GREEN_TWINKLE            = 0x10000100,
        
    #     YELLOW_GREEN_TWINKLE     = 0x10000110,
    #     RED_YELLOW_TWINKLE       = 0x10000011,
    #     RED_GREEN_TWINKLE        = 0x10000101,
    #     RED_YELLOW_GREEN_TWINKLE = 0x10000111,
        
    #     YELLOW_GREEN_SWITCH      = 0x20000110,
    #     RED_YELLOW_SWITCH        = 0x20000011,
    #     RED_GREEN_SWITCH         = 0x20000101,
        
    #     LIGHT_ALL_ON             = 0x00000111,
    #     LIGHT_OFF                = 0x00000000,
    # }
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new led_control(null);
    if (msg.three_color_led_type !== undefined) {
      resolved.three_color_led_type = msg.three_color_led_type;
    }
    else {
      resolved.three_color_led_type = 0
    }

    if (msg.corning_led_type !== undefined) {
      resolved.corning_led_type = msg.corning_led_type;
    }
    else {
      resolved.corning_led_type = 0
    }

    return resolved;
    }
};

module.exports = led_control;
