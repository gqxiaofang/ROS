// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class mls_navigation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.found_lines = null;
      this.line_offset = null;
    }
    else {
      if (initObj.hasOwnProperty('found_lines')) {
        this.found_lines = initObj.found_lines
      }
      else {
        this.found_lines = false;
      }
      if (initObj.hasOwnProperty('line_offset')) {
        this.line_offset = initObj.line_offset
      }
      else {
        this.line_offset = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type mls_navigation
    // Serialize message field [found_lines]
    bufferOffset = _serializer.bool(obj.found_lines, buffer, bufferOffset);
    // Serialize message field [line_offset]
    bufferOffset = _serializer.float32(obj.line_offset, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type mls_navigation
    let len;
    let data = new mls_navigation(null);
    // Deserialize message field [found_lines]
    data.found_lines = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [line_offset]
    data.line_offset = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/mls_navigation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'edf47fb2a72c42a3f3ab4a6c0084e4ab';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool found_lines
    float32 line_offset
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new mls_navigation(null);
    if (msg.found_lines !== undefined) {
      resolved.found_lines = msg.found_lines;
    }
    else {
      resolved.found_lines = false
    }

    if (msg.line_offset !== undefined) {
      resolved.line_offset = msg.line_offset;
    }
    else {
      resolved.line_offset = 0.0
    }

    return resolved;
    }
};

module.exports = mls_navigation;
