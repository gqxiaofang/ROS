// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class task_get_map_request {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.get_map_method = null;
      this.get_map_type = null;
    }
    else {
      if (initObj.hasOwnProperty('get_map_method')) {
        this.get_map_method = initObj.get_map_method
      }
      else {
        this.get_map_method = 0;
      }
      if (initObj.hasOwnProperty('get_map_type')) {
        this.get_map_type = initObj.get_map_type
      }
      else {
        this.get_map_type = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type task_get_map_request
    // Serialize message field [get_map_method]
    bufferOffset = _serializer.int32(obj.get_map_method, buffer, bufferOffset);
    // Serialize message field [get_map_type]
    bufferOffset = _serializer.int32(obj.get_map_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type task_get_map_request
    let len;
    let data = new task_get_map_request(null);
    // Deserialize message field [get_map_method]
    data.get_map_method = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [get_map_type]
    data.get_map_type = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/task_get_map_request';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f9c9d6d8461f095d540ef11222525059';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 获取标定地图信息包
    int32 get_map_method  # 获取地图的方式, 填 1 为 http请求的方式...
    int32 get_map_type  # 获取地图的类型, 填 1 为 反光板json列表...
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new task_get_map_request(null);
    if (msg.get_map_method !== undefined) {
      resolved.get_map_method = msg.get_map_method;
    }
    else {
      resolved.get_map_method = 0
    }

    if (msg.get_map_type !== undefined) {
      resolved.get_map_type = msg.get_map_type;
    }
    else {
      resolved.get_map_type = 0
    }

    return resolved;
    }
};

module.exports = task_get_map_request;
