// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class task_control_audio_request {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.audio_type = null;
      this.enable = null;
    }
    else {
      if (initObj.hasOwnProperty('audio_type')) {
        this.audio_type = initObj.audio_type
      }
      else {
        this.audio_type = 0;
      }
      if (initObj.hasOwnProperty('enable')) {
        this.enable = initObj.enable
      }
      else {
        this.enable = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type task_control_audio_request
    // Serialize message field [audio_type]
    bufferOffset = _serializer.int32(obj.audio_type, buffer, bufferOffset);
    // Serialize message field [enable]
    bufferOffset = _serializer.bool(obj.enable, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type task_control_audio_request
    let len;
    let data = new task_control_audio_request(null);
    // Deserialize message field [audio_type]
    data.audio_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [enable]
    data.enable = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/task_control_audio_request';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c27078912a31dd3fe69d8ea5fd49e7fc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 调度切换音频类型
    int32 audio_type  # 音频类型   
    bool enable      # 使能调度音频
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new task_control_audio_request(null);
    if (msg.audio_type !== undefined) {
      resolved.audio_type = msg.audio_type;
    }
    else {
      resolved.audio_type = 0
    }

    if (msg.enable !== undefined) {
      resolved.enable = msg.enable;
    }
    else {
      resolved.enable = false
    }

    return resolved;
    }
};

module.exports = task_control_audio_request;
