// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class valve_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.channel_0 = null;
      this.channel_1 = null;
      this.channel_2 = null;
      this.channel_3 = null;
      this.channel_4 = null;
      this.channel_5 = null;
      this.channel_6 = null;
      this.channel_7 = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('channel_0')) {
        this.channel_0 = initObj.channel_0
      }
      else {
        this.channel_0 = false;
      }
      if (initObj.hasOwnProperty('channel_1')) {
        this.channel_1 = initObj.channel_1
      }
      else {
        this.channel_1 = false;
      }
      if (initObj.hasOwnProperty('channel_2')) {
        this.channel_2 = initObj.channel_2
      }
      else {
        this.channel_2 = false;
      }
      if (initObj.hasOwnProperty('channel_3')) {
        this.channel_3 = initObj.channel_3
      }
      else {
        this.channel_3 = false;
      }
      if (initObj.hasOwnProperty('channel_4')) {
        this.channel_4 = initObj.channel_4
      }
      else {
        this.channel_4 = false;
      }
      if (initObj.hasOwnProperty('channel_5')) {
        this.channel_5 = initObj.channel_5
      }
      else {
        this.channel_5 = false;
      }
      if (initObj.hasOwnProperty('channel_6')) {
        this.channel_6 = initObj.channel_6
      }
      else {
        this.channel_6 = false;
      }
      if (initObj.hasOwnProperty('channel_7')) {
        this.channel_7 = initObj.channel_7
      }
      else {
        this.channel_7 = false;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type valve_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [channel_0]
    bufferOffset = _serializer.bool(obj.channel_0, buffer, bufferOffset);
    // Serialize message field [channel_1]
    bufferOffset = _serializer.bool(obj.channel_1, buffer, bufferOffset);
    // Serialize message field [channel_2]
    bufferOffset = _serializer.bool(obj.channel_2, buffer, bufferOffset);
    // Serialize message field [channel_3]
    bufferOffset = _serializer.bool(obj.channel_3, buffer, bufferOffset);
    // Serialize message field [channel_4]
    bufferOffset = _serializer.bool(obj.channel_4, buffer, bufferOffset);
    // Serialize message field [channel_5]
    bufferOffset = _serializer.bool(obj.channel_5, buffer, bufferOffset);
    // Serialize message field [channel_6]
    bufferOffset = _serializer.bool(obj.channel_6, buffer, bufferOffset);
    // Serialize message field [channel_7]
    bufferOffset = _serializer.bool(obj.channel_7, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.uint16(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type valve_feedback
    let len;
    let data = new valve_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [channel_0]
    data.channel_0 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_1]
    data.channel_1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_2]
    data.channel_2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_3]
    data.channel_3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_4]
    data.channel_4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_5]
    data.channel_5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_6]
    data.channel_6 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [channel_7]
    data.channel_7 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/valve_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0399058086b77e23fbc5f7c61e07ed22';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 时间戳
    uint32 time_stamp
    # 数据
    bool channel_0
    bool channel_1
    bool channel_2
    bool channel_3
    bool channel_4
    bool channel_5
    bool channel_6
    bool channel_7
    # 错误码
    uint16 error_code
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new valve_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.channel_0 !== undefined) {
      resolved.channel_0 = msg.channel_0;
    }
    else {
      resolved.channel_0 = false
    }

    if (msg.channel_1 !== undefined) {
      resolved.channel_1 = msg.channel_1;
    }
    else {
      resolved.channel_1 = false
    }

    if (msg.channel_2 !== undefined) {
      resolved.channel_2 = msg.channel_2;
    }
    else {
      resolved.channel_2 = false
    }

    if (msg.channel_3 !== undefined) {
      resolved.channel_3 = msg.channel_3;
    }
    else {
      resolved.channel_3 = false
    }

    if (msg.channel_4 !== undefined) {
      resolved.channel_4 = msg.channel_4;
    }
    else {
      resolved.channel_4 = false
    }

    if (msg.channel_5 !== undefined) {
      resolved.channel_5 = msg.channel_5;
    }
    else {
      resolved.channel_5 = false
    }

    if (msg.channel_6 !== undefined) {
      resolved.channel_6 = msg.channel_6;
    }
    else {
      resolved.channel_6 = false
    }

    if (msg.channel_7 !== undefined) {
      resolved.channel_7 = msg.channel_7;
    }
    else {
      resolved.channel_7 = false
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = valve_feedback;
