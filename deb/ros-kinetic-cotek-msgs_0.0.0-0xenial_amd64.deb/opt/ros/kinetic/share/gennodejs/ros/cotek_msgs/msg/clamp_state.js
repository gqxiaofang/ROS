// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class clamp_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.clamp_left_state = null;
      this.clamp_right_state = null;
      this.clamp_detect_state = null;
      this.clamp_limit_left_state = null;
      this.clamp_limit_right_state = null;
    }
    else {
      if (initObj.hasOwnProperty('clamp_left_state')) {
        this.clamp_left_state = initObj.clamp_left_state
      }
      else {
        this.clamp_left_state = 0;
      }
      if (initObj.hasOwnProperty('clamp_right_state')) {
        this.clamp_right_state = initObj.clamp_right_state
      }
      else {
        this.clamp_right_state = 0;
      }
      if (initObj.hasOwnProperty('clamp_detect_state')) {
        this.clamp_detect_state = initObj.clamp_detect_state
      }
      else {
        this.clamp_detect_state = 0;
      }
      if (initObj.hasOwnProperty('clamp_limit_left_state')) {
        this.clamp_limit_left_state = initObj.clamp_limit_left_state
      }
      else {
        this.clamp_limit_left_state = 0;
      }
      if (initObj.hasOwnProperty('clamp_limit_right_state')) {
        this.clamp_limit_right_state = initObj.clamp_limit_right_state
      }
      else {
        this.clamp_limit_right_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type clamp_state
    // Serialize message field [clamp_left_state]
    bufferOffset = _serializer.uint8(obj.clamp_left_state, buffer, bufferOffset);
    // Serialize message field [clamp_right_state]
    bufferOffset = _serializer.uint8(obj.clamp_right_state, buffer, bufferOffset);
    // Serialize message field [clamp_detect_state]
    bufferOffset = _serializer.uint8(obj.clamp_detect_state, buffer, bufferOffset);
    // Serialize message field [clamp_limit_left_state]
    bufferOffset = _serializer.uint8(obj.clamp_limit_left_state, buffer, bufferOffset);
    // Serialize message field [clamp_limit_right_state]
    bufferOffset = _serializer.uint8(obj.clamp_limit_right_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type clamp_state
    let len;
    let data = new clamp_state(null);
    // Deserialize message field [clamp_left_state]
    data.clamp_left_state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [clamp_right_state]
    data.clamp_right_state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [clamp_detect_state]
    data.clamp_detect_state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [clamp_limit_left_state]
    data.clamp_limit_left_state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [clamp_limit_right_state]
    data.clamp_limit_right_state = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/clamp_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7004bc39c6c3fa9b4a6e6f423115e459';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 clamp_left_state
    uint8 clamp_right_state
    uint8 clamp_detect_state
    uint8 clamp_limit_left_state
    uint8 clamp_limit_right_state
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new clamp_state(null);
    if (msg.clamp_left_state !== undefined) {
      resolved.clamp_left_state = msg.clamp_left_state;
    }
    else {
      resolved.clamp_left_state = 0
    }

    if (msg.clamp_right_state !== undefined) {
      resolved.clamp_right_state = msg.clamp_right_state;
    }
    else {
      resolved.clamp_right_state = 0
    }

    if (msg.clamp_detect_state !== undefined) {
      resolved.clamp_detect_state = msg.clamp_detect_state;
    }
    else {
      resolved.clamp_detect_state = 0
    }

    if (msg.clamp_limit_left_state !== undefined) {
      resolved.clamp_limit_left_state = msg.clamp_limit_left_state;
    }
    else {
      resolved.clamp_limit_left_state = 0
    }

    if (msg.clamp_limit_right_state !== undefined) {
      resolved.clamp_limit_right_state = msg.clamp_limit_right_state;
    }
    else {
      resolved.clamp_limit_right_state = 0
    }

    return resolved;
    }
};

module.exports = clamp_state;
