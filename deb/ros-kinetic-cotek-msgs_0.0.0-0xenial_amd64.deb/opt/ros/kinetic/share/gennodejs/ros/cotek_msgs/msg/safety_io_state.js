// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class safety_io_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.avoid_io_state = null;
    }
    else {
      if (initObj.hasOwnProperty('avoid_io_state')) {
        this.avoid_io_state = initObj.avoid_io_state
      }
      else {
        this.avoid_io_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type safety_io_state
    // Serialize message field [avoid_io_state]
    bufferOffset = _serializer.uint8(obj.avoid_io_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type safety_io_state
    let len;
    let data = new safety_io_state(null);
    // Deserialize message field [avoid_io_state]
    data.avoid_io_state = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/safety_io_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd7790e70bbdba02f2d53b010ebb0e8ae';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 avoid_io_state
    
    # 上报优先级 不可恢复(防撞条) > 可恢复光电(防撞检测开关) > 可恢复避障区域(北洋避障区域)
    # enum class Avoid_io_state : uint8_t {
    #   NONE = 0,            // 无避障 
    #   LEVEL_I = 1,         // 避障区域 避障等级1 - slowlevel1 
    #   LEVEL_II = 2,        // 避障区域 避障等级2 - slowlevel2 
    #   LEVEL_III = 3,       // 避障区域 避障等级3 - stop 
    #   BUMP = 4,            // 防撞条 
    #   FORK_LEFT_LEG = 5,   // 叉车左叉腿防撞 
    #   FORK_RIGHT_LEG = 6,  // 叉车右叉腿防撞 
    #   FORK_LEG_BOTH = 7    // 叉车左右叉腿都检测到 
    #   }
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new safety_io_state(null);
    if (msg.avoid_io_state !== undefined) {
      resolved.avoid_io_state = msg.avoid_io_state;
    }
    else {
      resolved.avoid_io_state = 0
    }

    return resolved;
    }
};

module.exports = safety_io_state;
