// Auto-generated. Do not edit!

// (in-package cotek_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class start_carto_with_mappingRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.new_map = null;
      this.map_id = null;
      this.section_id = null;
      this.x = null;
      this.y = null;
      this.yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('new_map')) {
        this.new_map = initObj.new_map
      }
      else {
        this.new_map = false;
      }
      if (initObj.hasOwnProperty('map_id')) {
        this.map_id = initObj.map_id
      }
      else {
        this.map_id = 0;
      }
      if (initObj.hasOwnProperty('section_id')) {
        this.section_id = initObj.section_id
      }
      else {
        this.section_id = 0;
      }
      if (initObj.hasOwnProperty('x')) {
        this.x = initObj.x
      }
      else {
        this.x = 0.0;
      }
      if (initObj.hasOwnProperty('y')) {
        this.y = initObj.y
      }
      else {
        this.y = 0.0;
      }
      if (initObj.hasOwnProperty('yaw')) {
        this.yaw = initObj.yaw
      }
      else {
        this.yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type start_carto_with_mappingRequest
    // Serialize message field [new_map]
    bufferOffset = _serializer.bool(obj.new_map, buffer, bufferOffset);
    // Serialize message field [map_id]
    bufferOffset = _serializer.int32(obj.map_id, buffer, bufferOffset);
    // Serialize message field [section_id]
    bufferOffset = _serializer.int32(obj.section_id, buffer, bufferOffset);
    // Serialize message field [x]
    bufferOffset = _serializer.float64(obj.x, buffer, bufferOffset);
    // Serialize message field [y]
    bufferOffset = _serializer.float64(obj.y, buffer, bufferOffset);
    // Serialize message field [yaw]
    bufferOffset = _serializer.float64(obj.yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type start_carto_with_mappingRequest
    let len;
    let data = new start_carto_with_mappingRequest(null);
    // Deserialize message field [new_map]
    data.new_map = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [map_id]
    data.map_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [section_id]
    data.section_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [x]
    data.x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y]
    data.y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [yaw]
    data.yaw = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 33;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/start_carto_with_mappingRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e2f8f27af5666f88dde9e1b5cf54aa56';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool new_map
    int32 map_id
    int32 section_id
    float64 x
    float64 y
    float64 yaw
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new start_carto_with_mappingRequest(null);
    if (msg.new_map !== undefined) {
      resolved.new_map = msg.new_map;
    }
    else {
      resolved.new_map = false
    }

    if (msg.map_id !== undefined) {
      resolved.map_id = msg.map_id;
    }
    else {
      resolved.map_id = 0
    }

    if (msg.section_id !== undefined) {
      resolved.section_id = msg.section_id;
    }
    else {
      resolved.section_id = 0
    }

    if (msg.x !== undefined) {
      resolved.x = msg.x;
    }
    else {
      resolved.x = 0.0
    }

    if (msg.y !== undefined) {
      resolved.y = msg.y;
    }
    else {
      resolved.y = 0.0
    }

    if (msg.yaw !== undefined) {
      resolved.yaw = msg.yaw;
    }
    else {
      resolved.yaw = 0.0
    }

    return resolved;
    }
};

class start_carto_with_mappingResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type start_carto_with_mappingResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type start_carto_with_mappingResponse
    let len;
    let data = new start_carto_with_mappingResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/start_carto_with_mappingResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new start_carto_with_mappingResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: start_carto_with_mappingRequest,
  Response: start_carto_with_mappingResponse,
  md5sum() { return 'e2f8f27af5666f88dde9e1b5cf54aa56'; },
  datatype() { return 'cotek_msgs/start_carto_with_mapping'; }
};
