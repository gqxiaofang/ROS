// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class update_init_pose {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.carto_need_update = null;
    }
    else {
      if (initObj.hasOwnProperty('carto_need_update')) {
        this.carto_need_update = initObj.carto_need_update
      }
      else {
        this.carto_need_update = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type update_init_pose
    // Serialize message field [carto_need_update]
    bufferOffset = _serializer.bool(obj.carto_need_update, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type update_init_pose
    let len;
    let data = new update_init_pose(null);
    // Deserialize message field [carto_need_update]
    data.carto_need_update = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/update_init_pose';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dfebe6329dbc389cb93c53e8e5956108';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool carto_need_update
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new update_init_pose(null);
    if (msg.carto_need_update !== undefined) {
      resolved.carto_need_update = msg.carto_need_update;
    }
    else {
      resolved.carto_need_update = false
    }

    return resolved;
    }
};

module.exports = update_init_pose;
