// Auto-generated. Do not edit!

// (in-package cotek_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class update_carto_init_poseRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_type = null;
      this.map_id = null;
      this.section_id = null;
      this.x = null;
      this.y = null;
      this.yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('map_type')) {
        this.map_type = initObj.map_type
      }
      else {
        this.map_type = 0;
      }
      if (initObj.hasOwnProperty('map_id')) {
        this.map_id = initObj.map_id
      }
      else {
        this.map_id = 0;
      }
      if (initObj.hasOwnProperty('section_id')) {
        this.section_id = initObj.section_id
      }
      else {
        this.section_id = 0;
      }
      if (initObj.hasOwnProperty('x')) {
        this.x = initObj.x
      }
      else {
        this.x = 0.0;
      }
      if (initObj.hasOwnProperty('y')) {
        this.y = initObj.y
      }
      else {
        this.y = 0.0;
      }
      if (initObj.hasOwnProperty('yaw')) {
        this.yaw = initObj.yaw
      }
      else {
        this.yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type update_carto_init_poseRequest
    // Serialize message field [map_type]
    bufferOffset = _serializer.int32(obj.map_type, buffer, bufferOffset);
    // Serialize message field [map_id]
    bufferOffset = _serializer.int32(obj.map_id, buffer, bufferOffset);
    // Serialize message field [section_id]
    bufferOffset = _serializer.int32(obj.section_id, buffer, bufferOffset);
    // Serialize message field [x]
    bufferOffset = _serializer.float64(obj.x, buffer, bufferOffset);
    // Serialize message field [y]
    bufferOffset = _serializer.float64(obj.y, buffer, bufferOffset);
    // Serialize message field [yaw]
    bufferOffset = _serializer.float64(obj.yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type update_carto_init_poseRequest
    let len;
    let data = new update_carto_init_poseRequest(null);
    // Deserialize message field [map_type]
    data.map_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [map_id]
    data.map_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [section_id]
    data.section_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [x]
    data.x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y]
    data.y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [yaw]
    data.yaw = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 36;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/update_carto_init_poseRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b8c581f4f20882033c3c7199c517b2ee';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 map_type
    int32 map_id
    int32 section_id
    float64 x
    float64 y
    float64 yaw
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new update_carto_init_poseRequest(null);
    if (msg.map_type !== undefined) {
      resolved.map_type = msg.map_type;
    }
    else {
      resolved.map_type = 0
    }

    if (msg.map_id !== undefined) {
      resolved.map_id = msg.map_id;
    }
    else {
      resolved.map_id = 0
    }

    if (msg.section_id !== undefined) {
      resolved.section_id = msg.section_id;
    }
    else {
      resolved.section_id = 0
    }

    if (msg.x !== undefined) {
      resolved.x = msg.x;
    }
    else {
      resolved.x = 0.0
    }

    if (msg.y !== undefined) {
      resolved.y = msg.y;
    }
    else {
      resolved.y = 0.0
    }

    if (msg.yaw !== undefined) {
      resolved.yaw = msg.yaw;
    }
    else {
      resolved.yaw = 0.0
    }

    return resolved;
    }
};

class update_carto_init_poseResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type update_carto_init_poseResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type update_carto_init_poseResponse
    let len;
    let data = new update_carto_init_poseResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cotek_msgs/update_carto_init_poseResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new update_carto_init_poseResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: update_carto_init_poseRequest,
  Response: update_carto_init_poseResponse,
  md5sum() { return 'b8c581f4f20882033c3c7199c517b2ee'; },
  datatype() { return 'cotek_msgs/update_carto_init_pose'; }
};
