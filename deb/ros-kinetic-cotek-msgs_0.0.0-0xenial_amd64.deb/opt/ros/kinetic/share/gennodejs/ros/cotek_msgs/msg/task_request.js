// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let step = require('./step.js');

//-----------------------------------------------------------

class task_request {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.agv_id = null;
      this.order_id = null;
      this.task_id = null;
      this.task_type = null;
      this.sequence_num = null;
      this.step_size = null;
      this.step_list = null;
    }
    else {
      if (initObj.hasOwnProperty('agv_id')) {
        this.agv_id = initObj.agv_id
      }
      else {
        this.agv_id = '';
      }
      if (initObj.hasOwnProperty('order_id')) {
        this.order_id = initObj.order_id
      }
      else {
        this.order_id = '';
      }
      if (initObj.hasOwnProperty('task_id')) {
        this.task_id = initObj.task_id
      }
      else {
        this.task_id = '';
      }
      if (initObj.hasOwnProperty('task_type')) {
        this.task_type = initObj.task_type
      }
      else {
        this.task_type = 0;
      }
      if (initObj.hasOwnProperty('sequence_num')) {
        this.sequence_num = initObj.sequence_num
      }
      else {
        this.sequence_num = 0;
      }
      if (initObj.hasOwnProperty('step_size')) {
        this.step_size = initObj.step_size
      }
      else {
        this.step_size = 0;
      }
      if (initObj.hasOwnProperty('step_list')) {
        this.step_list = initObj.step_list
      }
      else {
        this.step_list = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type task_request
    // Serialize message field [agv_id]
    bufferOffset = _serializer.string(obj.agv_id, buffer, bufferOffset);
    // Serialize message field [order_id]
    bufferOffset = _serializer.string(obj.order_id, buffer, bufferOffset);
    // Serialize message field [task_id]
    bufferOffset = _serializer.string(obj.task_id, buffer, bufferOffset);
    // Serialize message field [task_type]
    bufferOffset = _serializer.int32(obj.task_type, buffer, bufferOffset);
    // Serialize message field [sequence_num]
    bufferOffset = _serializer.int32(obj.sequence_num, buffer, bufferOffset);
    // Serialize message field [step_size]
    bufferOffset = _serializer.int32(obj.step_size, buffer, bufferOffset);
    // Serialize message field [step_list]
    // Serialize the length for message field [step_list]
    bufferOffset = _serializer.uint32(obj.step_list.length, buffer, bufferOffset);
    obj.step_list.forEach((val) => {
      bufferOffset = step.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type task_request
    let len;
    let data = new task_request(null);
    // Deserialize message field [agv_id]
    data.agv_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [order_id]
    data.order_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [task_id]
    data.task_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [task_type]
    data.task_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [sequence_num]
    data.sequence_num = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [step_size]
    data.step_size = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [step_list]
    // Deserialize array length for message field [step_list]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.step_list = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.step_list[i] = step.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.agv_id.length;
    length += object.order_id.length;
    length += object.task_id.length;
    object.step_list.forEach((val) => {
      length += step.getMessageSize(val);
    });
    return length + 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/task_request';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e945772edcc1340715a82347dbb4b097';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 任务请求   taskType: ForkTaskRequest
    string agv_id  # agv 设备的序列号
    string order_id # 任务订单号
    string task_id # 任务号
    int32 task_type# 任务类型
    int32 sequence_num
    int32 step_size
    cotek_msgs/step[] step_list
    ================================================================================
    MSG: cotek_msgs/step
    int32 sequence_id
    int32 navi_type
    int32 step_type
    int32 move_type
    int32 path_type
    string node_id
    int32 point_id
    float64 point_x
    float64 point_y
    float64 point_yaw
    int32 relative
    float64 plate_angle
    float64 plate_weight
    float64 control_point_x0
    float64 control_point_y0
    float64 control_point_x1
    float64 control_point_y1
    int32 current_sec_id
    int32 target_sec_id
    int32 switch_point_id
    float64 switch_point_x
    float64 switch_point_y
    float64 switch_point_yaw
    float64 speed
    float64 odom
    int32 ultrasonic_obstacle
    int32 avoid_strategy_code
    int32 operation_type
    float64 operation_value
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new task_request(null);
    if (msg.agv_id !== undefined) {
      resolved.agv_id = msg.agv_id;
    }
    else {
      resolved.agv_id = ''
    }

    if (msg.order_id !== undefined) {
      resolved.order_id = msg.order_id;
    }
    else {
      resolved.order_id = ''
    }

    if (msg.task_id !== undefined) {
      resolved.task_id = msg.task_id;
    }
    else {
      resolved.task_id = ''
    }

    if (msg.task_type !== undefined) {
      resolved.task_type = msg.task_type;
    }
    else {
      resolved.task_type = 0
    }

    if (msg.sequence_num !== undefined) {
      resolved.sequence_num = msg.sequence_num;
    }
    else {
      resolved.sequence_num = 0
    }

    if (msg.step_size !== undefined) {
      resolved.step_size = msg.step_size;
    }
    else {
      resolved.step_size = 0
    }

    if (msg.step_list !== undefined) {
      resolved.step_list = new Array(msg.step_list.length);
      for (let i = 0; i < resolved.step_list.length; ++i) {
        resolved.step_list[i] = step.Resolve(msg.step_list[i]);
      }
    }
    else {
      resolved.step_list = []
    }

    return resolved;
    }
};

module.exports = task_request;
