// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ultarsonic_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.length1 = null;
      this.length2 = null;
      this.length3 = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('length1')) {
        this.length1 = initObj.length1
      }
      else {
        this.length1 = 0.0;
      }
      if (initObj.hasOwnProperty('length2')) {
        this.length2 = initObj.length2
      }
      else {
        this.length2 = 0.0;
      }
      if (initObj.hasOwnProperty('length3')) {
        this.length3 = initObj.length3
      }
      else {
        this.length3 = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ultarsonic_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [length1]
    bufferOffset = _serializer.float64(obj.length1, buffer, bufferOffset);
    // Serialize message field [length2]
    bufferOffset = _serializer.float64(obj.length2, buffer, bufferOffset);
    // Serialize message field [length3]
    bufferOffset = _serializer.float64(obj.length3, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ultarsonic_feedback
    let len;
    let data = new ultarsonic_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [length1]
    data.length1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [length2]
    data.length2 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [length3]
    data.length3 = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/ultarsonic_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '028b4e5a22a3865bca5861b18f927cff';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 时间戳
    uint32 time_stamp
    # 三个超声波传感器测量的长度
    float64 length1
    float64 length2
    float64 length3
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ultarsonic_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.length1 !== undefined) {
      resolved.length1 = msg.length1;
    }
    else {
      resolved.length1 = 0.0
    }

    if (msg.length2 !== undefined) {
      resolved.length2 = msg.length2;
    }
    else {
      resolved.length2 = 0.0
    }

    if (msg.length3 !== undefined) {
      resolved.length3 = msg.length3;
    }
    else {
      resolved.length3 = 0.0
    }

    return resolved;
    }
};

module.exports = ultarsonic_feedback;
