// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let reflector = require('./reflector.js');

//-----------------------------------------------------------

class reflector_list {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.reflector_list = null;
    }
    else {
      if (initObj.hasOwnProperty('reflector_list')) {
        this.reflector_list = initObj.reflector_list
      }
      else {
        this.reflector_list = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type reflector_list
    // Serialize message field [reflector_list]
    // Serialize the length for message field [reflector_list]
    bufferOffset = _serializer.uint32(obj.reflector_list.length, buffer, bufferOffset);
    obj.reflector_list.forEach((val) => {
      bufferOffset = reflector.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type reflector_list
    let len;
    let data = new reflector_list(null);
    // Deserialize message field [reflector_list]
    // Deserialize array length for message field [reflector_list]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.reflector_list = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.reflector_list[i] = reflector.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 24 * object.reflector_list.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/reflector_list';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '621a564b1544895890ce3d2f27d41ea0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cotek_msgs/reflector[] reflector_list
    ================================================================================
    MSG: cotek_msgs/reflector
    uint32 id
    float64 x
    float64 y
    uint32 count
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new reflector_list(null);
    if (msg.reflector_list !== undefined) {
      resolved.reflector_list = new Array(msg.reflector_list.length);
      for (let i = 0; i < resolved.reflector_list.length; ++i) {
        resolved.reflector_list[i] = reflector.Resolve(msg.reflector_list[i]);
      }
    }
    else {
      resolved.reflector_list = []
    }

    return resolved;
    }
};

module.exports = reflector_list;
