// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class pallet_fork_io_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.fork_up_down_state = null;
      this.fork_pallet_state = null;
    }
    else {
      if (initObj.hasOwnProperty('fork_up_down_state')) {
        this.fork_up_down_state = initObj.fork_up_down_state
      }
      else {
        this.fork_up_down_state = 0;
      }
      if (initObj.hasOwnProperty('fork_pallet_state')) {
        this.fork_pallet_state = initObj.fork_pallet_state
      }
      else {
        this.fork_pallet_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type pallet_fork_io_state
    // Serialize message field [fork_up_down_state]
    bufferOffset = _serializer.uint8(obj.fork_up_down_state, buffer, bufferOffset);
    // Serialize message field [fork_pallet_state]
    bufferOffset = _serializer.uint8(obj.fork_pallet_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type pallet_fork_io_state
    let len;
    let data = new pallet_fork_io_state(null);
    // Deserialize message field [fork_up_down_state]
    data.fork_up_down_state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [fork_pallet_state]
    data.fork_pallet_state = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/pallet_fork_io_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd35520bdb65b7a98ed31207edc2a2fbd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 fork_up_down_state
    uint8 fork_pallet_state
    
    # enum class ForkPalletState : uint32_t {
    #   NONE = 0,         // 左右都无检测
    #   LEFT_CHECK = 1,   // 左边检测到
    #   RIGHT_CHECK = 2,  // 右边检测到
    #   BOTH = 3,         // 左右都检测到
    # };
    
    # enum class ForkStateType : uint32_t { DOWN = 0, MIDDLE = 1, UP = 2 };
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new pallet_fork_io_state(null);
    if (msg.fork_up_down_state !== undefined) {
      resolved.fork_up_down_state = msg.fork_up_down_state;
    }
    else {
      resolved.fork_up_down_state = 0
    }

    if (msg.fork_pallet_state !== undefined) {
      resolved.fork_pallet_state = msg.fork_pallet_state;
    }
    else {
      resolved.fork_pallet_state = 0
    }

    return resolved;
    }
};

module.exports = pallet_fork_io_state;
