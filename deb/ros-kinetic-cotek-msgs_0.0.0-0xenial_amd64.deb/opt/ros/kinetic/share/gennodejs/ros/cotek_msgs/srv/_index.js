
"use strict";

let update_avoid_area_config = require('./update_avoid_area_config.js')
let update_embedded_config = require('./update_embedded_config.js')
let update_localizer_config = require('./update_localizer_config.js')
let update_navigation_config = require('./update_navigation_config.js')
let update_action_config = require('./update_action_config.js')
let update_avoid_config = require('./update_avoid_config.js')
let update_logic_config = require('./update_logic_config.js')

module.exports = {
  update_avoid_area_config: update_avoid_area_config,
  update_embedded_config: update_embedded_config,
  update_localizer_config: update_localizer_config,
  update_navigation_config: update_navigation_config,
  update_action_config: update_action_config,
  update_avoid_config: update_avoid_config,
  update_logic_config: update_logic_config,
};
