// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class step {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sequence_id = null;
      this.navi_type = null;
      this.step_type = null;
      this.move_type = null;
      this.path_type = null;
      this.node_id = null;
      this.point_id = null;
      this.point_x = null;
      this.point_y = null;
      this.point_yaw = null;
      this.relative = null;
      this.plate_angle = null;
      this.plate_weight = null;
      this.control_point_x0 = null;
      this.control_point_y0 = null;
      this.control_point_x1 = null;
      this.control_point_y1 = null;
      this.current_sec_id = null;
      this.target_sec_id = null;
      this.switch_point_id = null;
      this.switch_point_x = null;
      this.switch_point_y = null;
      this.switch_point_yaw = null;
      this.speed = null;
      this.odom = null;
      this.ultrasonic_obstacle = null;
      this.avoid_strategy_code = null;
      this.operation_type = null;
      this.operation_value = null;
    }
    else {
      if (initObj.hasOwnProperty('sequence_id')) {
        this.sequence_id = initObj.sequence_id
      }
      else {
        this.sequence_id = 0;
      }
      if (initObj.hasOwnProperty('navi_type')) {
        this.navi_type = initObj.navi_type
      }
      else {
        this.navi_type = 0;
      }
      if (initObj.hasOwnProperty('step_type')) {
        this.step_type = initObj.step_type
      }
      else {
        this.step_type = 0;
      }
      if (initObj.hasOwnProperty('move_type')) {
        this.move_type = initObj.move_type
      }
      else {
        this.move_type = 0;
      }
      if (initObj.hasOwnProperty('path_type')) {
        this.path_type = initObj.path_type
      }
      else {
        this.path_type = 0;
      }
      if (initObj.hasOwnProperty('node_id')) {
        this.node_id = initObj.node_id
      }
      else {
        this.node_id = '';
      }
      if (initObj.hasOwnProperty('point_id')) {
        this.point_id = initObj.point_id
      }
      else {
        this.point_id = 0;
      }
      if (initObj.hasOwnProperty('point_x')) {
        this.point_x = initObj.point_x
      }
      else {
        this.point_x = 0.0;
      }
      if (initObj.hasOwnProperty('point_y')) {
        this.point_y = initObj.point_y
      }
      else {
        this.point_y = 0.0;
      }
      if (initObj.hasOwnProperty('point_yaw')) {
        this.point_yaw = initObj.point_yaw
      }
      else {
        this.point_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('relative')) {
        this.relative = initObj.relative
      }
      else {
        this.relative = 0;
      }
      if (initObj.hasOwnProperty('plate_angle')) {
        this.plate_angle = initObj.plate_angle
      }
      else {
        this.plate_angle = 0.0;
      }
      if (initObj.hasOwnProperty('plate_weight')) {
        this.plate_weight = initObj.plate_weight
      }
      else {
        this.plate_weight = 0.0;
      }
      if (initObj.hasOwnProperty('control_point_x0')) {
        this.control_point_x0 = initObj.control_point_x0
      }
      else {
        this.control_point_x0 = 0.0;
      }
      if (initObj.hasOwnProperty('control_point_y0')) {
        this.control_point_y0 = initObj.control_point_y0
      }
      else {
        this.control_point_y0 = 0.0;
      }
      if (initObj.hasOwnProperty('control_point_x1')) {
        this.control_point_x1 = initObj.control_point_x1
      }
      else {
        this.control_point_x1 = 0.0;
      }
      if (initObj.hasOwnProperty('control_point_y1')) {
        this.control_point_y1 = initObj.control_point_y1
      }
      else {
        this.control_point_y1 = 0.0;
      }
      if (initObj.hasOwnProperty('current_sec_id')) {
        this.current_sec_id = initObj.current_sec_id
      }
      else {
        this.current_sec_id = 0;
      }
      if (initObj.hasOwnProperty('target_sec_id')) {
        this.target_sec_id = initObj.target_sec_id
      }
      else {
        this.target_sec_id = 0;
      }
      if (initObj.hasOwnProperty('switch_point_id')) {
        this.switch_point_id = initObj.switch_point_id
      }
      else {
        this.switch_point_id = 0;
      }
      if (initObj.hasOwnProperty('switch_point_x')) {
        this.switch_point_x = initObj.switch_point_x
      }
      else {
        this.switch_point_x = 0.0;
      }
      if (initObj.hasOwnProperty('switch_point_y')) {
        this.switch_point_y = initObj.switch_point_y
      }
      else {
        this.switch_point_y = 0.0;
      }
      if (initObj.hasOwnProperty('switch_point_yaw')) {
        this.switch_point_yaw = initObj.switch_point_yaw
      }
      else {
        this.switch_point_yaw = 0.0;
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = 0.0;
      }
      if (initObj.hasOwnProperty('odom')) {
        this.odom = initObj.odom
      }
      else {
        this.odom = 0.0;
      }
      if (initObj.hasOwnProperty('ultrasonic_obstacle')) {
        this.ultrasonic_obstacle = initObj.ultrasonic_obstacle
      }
      else {
        this.ultrasonic_obstacle = 0;
      }
      if (initObj.hasOwnProperty('avoid_strategy_code')) {
        this.avoid_strategy_code = initObj.avoid_strategy_code
      }
      else {
        this.avoid_strategy_code = 0;
      }
      if (initObj.hasOwnProperty('operation_type')) {
        this.operation_type = initObj.operation_type
      }
      else {
        this.operation_type = 0;
      }
      if (initObj.hasOwnProperty('operation_value')) {
        this.operation_value = initObj.operation_value
      }
      else {
        this.operation_value = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type step
    // Serialize message field [sequence_id]
    bufferOffset = _serializer.int32(obj.sequence_id, buffer, bufferOffset);
    // Serialize message field [navi_type]
    bufferOffset = _serializer.int32(obj.navi_type, buffer, bufferOffset);
    // Serialize message field [step_type]
    bufferOffset = _serializer.int32(obj.step_type, buffer, bufferOffset);
    // Serialize message field [move_type]
    bufferOffset = _serializer.int32(obj.move_type, buffer, bufferOffset);
    // Serialize message field [path_type]
    bufferOffset = _serializer.int32(obj.path_type, buffer, bufferOffset);
    // Serialize message field [node_id]
    bufferOffset = _serializer.string(obj.node_id, buffer, bufferOffset);
    // Serialize message field [point_id]
    bufferOffset = _serializer.int32(obj.point_id, buffer, bufferOffset);
    // Serialize message field [point_x]
    bufferOffset = _serializer.float64(obj.point_x, buffer, bufferOffset);
    // Serialize message field [point_y]
    bufferOffset = _serializer.float64(obj.point_y, buffer, bufferOffset);
    // Serialize message field [point_yaw]
    bufferOffset = _serializer.float64(obj.point_yaw, buffer, bufferOffset);
    // Serialize message field [relative]
    bufferOffset = _serializer.int32(obj.relative, buffer, bufferOffset);
    // Serialize message field [plate_angle]
    bufferOffset = _serializer.float64(obj.plate_angle, buffer, bufferOffset);
    // Serialize message field [plate_weight]
    bufferOffset = _serializer.float64(obj.plate_weight, buffer, bufferOffset);
    // Serialize message field [control_point_x0]
    bufferOffset = _serializer.float64(obj.control_point_x0, buffer, bufferOffset);
    // Serialize message field [control_point_y0]
    bufferOffset = _serializer.float64(obj.control_point_y0, buffer, bufferOffset);
    // Serialize message field [control_point_x1]
    bufferOffset = _serializer.float64(obj.control_point_x1, buffer, bufferOffset);
    // Serialize message field [control_point_y1]
    bufferOffset = _serializer.float64(obj.control_point_y1, buffer, bufferOffset);
    // Serialize message field [current_sec_id]
    bufferOffset = _serializer.int32(obj.current_sec_id, buffer, bufferOffset);
    // Serialize message field [target_sec_id]
    bufferOffset = _serializer.int32(obj.target_sec_id, buffer, bufferOffset);
    // Serialize message field [switch_point_id]
    bufferOffset = _serializer.int32(obj.switch_point_id, buffer, bufferOffset);
    // Serialize message field [switch_point_x]
    bufferOffset = _serializer.float64(obj.switch_point_x, buffer, bufferOffset);
    // Serialize message field [switch_point_y]
    bufferOffset = _serializer.float64(obj.switch_point_y, buffer, bufferOffset);
    // Serialize message field [switch_point_yaw]
    bufferOffset = _serializer.float64(obj.switch_point_yaw, buffer, bufferOffset);
    // Serialize message field [speed]
    bufferOffset = _serializer.float64(obj.speed, buffer, bufferOffset);
    // Serialize message field [odom]
    bufferOffset = _serializer.float64(obj.odom, buffer, bufferOffset);
    // Serialize message field [ultrasonic_obstacle]
    bufferOffset = _serializer.int32(obj.ultrasonic_obstacle, buffer, bufferOffset);
    // Serialize message field [avoid_strategy_code]
    bufferOffset = _serializer.int32(obj.avoid_strategy_code, buffer, bufferOffset);
    // Serialize message field [operation_type]
    bufferOffset = _serializer.int32(obj.operation_type, buffer, bufferOffset);
    // Serialize message field [operation_value]
    bufferOffset = _serializer.float64(obj.operation_value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type step
    let len;
    let data = new step(null);
    // Deserialize message field [sequence_id]
    data.sequence_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [navi_type]
    data.navi_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [step_type]
    data.step_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [move_type]
    data.move_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [path_type]
    data.path_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [node_id]
    data.node_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [point_id]
    data.point_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [point_x]
    data.point_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [point_y]
    data.point_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [point_yaw]
    data.point_yaw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [relative]
    data.relative = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [plate_angle]
    data.plate_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [plate_weight]
    data.plate_weight = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [control_point_x0]
    data.control_point_x0 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [control_point_y0]
    data.control_point_y0 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [control_point_x1]
    data.control_point_x1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [control_point_y1]
    data.control_point_y1 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current_sec_id]
    data.current_sec_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [target_sec_id]
    data.target_sec_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [switch_point_id]
    data.switch_point_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [switch_point_x]
    data.switch_point_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [switch_point_y]
    data.switch_point_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [switch_point_yaw]
    data.switch_point_yaw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [speed]
    data.speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [odom]
    data.odom = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ultrasonic_obstacle]
    data.ultrasonic_obstacle = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [avoid_strategy_code]
    data.avoid_strategy_code = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [operation_type]
    data.operation_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [operation_value]
    data.operation_value = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.node_id.length;
    return length + 176;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/step';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0aaf3187093067242286930e52548660';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 sequence_id
    int32 navi_type
    int32 step_type
    int32 move_type
    int32 path_type
    string node_id
    int32 point_id
    float64 point_x
    float64 point_y
    float64 point_yaw
    int32 relative
    float64 plate_angle
    float64 plate_weight
    float64 control_point_x0
    float64 control_point_y0
    float64 control_point_x1
    float64 control_point_y1
    int32 current_sec_id
    int32 target_sec_id
    int32 switch_point_id
    float64 switch_point_x
    float64 switch_point_y
    float64 switch_point_yaw
    float64 speed
    float64 odom
    int32 ultrasonic_obstacle
    int32 avoid_strategy_code
    int32 operation_type
    float64 operation_value
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new step(null);
    if (msg.sequence_id !== undefined) {
      resolved.sequence_id = msg.sequence_id;
    }
    else {
      resolved.sequence_id = 0
    }

    if (msg.navi_type !== undefined) {
      resolved.navi_type = msg.navi_type;
    }
    else {
      resolved.navi_type = 0
    }

    if (msg.step_type !== undefined) {
      resolved.step_type = msg.step_type;
    }
    else {
      resolved.step_type = 0
    }

    if (msg.move_type !== undefined) {
      resolved.move_type = msg.move_type;
    }
    else {
      resolved.move_type = 0
    }

    if (msg.path_type !== undefined) {
      resolved.path_type = msg.path_type;
    }
    else {
      resolved.path_type = 0
    }

    if (msg.node_id !== undefined) {
      resolved.node_id = msg.node_id;
    }
    else {
      resolved.node_id = ''
    }

    if (msg.point_id !== undefined) {
      resolved.point_id = msg.point_id;
    }
    else {
      resolved.point_id = 0
    }

    if (msg.point_x !== undefined) {
      resolved.point_x = msg.point_x;
    }
    else {
      resolved.point_x = 0.0
    }

    if (msg.point_y !== undefined) {
      resolved.point_y = msg.point_y;
    }
    else {
      resolved.point_y = 0.0
    }

    if (msg.point_yaw !== undefined) {
      resolved.point_yaw = msg.point_yaw;
    }
    else {
      resolved.point_yaw = 0.0
    }

    if (msg.relative !== undefined) {
      resolved.relative = msg.relative;
    }
    else {
      resolved.relative = 0
    }

    if (msg.plate_angle !== undefined) {
      resolved.plate_angle = msg.plate_angle;
    }
    else {
      resolved.plate_angle = 0.0
    }

    if (msg.plate_weight !== undefined) {
      resolved.plate_weight = msg.plate_weight;
    }
    else {
      resolved.plate_weight = 0.0
    }

    if (msg.control_point_x0 !== undefined) {
      resolved.control_point_x0 = msg.control_point_x0;
    }
    else {
      resolved.control_point_x0 = 0.0
    }

    if (msg.control_point_y0 !== undefined) {
      resolved.control_point_y0 = msg.control_point_y0;
    }
    else {
      resolved.control_point_y0 = 0.0
    }

    if (msg.control_point_x1 !== undefined) {
      resolved.control_point_x1 = msg.control_point_x1;
    }
    else {
      resolved.control_point_x1 = 0.0
    }

    if (msg.control_point_y1 !== undefined) {
      resolved.control_point_y1 = msg.control_point_y1;
    }
    else {
      resolved.control_point_y1 = 0.0
    }

    if (msg.current_sec_id !== undefined) {
      resolved.current_sec_id = msg.current_sec_id;
    }
    else {
      resolved.current_sec_id = 0
    }

    if (msg.target_sec_id !== undefined) {
      resolved.target_sec_id = msg.target_sec_id;
    }
    else {
      resolved.target_sec_id = 0
    }

    if (msg.switch_point_id !== undefined) {
      resolved.switch_point_id = msg.switch_point_id;
    }
    else {
      resolved.switch_point_id = 0
    }

    if (msg.switch_point_x !== undefined) {
      resolved.switch_point_x = msg.switch_point_x;
    }
    else {
      resolved.switch_point_x = 0.0
    }

    if (msg.switch_point_y !== undefined) {
      resolved.switch_point_y = msg.switch_point_y;
    }
    else {
      resolved.switch_point_y = 0.0
    }

    if (msg.switch_point_yaw !== undefined) {
      resolved.switch_point_yaw = msg.switch_point_yaw;
    }
    else {
      resolved.switch_point_yaw = 0.0
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = 0.0
    }

    if (msg.odom !== undefined) {
      resolved.odom = msg.odom;
    }
    else {
      resolved.odom = 0.0
    }

    if (msg.ultrasonic_obstacle !== undefined) {
      resolved.ultrasonic_obstacle = msg.ultrasonic_obstacle;
    }
    else {
      resolved.ultrasonic_obstacle = 0
    }

    if (msg.avoid_strategy_code !== undefined) {
      resolved.avoid_strategy_code = msg.avoid_strategy_code;
    }
    else {
      resolved.avoid_strategy_code = 0
    }

    if (msg.operation_type !== undefined) {
      resolved.operation_type = msg.operation_type;
    }
    else {
      resolved.operation_type = 0
    }

    if (msg.operation_value !== undefined) {
      resolved.operation_value = msg.operation_value;
    }
    else {
      resolved.operation_value = 0.0
    }

    return resolved;
    }
};

module.exports = step;
