// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class dongle_to_dispatch {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.dongle_type = null;
      this.encrypt_data = null;
    }
    else {
      if (initObj.hasOwnProperty('dongle_type')) {
        this.dongle_type = initObj.dongle_type
      }
      else {
        this.dongle_type = '';
      }
      if (initObj.hasOwnProperty('encrypt_data')) {
        this.encrypt_data = initObj.encrypt_data
      }
      else {
        this.encrypt_data = new Array(16).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type dongle_to_dispatch
    // Serialize message field [dongle_type]
    bufferOffset = _serializer.string(obj.dongle_type, buffer, bufferOffset);
    // Check that the constant length array field [encrypt_data] has the right length
    if (obj.encrypt_data.length !== 16) {
      throw new Error('Unable to serialize array field encrypt_data - length must be 16')
    }
    // Serialize message field [encrypt_data]
    bufferOffset = _arraySerializer.uint8(obj.encrypt_data, buffer, bufferOffset, 16);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type dongle_to_dispatch
    let len;
    let data = new dongle_to_dispatch(null);
    // Deserialize message field [dongle_type]
    data.dongle_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [encrypt_data]
    data.encrypt_data = _arrayDeserializer.uint8(buffer, bufferOffset, 16)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.dongle_type.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/dongle_to_dispatch';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5d9cc34c6ffbbd58163e83ce18723d09';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 加密数据
    string dongle_type
    uint8[16] encrypt_data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new dongle_to_dispatch(null);
    if (msg.dongle_type !== undefined) {
      resolved.dongle_type = msg.dongle_type;
    }
    else {
      resolved.dongle_type = ''
    }

    if (msg.encrypt_data !== undefined) {
      resolved.encrypt_data = msg.encrypt_data;
    }
    else {
      resolved.encrypt_data = new Array(16).fill(0)
    }

    return resolved;
    }
};

module.exports = dongle_to_dispatch;
