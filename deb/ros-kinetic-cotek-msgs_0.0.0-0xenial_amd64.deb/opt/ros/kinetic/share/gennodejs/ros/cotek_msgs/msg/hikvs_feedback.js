// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class hikvs_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.x_deviation = null;
      this.y_deviation = null;
      this.angle = null;
      this.tag_number = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('x_deviation')) {
        this.x_deviation = initObj.x_deviation
      }
      else {
        this.x_deviation = 0.0;
      }
      if (initObj.hasOwnProperty('y_deviation')) {
        this.y_deviation = initObj.y_deviation
      }
      else {
        this.y_deviation = 0.0;
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0.0;
      }
      if (initObj.hasOwnProperty('tag_number')) {
        this.tag_number = initObj.tag_number
      }
      else {
        this.tag_number = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type hikvs_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [x_deviation]
    bufferOffset = _serializer.float32(obj.x_deviation, buffer, bufferOffset);
    // Serialize message field [y_deviation]
    bufferOffset = _serializer.float32(obj.y_deviation, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.float32(obj.angle, buffer, bufferOffset);
    // Serialize message field [tag_number]
    bufferOffset = _serializer.uint64(obj.tag_number, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type hikvs_feedback
    let len;
    let data = new hikvs_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [x_deviation]
    data.x_deviation = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [y_deviation]
    data.y_deviation = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [tag_number]
    data.tag_number = _deserializer.uint64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/hikvs_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'aed29db64bb6e013d46dd57eb3ad5442';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
      uint32 time_stamp
      float32 x_deviation
      float32 y_deviation
      float32 angle
      uint64 tag_number
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new hikvs_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.x_deviation !== undefined) {
      resolved.x_deviation = msg.x_deviation;
    }
    else {
      resolved.x_deviation = 0.0
    }

    if (msg.y_deviation !== undefined) {
      resolved.y_deviation = msg.y_deviation;
    }
    else {
      resolved.y_deviation = 0.0
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0.0
    }

    if (msg.tag_number !== undefined) {
      resolved.tag_number = msg.tag_number;
    }
    else {
      resolved.tag_number = 0
    }

    return resolved;
    }
};

module.exports = hikvs_feedback;
