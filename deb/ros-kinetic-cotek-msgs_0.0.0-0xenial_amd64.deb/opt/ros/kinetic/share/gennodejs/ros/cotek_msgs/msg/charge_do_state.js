// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class charge_do_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.charge_do_state = null;
    }
    else {
      if (initObj.hasOwnProperty('charge_do_state')) {
        this.charge_do_state = initObj.charge_do_state
      }
      else {
        this.charge_do_state = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type charge_do_state
    // Serialize message field [charge_do_state]
    bufferOffset = _serializer.bool(obj.charge_do_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type charge_do_state
    let len;
    let data = new charge_do_state(null);
    // Deserialize message field [charge_do_state]
    data.charge_do_state = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/charge_do_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5d8df11333a474a52523ded223185560';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool charge_do_state
    
    # true: 充电继电器打开  false：充电继电器关闭　
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new charge_do_state(null);
    if (msg.charge_do_state !== undefined) {
      resolved.charge_do_state = msg.charge_do_state;
    }
    else {
      resolved.charge_do_state = false
    }

    return resolved;
    }
};

module.exports = charge_do_state;
