// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let error_info = require('./error_info.js');

//-----------------------------------------------------------

class node_diagnostic {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.status = null;
      this.error_info = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('error_info')) {
        this.error_info = initObj.error_info
      }
      else {
        this.error_info = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type node_diagnostic
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint16(obj.status, buffer, bufferOffset);
    // Serialize message field [error_info]
    // Serialize the length for message field [error_info]
    bufferOffset = _serializer.uint32(obj.error_info.length, buffer, bufferOffset);
    obj.error_info.forEach((val) => {
      bufferOffset = error_info.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type node_diagnostic
    let len;
    let data = new node_diagnostic(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [error_info]
    // Deserialize array length for message field [error_info]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.error_info = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.error_info[i] = error_info.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.error_info.length;
    return length + 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/node_diagnostic';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5fbcb6b61c2a63de8a8026257665c3b2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    uint16 status
    cotek_msgs/error_info[] error_info
    
    
    ================================================================================
    MSG: cotek_msgs/error_info
    float64 error_info
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new node_diagnostic(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.error_info !== undefined) {
      resolved.error_info = new Array(msg.error_info.length);
      for (let i = 0; i < resolved.error_info.length; ++i) {
        resolved.error_info[i] = error_info.Resolve(msg.error_info[i]);
      }
    }
    else {
      resolved.error_info = []
    }

    return resolved;
    }
};

module.exports = node_diagnostic;
