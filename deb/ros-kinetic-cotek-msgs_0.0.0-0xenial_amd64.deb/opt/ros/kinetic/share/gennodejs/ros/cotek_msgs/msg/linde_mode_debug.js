// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class linde_mode_debug {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.driver_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('driver_mode')) {
        this.driver_mode = initObj.driver_mode
      }
      else {
        this.driver_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type linde_mode_debug
    // Serialize message field [driver_mode]
    bufferOffset = _serializer.uint8(obj.driver_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type linde_mode_debug
    let len;
    let data = new linde_mode_debug(null);
    // Deserialize message field [driver_mode]
    data.driver_mode = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/linde_mode_debug';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '45c34a21b69c5724b9f2773be1c72add';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 driver_mode
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new linde_mode_debug(null);
    if (msg.driver_mode !== undefined) {
      resolved.driver_mode = msg.driver_mode;
    }
    else {
      resolved.driver_mode = 0
    }

    return resolved;
    }
};

module.exports = linde_mode_debug;
