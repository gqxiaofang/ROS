// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class stop_protect {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stop_protect = null;
    }
    else {
      if (initObj.hasOwnProperty('stop_protect')) {
        this.stop_protect = initObj.stop_protect
      }
      else {
        this.stop_protect = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type stop_protect
    // Serialize message field [stop_protect]
    bufferOffset = _serializer.bool(obj.stop_protect, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type stop_protect
    let len;
    let data = new stop_protect(null);
    // Deserialize message field [stop_protect]
    data.stop_protect = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/stop_protect';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3092b7b1c7ae2ed2d126e7cef8956ba3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool stop_protect
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new stop_protect(null);
    if (msg.stop_protect !== undefined) {
      resolved.stop_protect = msg.stop_protect;
    }
    else {
      resolved.stop_protect = false
    }

    return resolved;
    }
};

module.exports = stop_protect;
