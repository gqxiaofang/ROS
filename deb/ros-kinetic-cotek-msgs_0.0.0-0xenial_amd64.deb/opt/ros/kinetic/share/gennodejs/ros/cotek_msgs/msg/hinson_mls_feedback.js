// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class hinson_mls_feedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time_stamp = null;
      this.lines_info = null;
      this.line_offset = null;
      this.strength = null;
      this.interaction_count = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0;
      }
      if (initObj.hasOwnProperty('lines_info')) {
        this.lines_info = initObj.lines_info
      }
      else {
        this.lines_info = 0;
      }
      if (initObj.hasOwnProperty('line_offset')) {
        this.line_offset = initObj.line_offset
      }
      else {
        this.line_offset = 0;
      }
      if (initObj.hasOwnProperty('strength')) {
        this.strength = initObj.strength
      }
      else {
        this.strength = 0;
      }
      if (initObj.hasOwnProperty('interaction_count')) {
        this.interaction_count = initObj.interaction_count
      }
      else {
        this.interaction_count = 0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type hinson_mls_feedback
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.uint32(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [lines_info]
    bufferOffset = _serializer.uint16(obj.lines_info, buffer, bufferOffset);
    // Serialize message field [line_offset]
    bufferOffset = _serializer.int16(obj.line_offset, buffer, bufferOffset);
    // Serialize message field [strength]
    bufferOffset = _serializer.int16(obj.strength, buffer, bufferOffset);
    // Serialize message field [interaction_count]
    bufferOffset = _serializer.int16(obj.interaction_count, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.uint16(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type hinson_mls_feedback
    let len;
    let data = new hinson_mls_feedback(null);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [lines_info]
    data.lines_info = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [line_offset]
    data.line_offset = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [strength]
    data.strength = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [interaction_count]
    data.interaction_count = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/hinson_mls_feedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1286f060a2d4b7f327318b5b4c2c3e90';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
      # 时间戳
      uint32 time_stamp
      # 兴颂磁条传感器设备数据
      uint16 lines_info
      int16 line_offset  # mm left > 0, right < 0, center = 0;
      int16 strength
      int16 interaction_count
      #错误码
      uint16 error_code
      
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new hinson_mls_feedback(null);
    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0
    }

    if (msg.lines_info !== undefined) {
      resolved.lines_info = msg.lines_info;
    }
    else {
      resolved.lines_info = 0
    }

    if (msg.line_offset !== undefined) {
      resolved.line_offset = msg.line_offset;
    }
    else {
      resolved.line_offset = 0
    }

    if (msg.strength !== undefined) {
      resolved.strength = msg.strength;
    }
    else {
      resolved.strength = 0
    }

    if (msg.interaction_count !== undefined) {
      resolved.interaction_count = msg.interaction_count;
    }
    else {
      resolved.interaction_count = 0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = hinson_mls_feedback;
