// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let error_state = require('./error_state.js');

//-----------------------------------------------------------

class update_event {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.agv_id = null;
      this.node_id = null;
      this.point_id = null;
      this.plate_id = null;
      this.plate_angle = null;
      this.plate_weight = null;
      this.speed = null;
      this.x = null;
      this.y = null;
      this.yaw = null;
      this.lift_height = null;
      this.agv_status = null;
      this.current_section_id = null;
      this.switch_section_id = null;
      this.error_code = null;
      this.battery = null;
      this.power_supply = null;
      this.task_type = null;
      this.order_id = null;
      this.task_sequence = null;
    }
    else {
      if (initObj.hasOwnProperty('agv_id')) {
        this.agv_id = initObj.agv_id
      }
      else {
        this.agv_id = '';
      }
      if (initObj.hasOwnProperty('node_id')) {
        this.node_id = initObj.node_id
      }
      else {
        this.node_id = '';
      }
      if (initObj.hasOwnProperty('point_id')) {
        this.point_id = initObj.point_id
      }
      else {
        this.point_id = 0;
      }
      if (initObj.hasOwnProperty('plate_id')) {
        this.plate_id = initObj.plate_id
      }
      else {
        this.plate_id = 0;
      }
      if (initObj.hasOwnProperty('plate_angle')) {
        this.plate_angle = initObj.plate_angle
      }
      else {
        this.plate_angle = 0;
      }
      if (initObj.hasOwnProperty('plate_weight')) {
        this.plate_weight = initObj.plate_weight
      }
      else {
        this.plate_weight = 0;
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = 0.0;
      }
      if (initObj.hasOwnProperty('x')) {
        this.x = initObj.x
      }
      else {
        this.x = 0.0;
      }
      if (initObj.hasOwnProperty('y')) {
        this.y = initObj.y
      }
      else {
        this.y = 0.0;
      }
      if (initObj.hasOwnProperty('yaw')) {
        this.yaw = initObj.yaw
      }
      else {
        this.yaw = 0.0;
      }
      if (initObj.hasOwnProperty('lift_height')) {
        this.lift_height = initObj.lift_height
      }
      else {
        this.lift_height = 0.0;
      }
      if (initObj.hasOwnProperty('agv_status')) {
        this.agv_status = initObj.agv_status
      }
      else {
        this.agv_status = 0;
      }
      if (initObj.hasOwnProperty('current_section_id')) {
        this.current_section_id = initObj.current_section_id
      }
      else {
        this.current_section_id = 0;
      }
      if (initObj.hasOwnProperty('switch_section_id')) {
        this.switch_section_id = initObj.switch_section_id
      }
      else {
        this.switch_section_id = 0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = [];
      }
      if (initObj.hasOwnProperty('battery')) {
        this.battery = initObj.battery
      }
      else {
        this.battery = 0;
      }
      if (initObj.hasOwnProperty('power_supply')) {
        this.power_supply = initObj.power_supply
      }
      else {
        this.power_supply = 0;
      }
      if (initObj.hasOwnProperty('task_type')) {
        this.task_type = initObj.task_type
      }
      else {
        this.task_type = '';
      }
      if (initObj.hasOwnProperty('order_id')) {
        this.order_id = initObj.order_id
      }
      else {
        this.order_id = '';
      }
      if (initObj.hasOwnProperty('task_sequence')) {
        this.task_sequence = initObj.task_sequence
      }
      else {
        this.task_sequence = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type update_event
    // Serialize message field [agv_id]
    bufferOffset = _serializer.string(obj.agv_id, buffer, bufferOffset);
    // Serialize message field [node_id]
    bufferOffset = _serializer.string(obj.node_id, buffer, bufferOffset);
    // Serialize message field [point_id]
    bufferOffset = _serializer.int32(obj.point_id, buffer, bufferOffset);
    // Serialize message field [plate_id]
    bufferOffset = _serializer.int32(obj.plate_id, buffer, bufferOffset);
    // Serialize message field [plate_angle]
    bufferOffset = _serializer.int32(obj.plate_angle, buffer, bufferOffset);
    // Serialize message field [plate_weight]
    bufferOffset = _serializer.uint32(obj.plate_weight, buffer, bufferOffset);
    // Serialize message field [speed]
    bufferOffset = _serializer.float64(obj.speed, buffer, bufferOffset);
    // Serialize message field [x]
    bufferOffset = _serializer.float64(obj.x, buffer, bufferOffset);
    // Serialize message field [y]
    bufferOffset = _serializer.float64(obj.y, buffer, bufferOffset);
    // Serialize message field [yaw]
    bufferOffset = _serializer.float64(obj.yaw, buffer, bufferOffset);
    // Serialize message field [lift_height]
    bufferOffset = _serializer.float64(obj.lift_height, buffer, bufferOffset);
    // Serialize message field [agv_status]
    bufferOffset = _serializer.int32(obj.agv_status, buffer, bufferOffset);
    // Serialize message field [current_section_id]
    bufferOffset = _serializer.int32(obj.current_section_id, buffer, bufferOffset);
    // Serialize message field [switch_section_id]
    bufferOffset = _serializer.int32(obj.switch_section_id, buffer, bufferOffset);
    // Serialize message field [error_code]
    // Serialize the length for message field [error_code]
    bufferOffset = _serializer.uint32(obj.error_code.length, buffer, bufferOffset);
    obj.error_code.forEach((val) => {
      bufferOffset = error_state.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [battery]
    bufferOffset = _serializer.int32(obj.battery, buffer, bufferOffset);
    // Serialize message field [power_supply]
    bufferOffset = _serializer.int32(obj.power_supply, buffer, bufferOffset);
    // Serialize message field [task_type]
    bufferOffset = _serializer.string(obj.task_type, buffer, bufferOffset);
    // Serialize message field [order_id]
    bufferOffset = _serializer.string(obj.order_id, buffer, bufferOffset);
    // Serialize message field [task_sequence]
    bufferOffset = _serializer.int32(obj.task_sequence, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type update_event
    let len;
    let data = new update_event(null);
    // Deserialize message field [agv_id]
    data.agv_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [node_id]
    data.node_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [point_id]
    data.point_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [plate_id]
    data.plate_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [plate_angle]
    data.plate_angle = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [plate_weight]
    data.plate_weight = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [speed]
    data.speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [x]
    data.x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y]
    data.y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [yaw]
    data.yaw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [lift_height]
    data.lift_height = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [agv_status]
    data.agv_status = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [current_section_id]
    data.current_section_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [switch_section_id]
    data.switch_section_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [error_code]
    // Deserialize array length for message field [error_code]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.error_code = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.error_code[i] = error_state.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [battery]
    data.battery = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [power_supply]
    data.power_supply = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [task_type]
    data.task_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [order_id]
    data.order_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [task_sequence]
    data.task_sequence = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.agv_id.length;
    length += object.node_id.length;
    object.error_code.forEach((val) => {
      length += error_state.getMessageSize(val);
    });
    length += object.task_type.length;
    length += object.order_id.length;
    return length + 100;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/update_event';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd457d3edd4157630f6d6567e15d2f2bf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 状态更新事件消息包  -- 心跳包  taskType: ForkUpdataEvent
    string agv_id  # agv 设备的序列号
    string node_id  # 空间间实体对象的ID，表示agv当前所处的位置
    int32 point_id  # 目标点id
    int32 plate_id  # 托盘编号
    int32 plate_angle  # 托盘角度  -180 ~ 180
    uint32 plate_weight # 托盘承重
    float64 speed  # 当前速度 (单位)米为单位,精确到小数点后三位
    float64 x  # agv 在空间中所处的x坐标 (单位)米为单位,精确到小数点后三位
    float64 y  # agv 在空间中所处的y坐标 (单位)米为单位,精确到小数点后三位
    float64 yaw  # agv 在坐标系中的偏航角 -180 ~ 180
    float64 lift_height  # agv 当前托盘抬升高度，会随抬升过程而变化，单位米
    int32 agv_status  # agv 状态, 双方约定枚举类型
    int32 current_section_id  # 当前所在区域
    int32 switch_section_id  # 需要切换的目标区域
    cotek_msgs/error_state[] error_code  # 错误码表: 错误编号 + 错误码
    int32 battery  # 电池电量 0 ~ 100 %
    int32 power_supply  # 电源 1：断电 2：有电
    string task_type  # 当前正在处理的任务类型，与消息类型与消息体对象对照表对应
    string order_id # 工单号
    int32 task_sequence  # 当前正在处理的任务指令的序列号
    
    
    ================================================================================
    MSG: cotek_msgs/error_state
    string id
    int32 error_code
    cotek_msgs/error_info[] error_info
    ================================================================================
    MSG: cotek_msgs/error_info
    float64 error_info
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new update_event(null);
    if (msg.agv_id !== undefined) {
      resolved.agv_id = msg.agv_id;
    }
    else {
      resolved.agv_id = ''
    }

    if (msg.node_id !== undefined) {
      resolved.node_id = msg.node_id;
    }
    else {
      resolved.node_id = ''
    }

    if (msg.point_id !== undefined) {
      resolved.point_id = msg.point_id;
    }
    else {
      resolved.point_id = 0
    }

    if (msg.plate_id !== undefined) {
      resolved.plate_id = msg.plate_id;
    }
    else {
      resolved.plate_id = 0
    }

    if (msg.plate_angle !== undefined) {
      resolved.plate_angle = msg.plate_angle;
    }
    else {
      resolved.plate_angle = 0
    }

    if (msg.plate_weight !== undefined) {
      resolved.plate_weight = msg.plate_weight;
    }
    else {
      resolved.plate_weight = 0
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = 0.0
    }

    if (msg.x !== undefined) {
      resolved.x = msg.x;
    }
    else {
      resolved.x = 0.0
    }

    if (msg.y !== undefined) {
      resolved.y = msg.y;
    }
    else {
      resolved.y = 0.0
    }

    if (msg.yaw !== undefined) {
      resolved.yaw = msg.yaw;
    }
    else {
      resolved.yaw = 0.0
    }

    if (msg.lift_height !== undefined) {
      resolved.lift_height = msg.lift_height;
    }
    else {
      resolved.lift_height = 0.0
    }

    if (msg.agv_status !== undefined) {
      resolved.agv_status = msg.agv_status;
    }
    else {
      resolved.agv_status = 0
    }

    if (msg.current_section_id !== undefined) {
      resolved.current_section_id = msg.current_section_id;
    }
    else {
      resolved.current_section_id = 0
    }

    if (msg.switch_section_id !== undefined) {
      resolved.switch_section_id = msg.switch_section_id;
    }
    else {
      resolved.switch_section_id = 0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = new Array(msg.error_code.length);
      for (let i = 0; i < resolved.error_code.length; ++i) {
        resolved.error_code[i] = error_state.Resolve(msg.error_code[i]);
      }
    }
    else {
      resolved.error_code = []
    }

    if (msg.battery !== undefined) {
      resolved.battery = msg.battery;
    }
    else {
      resolved.battery = 0
    }

    if (msg.power_supply !== undefined) {
      resolved.power_supply = msg.power_supply;
    }
    else {
      resolved.power_supply = 0
    }

    if (msg.task_type !== undefined) {
      resolved.task_type = msg.task_type;
    }
    else {
      resolved.task_type = ''
    }

    if (msg.order_id !== undefined) {
      resolved.order_id = msg.order_id;
    }
    else {
      resolved.order_id = ''
    }

    if (msg.task_sequence !== undefined) {
      resolved.task_sequence = msg.task_sequence;
    }
    else {
      resolved.task_sequence = 0
    }

    return resolved;
    }
};

module.exports = update_event;
