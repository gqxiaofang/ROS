// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class pallet_act_info {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.lift_velocity = null;
      this.lift_height = null;
      this.lift_rpm = null;
      this.height_init = null;
      this.rotate_omega = null;
      this.rotate_degree = null;
      this.rotate_rpm = null;
      this.degree_init = null;
    }
    else {
      if (initObj.hasOwnProperty('lift_velocity')) {
        this.lift_velocity = initObj.lift_velocity
      }
      else {
        this.lift_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('lift_height')) {
        this.lift_height = initObj.lift_height
      }
      else {
        this.lift_height = 0.0;
      }
      if (initObj.hasOwnProperty('lift_rpm')) {
        this.lift_rpm = initObj.lift_rpm
      }
      else {
        this.lift_rpm = 0;
      }
      if (initObj.hasOwnProperty('height_init')) {
        this.height_init = initObj.height_init
      }
      else {
        this.height_init = false;
      }
      if (initObj.hasOwnProperty('rotate_omega')) {
        this.rotate_omega = initObj.rotate_omega
      }
      else {
        this.rotate_omega = 0.0;
      }
      if (initObj.hasOwnProperty('rotate_degree')) {
        this.rotate_degree = initObj.rotate_degree
      }
      else {
        this.rotate_degree = 0.0;
      }
      if (initObj.hasOwnProperty('rotate_rpm')) {
        this.rotate_rpm = initObj.rotate_rpm
      }
      else {
        this.rotate_rpm = 0;
      }
      if (initObj.hasOwnProperty('degree_init')) {
        this.degree_init = initObj.degree_init
      }
      else {
        this.degree_init = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type pallet_act_info
    // Serialize message field [lift_velocity]
    bufferOffset = _serializer.float64(obj.lift_velocity, buffer, bufferOffset);
    // Serialize message field [lift_height]
    bufferOffset = _serializer.float64(obj.lift_height, buffer, bufferOffset);
    // Serialize message field [lift_rpm]
    bufferOffset = _serializer.int32(obj.lift_rpm, buffer, bufferOffset);
    // Serialize message field [height_init]
    bufferOffset = _serializer.bool(obj.height_init, buffer, bufferOffset);
    // Serialize message field [rotate_omega]
    bufferOffset = _serializer.float64(obj.rotate_omega, buffer, bufferOffset);
    // Serialize message field [rotate_degree]
    bufferOffset = _serializer.float64(obj.rotate_degree, buffer, bufferOffset);
    // Serialize message field [rotate_rpm]
    bufferOffset = _serializer.int32(obj.rotate_rpm, buffer, bufferOffset);
    // Serialize message field [degree_init]
    bufferOffset = _serializer.bool(obj.degree_init, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type pallet_act_info
    let len;
    let data = new pallet_act_info(null);
    // Deserialize message field [lift_velocity]
    data.lift_velocity = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [lift_height]
    data.lift_height = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [lift_rpm]
    data.lift_rpm = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [height_init]
    data.height_init = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [rotate_omega]
    data.rotate_omega = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rotate_degree]
    data.rotate_degree = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rotate_rpm]
    data.rotate_rpm = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [degree_init]
    data.degree_init = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 42;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/pallet_act_info';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '670279a69953c2192769da9f769f73bd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 lift_velocity #托盘升降线速度
    float64 lift_height   #托盘高度
    int32   lift_rpm      #顶升电机转速
    bool height_init      #高度初始化标志
    
    float64 rotate_omega  #托盘旋转角速度
    float64 rotate_degree #托盘角度
    int32   rotate_rpm    #旋转电机转速
    bool degree_init      #角度初始化标志
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new pallet_act_info(null);
    if (msg.lift_velocity !== undefined) {
      resolved.lift_velocity = msg.lift_velocity;
    }
    else {
      resolved.lift_velocity = 0.0
    }

    if (msg.lift_height !== undefined) {
      resolved.lift_height = msg.lift_height;
    }
    else {
      resolved.lift_height = 0.0
    }

    if (msg.lift_rpm !== undefined) {
      resolved.lift_rpm = msg.lift_rpm;
    }
    else {
      resolved.lift_rpm = 0
    }

    if (msg.height_init !== undefined) {
      resolved.height_init = msg.height_init;
    }
    else {
      resolved.height_init = false
    }

    if (msg.rotate_omega !== undefined) {
      resolved.rotate_omega = msg.rotate_omega;
    }
    else {
      resolved.rotate_omega = 0.0
    }

    if (msg.rotate_degree !== undefined) {
      resolved.rotate_degree = msg.rotate_degree;
    }
    else {
      resolved.rotate_degree = 0.0
    }

    if (msg.rotate_rpm !== undefined) {
      resolved.rotate_rpm = msg.rotate_rpm;
    }
    else {
      resolved.rotate_rpm = 0
    }

    if (msg.degree_init !== undefined) {
      resolved.degree_init = msg.degree_init;
    }
    else {
      resolved.degree_init = false
    }

    return resolved;
    }
};

module.exports = pallet_act_info;
