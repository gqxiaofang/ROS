// Auto-generated. Do not edit!

// (in-package cotek_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let error_info = require('./error_info.js');

//-----------------------------------------------------------

class error_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.error_code = null;
      this.error_info = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = '';
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
      if (initObj.hasOwnProperty('error_info')) {
        this.error_info = initObj.error_info
      }
      else {
        this.error_info = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type error_state
    // Serialize message field [id]
    bufferOffset = _serializer.string(obj.id, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.int32(obj.error_code, buffer, bufferOffset);
    // Serialize message field [error_info]
    // Serialize the length for message field [error_info]
    bufferOffset = _serializer.uint32(obj.error_info.length, buffer, bufferOffset);
    obj.error_info.forEach((val) => {
      bufferOffset = error_info.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type error_state
    let len;
    let data = new error_state(null);
    // Deserialize message field [id]
    data.id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [error_info]
    // Deserialize array length for message field [error_info]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.error_info = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.error_info[i] = error_info.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.id.length;
    length += 8 * object.error_info.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cotek_msgs/error_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ed8cf7218cfefa839991e5cf6bce4e7d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string id
    int32 error_code
    cotek_msgs/error_info[] error_info
    ================================================================================
    MSG: cotek_msgs/error_info
    float64 error_info
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new error_state(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = ''
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    if (msg.error_info !== undefined) {
      resolved.error_info = new Array(msg.error_info.length);
      for (let i = 0; i < resolved.error_info.length; ++i) {
        resolved.error_info[i] = error_info.Resolve(msg.error_info[i]);
      }
    }
    else {
      resolved.error_info = []
    }

    return resolved;
    }
};

module.exports = error_state;
